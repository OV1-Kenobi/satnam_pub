"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var encryption_exports = {};
__export(encryption_exports, {
  PrivacyUtils: () => PrivacyUtils,
  SecureMemoryBuffer: () => SecureMemoryBuffer,
  decryptNpub: () => decryptNpub,
  decryptNsec: () => decryptNsec,
  decryptNsecBytes: () => decryptNsecBytes,
  decryptNsecSimple: () => decryptNsecSimple,
  decryptSensitiveData: () => decryptSensitiveData,
  doubleDecryptSensitiveData: () => doubleDecryptSensitiveData,
  doubleEncryptSensitiveData: () => doubleEncryptSensitiveData,
  encryptNpub: () => encryptNpub,
  encryptNsec: () => encryptNsec,
  encryptNsecSimple: () => encryptNsecSimple,
  encryptSensitiveData: () => encryptSensitiveData,
  generateSalt: () => generateSalt,
  generateSecureFamilyId: () => generateSecureFamilyId,
  generateSecureUUID: () => generateSecureUUID,
  generateUniqueSalts: () => generateUniqueSalts,
  hashUsername: () => hashUsername,
  logPrivacyOperation: () => logPrivacyOperation,
  secureClearMemory: () => secureClearMemory,
  secureClearMemoryLegacy: () => secureClearMemoryLegacy,
  validateDataIntegrity: () => validateDataIntegrity,
  verifyUsername: () => verifyUsername
});
module.exports = __toCommonJS(encryption_exports);
var import_noble_encryption = require("../crypto/noble-encryption");
function getEnvVar(key) {
  return process.env[key];
}
const ENCRYPTION_CONFIG = {
  algorithm: "AES-GCM",
  keyLength: 256,
  ivLength: 12,
  // GCM uses 12 bytes for IV
  saltLength: 32,
  iterations: 1e5
  // High iteration count for key derivation
};
async function getMasterKey() {
  let vaultError = null;
  try {
    const vaultKey = await getPrivacyMasterKeyFromVault();
    if (vaultKey) {
      console.log("\u2705 Using privacy master key from Supabase Vault");
      return vaultKey;
    }
  } catch (error) {
    vaultError = error instanceof Error ? error : new Error("Unknown vault error");
    console.warn(`\u26A0\uFE0F  Vault access failed: ${vaultError.message}`);
  }
  const envKey = typeof window === "undefined" ? process.env.PRIVACY_MASTER_KEY : getEnvVar("PRIVACY_MASTER_KEY");
  if (envKey) {
    console.log("\u2705 Using privacy master key from environment variables");
    return envKey;
  }
  const errorDetails = [
    "CRITICAL SECURITY ERROR: No secure privacy master key available.",
    "",
    "Required configuration:",
    "1. Store PRIVACY_MASTER_KEY in Supabase Vault (recommended), OR",
    "2. Set PRIVACY_MASTER_KEY environment variable",
    "",
    "Vault access error: " + (vaultError?.message || "Unable to connect to vault"),
    "Environment variable: " + (envKey ? "Available" : "Not set"),
    "",
    "Encryption cannot proceed without a secure key."
  ].join("\n");
  throw new Error(errorDetails);
}
async function getPrivacyMasterKeyFromVault() {
  if (typeof window !== "undefined") {
    try {
      const { getPrivacyMasterKey } = await import("../../../lib/vault-config");
      return await getPrivacyMasterKey();
    } catch (error) {
      console.warn("Browser vault access failed:", error);
      return null;
    }
  } else {
    try {
      const { createClient } = await import("@supabase/supabase-js");
      const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
      const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_ANON_KEY;
      if (!supabaseUrl || !supabaseKey) {
        throw new Error(
          "Supabase credentials not available for vault access. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables."
        );
      }
      const supabase = createClient(supabaseUrl, supabaseKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: false
        },
        global: {
          headers: {
            "x-client-info": "privacy-encryption-vault-access@1.0.0"
          }
        }
      });
      const { data, error } = await supabase.from("vault.decrypted_secrets").select("decrypted_secret").eq("name", "privacy_master_key").single();
      if (error) {
        throw new Error(
          `Vault query failed: ${error.message}. Check vault setup and RLS policies.`
        );
      }
      if (!data?.decrypted_secret) {
        throw new Error(
          "PRIVACY_MASTER_KEY not found in Supabase Vault. Run vault setup to store the key."
        );
      }
      return data.decrypted_secret;
    } catch (error) {
      throw new Error(
        `Server vault access failed: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  }
}
function generateSecureUUID() {
  return crypto.randomUUID();
}
function generateSalt() {
  const salt = new Uint8Array(ENCRYPTION_CONFIG.saltLength);
  crypto.getRandomValues(salt);
  return salt;
}
function generateUniqueSalts(count) {
  const salts = [];
  for (let i = 0; i < count; i++) {
    salts.push(generateSalt());
  }
  return salts;
}
async function deriveKey(masterKey, salt) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(masterKey),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );
  const saltBuffer = new Uint8Array(salt.length);
  saltBuffer.set(salt);
  return await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: saltBuffer,
      iterations: ENCRYPTION_CONFIG.iterations,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: ENCRYPTION_CONFIG.keyLength },
    false,
    ["encrypt", "decrypt"]
  );
}
async function encryptSensitiveData(plaintext) {
  try {
    const salt = generateSalt();
    const iv = new Uint8Array(ENCRYPTION_CONFIG.ivLength);
    crypto.getRandomValues(iv);
    const masterKey = await getMasterKey();
    const key = await deriveKey(masterKey, salt);
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encrypted = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv,
        additionalData: encoder.encode("family-nostr-data")
      },
      key,
      data
    );
    return {
      encrypted: btoa(
        String.fromCharCode.apply(null, Array.from(new Uint8Array(encrypted)))
      ),
      salt: btoa(String.fromCharCode.apply(null, Array.from(salt))),
      iv: btoa(String.fromCharCode.apply(null, Array.from(iv))),
      tag: ""
      // GCM includes auth tag in encrypted data
    };
  } catch (error) {
    throw new Error(
      `Encryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function decryptSensitiveData(encryptedData) {
  try {
    const salt = new Uint8Array(
      atob(encryptedData.salt).split("").map((c) => c.charCodeAt(0))
    );
    const iv = new Uint8Array(
      atob(encryptedData.iv).split("").map((c) => c.charCodeAt(0))
    );
    const encrypted = new Uint8Array(
      atob(encryptedData.encrypted).split("").map((c) => c.charCodeAt(0))
    );
    const masterKey = await getMasterKey();
    const key = await deriveKey(masterKey, salt);
    const decrypted = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv,
        additionalData: new TextEncoder().encode("family-nostr-data")
      },
      key,
      encrypted
    );
    return new TextDecoder().decode(decrypted);
  } catch (error) {
    throw new Error(
      `Decryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function hashUsername(username) {
  try {
    const salt = generateSalt();
    const uuid = generateSecureUUID();
    const encoder = new TextEncoder();
    const data = encoder.encode(username.toLowerCase().trim());
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      data,
      { name: "PBKDF2" },
      false,
      ["deriveBits"]
    );
    const saltBuffer = new Uint8Array(salt.length);
    saltBuffer.set(salt);
    const hash = await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: saltBuffer,
        iterations: ENCRYPTION_CONFIG.iterations,
        hash: "SHA-512"
      },
      keyMaterial,
      512
    );
    return {
      hash: btoa(
        String.fromCharCode.apply(null, Array.from(new Uint8Array(hash)))
      ),
      salt: btoa(String.fromCharCode.apply(null, Array.from(salt))),
      uuid
    };
  } catch (error) {
    throw new Error(
      `Username hashing failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function verifyUsername(username, storedHash, storedSalt) {
  try {
    const salt = new Uint8Array(
      atob(storedSalt).split("").map((c) => c.charCodeAt(0))
    );
    const encoder = new TextEncoder();
    const data = encoder.encode(username.toLowerCase().trim());
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      data,
      { name: "PBKDF2" },
      false,
      ["deriveBits"]
    );
    const saltBuffer = new Uint8Array(salt.length);
    saltBuffer.set(salt);
    const hash = await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: saltBuffer,
        iterations: ENCRYPTION_CONFIG.iterations,
        hash: "SHA-512"
      },
      keyMaterial,
      512
    );
    const computedHash = btoa(
      String.fromCharCode.apply(null, Array.from(new Uint8Array(hash)))
    );
    return computedHash === storedHash;
  } catch (error) {
    console.error("Username verification failed:", error);
    return false;
  }
}
async function encryptNsec(nsec) {
  const result = await encryptSensitiveData(nsec);
  return {
    encryptedNsec: result.encrypted,
    salt: result.salt,
    iv: result.iv,
    tag: result.tag,
    keyId: generateSecureUUID()
  };
}
async function decryptNsec(encryptedData) {
  return await decryptSensitiveData({
    encrypted: encryptedData.encryptedNsec,
    salt: encryptedData.salt,
    iv: encryptedData.iv,
    tag: encryptedData.tag
  });
}
async function decryptNsecSimple(encryptedNsec, userSalt) {
  try {
    console.log("\u{1F510} decryptNsecSimple: Using Noble V2 implementation");
    console.log(
      "\u{1F510} decryptNsecSimple: Input encryptedNsec length:",
      encryptedNsec?.length
    );
    console.log(
      "\u{1F510} decryptNsecSimple: Input userSalt length:",
      userSalt?.length
    );
    if (!encryptedNsec || typeof encryptedNsec !== "string") {
      throw new Error("Invalid encryptedNsec: must be a non-empty string");
    }
    if (!userSalt || typeof userSalt !== "string") {
      throw new Error("Invalid userSalt: must be a non-empty string");
    }
    console.log("\u{1F510} decryptNsecSimple: Calling Noble V2 decryptNsec...");
    const result = await import_noble_encryption.NobleEncryption.decryptNsec(encryptedNsec, userSalt);
    console.log("\u{1F510} decryptNsecSimple: Noble V2 decryption successful");
    console.log(
      "\u{1F510} decryptNsecSimple: Result starts with 'nsec':",
      result.startsWith("nsec")
    );
    return result;
  } catch (error) {
    console.error("\u{1F510} decryptNsecSimple: Noble V2 decryption failed:", error);
    throw new Error(
      `Nsec decryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function decryptNsecBytes(encryptedNsec, userSalt) {
  try {
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(userSalt),
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );
    const salt = new TextEncoder().encode(userSalt);
    const decryptionKey = await crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt,
        iterations: ENCRYPTION_CONFIG.iterations,
        hash: "SHA-256"
      },
      keyMaterial,
      {
        name: ENCRYPTION_CONFIG.algorithm,
        length: ENCRYPTION_CONFIG.keyLength
      },
      false,
      ["decrypt"]
    );
    const encryptedBuffer = new Uint8Array(
      atob(encryptedNsec).split("").map((c) => c.charCodeAt(0))
    );
    const iv = encryptedBuffer.slice(0, ENCRYPTION_CONFIG.ivLength);
    const ciphertext = encryptedBuffer.slice(ENCRYPTION_CONFIG.ivLength);
    const decryptedBuffer = await crypto.subtle.decrypt(
      { name: ENCRYPTION_CONFIG.algorithm, iv },
      decryptionKey,
      ciphertext
    );
    return new Uint8Array(decryptedBuffer);
  } catch (error) {
    console.error("Failed to decrypt nsec to buffer:", error);
    throw new Error("Failed to decrypt nsec");
  }
}
async function encryptNsecSimple(nsec, userSalt) {
  try {
    console.log("\u{1F510} encryptNsecSimple: Using Noble V2 implementation");
    const result = await import_noble_encryption.NobleEncryption.encryptNsec(nsec, userSalt);
    console.log("\u{1F510} encryptNsecSimple: Noble V2 encryption successful");
    return result;
  } catch (error) {
    console.error("\u{1F510} encryptNsecSimple: Noble V2 encryption failed:", error);
    throw new Error(
      `Nsec encryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function encryptNpub(npub) {
  const result = await encryptSensitiveData(npub);
  return {
    encryptedNpub: result.encrypted,
    salt: result.salt,
    iv: result.iv,
    tag: result.tag
  };
}
async function decryptNpub(encryptedData) {
  return await decryptSensitiveData({
    encrypted: encryptedData.encryptedNpub,
    salt: encryptedData.salt,
    iv: encryptedData.iv,
    tag: encryptedData.tag
  });
}
function generateSecureFamilyId(familyName) {
  const familyUuid = generateSecureUUID();
  const familyId = familyName ? `${familyName.toLowerCase().replace(/[^a-z0-9]/g, "")}-${familyUuid.slice(
    0,
    8
  )}` : `family-${familyUuid.slice(0, 8)}`;
  const hash = btoa(familyId).slice(0, 16);
  return {
    familyId,
    familyUuid,
    hash
  };
}
function logPrivacyOperation(entry) {
  const auditEntry = {
    ...entry,
    id: generateSecureUUID(),
    timestamp: /* @__PURE__ */ new Date()
  };
  console.log("Privacy Audit:", auditEntry);
  return auditEntry;
}
function validateDataIntegrity(originalData, processedData, operation) {
  if (operation === "decrypt") {
    return originalData === processedData;
  }
  return true;
}
class SecureMemoryBuffer {
  buffer = null;
  view = null;
  isCleared = false;
  constructor(data) {
    if (typeof data === "string") {
      const encoder = new TextEncoder();
      const encoded = encoder.encode(data);
      this.buffer = encoded.buffer.slice(
        encoded.byteOffset,
        encoded.byteOffset + encoded.byteLength
      );
      this.view = new Uint8Array(this.buffer);
    } else if (data instanceof ArrayBuffer) {
      this.buffer = data.slice(0);
      this.view = new Uint8Array(this.buffer);
    } else if (data instanceof Uint8Array) {
      const sourceBuffer = data.buffer;
      this.buffer = sourceBuffer.slice(
        data.byteOffset,
        data.byteOffset + data.byteLength
      );
      this.view = new Uint8Array(this.buffer);
    }
  }
  /**
   * Get the data as string (only if not cleared)
   */
  toString() {
    if (this.isCleared || !this.view) {
      throw new Error("SecureMemoryBuffer has been cleared");
    }
    try {
      const decoder = new TextDecoder("utf-8", { fatal: true });
      return decoder.decode(this.view);
    } catch (error) {
      throw new Error(`Failed to decode SecureMemoryBuffer: ${error}`);
    }
  }
  /**
   * Get the data as ArrayBuffer (only if not cleared)
   */
  toArrayBuffer() {
    if (this.isCleared || !this.buffer) {
      throw new Error("SecureMemoryBuffer has been cleared");
    }
    return this.buffer.slice(0);
  }
  /**
   * Get the data as Uint8Array (only if not cleared)
   */
  toUint8Array() {
    if (this.isCleared || !this.view) {
      throw new Error("SecureMemoryBuffer has been cleared");
    }
    return new Uint8Array(this.view);
  }
  /**
   * Securely clear the buffer by overwriting with cryptographically secure random data
   * SECURITY: Multiple overwrites with different patterns for defense in depth
   */
  clear() {
    if (this.view && !this.isCleared) {
      try {
        crypto.getRandomValues(this.view);
        this.view.fill(0);
        this.view.fill(255);
        crypto.getRandomValues(this.view);
        this.buffer = null;
        this.view = null;
        this.isCleared = true;
        if (typeof window !== "undefined" && "gc" in window) {
          window.gc();
        }
      } catch (error) {
        console.warn("Secure memory clearing failed:", error);
        this.buffer = null;
        this.view = null;
        this.isCleared = true;
      }
    }
  }
  /**
   * Check if buffer has been cleared
   */
  get cleared() {
    return this.isCleared;
  }
  /**
   * Get buffer size in bytes
   */
  get size() {
    return this.isCleared || !this.view ? 0 : this.view.length;
  }
}
function secureClearMemory(targets) {
  targets.forEach((target) => {
    try {
      switch (target.type) {
        case "arraybuffer":
          if (target.data instanceof ArrayBuffer) {
            const view = new Uint8Array(target.data);
            crypto.getRandomValues(view);
            view.fill(0);
            view.fill(255);
            crypto.getRandomValues(view);
          }
          break;
        case "uint8array":
          if (target.data instanceof Uint8Array) {
            crypto.getRandomValues(target.data);
            target.data.fill(0);
            target.data.fill(255);
            crypto.getRandomValues(target.data);
          }
          break;
        case "string":
          if (typeof target.data === "string") {
            const encoder = new TextEncoder();
            const buffer = encoder.encode(target.data);
            crypto.getRandomValues(buffer);
            buffer.fill(0);
            buffer.fill(255);
            crypto.getRandomValues(buffer);
          }
          break;
      }
    } catch (error) {
      console.warn(
        `Failed to clear memory target of type ${target.type}:`,
        error
      );
    }
  });
  if (typeof window !== "undefined" && "gc" in window) {
    window.gc();
  }
}
function secureClearMemoryLegacy(sensitiveString) {
  secureClearMemory([{ data: sensitiveString, type: "string" }]);
}
async function doubleEncryptSensitiveData(plaintext) {
  try {
    const firstEncryption = await encryptSensitiveData(plaintext);
    const secondEncryption = await encryptSensitiveData(
      JSON.stringify(firstEncryption)
    );
    return {
      // First layer
      encrypted: firstEncryption.encrypted,
      salt: firstEncryption.salt,
      iv: firstEncryption.iv,
      tag: firstEncryption.tag,
      // Second layer
      doubleEncrypted: secondEncryption.encrypted,
      doubleSalt: secondEncryption.salt,
      doubleIv: secondEncryption.iv,
      doubleTag: secondEncryption.tag
    };
  } catch (error) {
    throw new Error(
      `Double encryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
async function doubleDecryptSensitiveData(encryptedData) {
  try {
    const outerDecrypted = await decryptSensitiveData({
      encrypted: encryptedData.doubleEncrypted,
      salt: encryptedData.doubleSalt,
      iv: encryptedData.doubleIv,
      tag: encryptedData.doubleTag
    });
    const innerEncryptionData = JSON.parse(outerDecrypted);
    const innerDecrypted = await decryptSensitiveData(innerEncryptionData);
    return innerDecrypted;
  } catch (error) {
    throw new Error(
      `Double decryption failed: ${error instanceof Error ? error.message : "Unknown error"}`
    );
  }
}
const PrivacyUtils = {
  generateSecureUUID,
  generateSalt,
  generateUniqueSalts,
  encryptSensitiveData,
  decryptSensitiveData,
  doubleEncryptSensitiveData,
  doubleDecryptSensitiveData,
  hashUsername,
  verifyUsername,
  encryptNsec,
  decryptNsec,
  decryptNsecSimple,
  encryptNsecSimple,
  encryptNpub,
  decryptNpub,
  generateSecureFamilyId,
  logPrivacyOperation,
  validateDataIntegrity,
  secureClearMemory,
  secureClearMemoryLegacy,
  SecureMemoryBuffer
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PrivacyUtils,
  SecureMemoryBuffer,
  decryptNpub,
  decryptNsec,
  decryptNsecBytes,
  decryptNsecSimple,
  decryptSensitiveData,
  doubleDecryptSensitiveData,
  doubleEncryptSensitiveData,
  encryptNpub,
  encryptNsec,
  encryptNsecSimple,
  encryptSensitiveData,
  generateSalt,
  generateSecureFamilyId,
  generateSecureUUID,
  generateUniqueSalts,
  hashUsername,
  logPrivacyOperation,
  secureClearMemory,
  secureClearMemoryLegacy,
  validateDataIntegrity,
  verifyUsername
});
