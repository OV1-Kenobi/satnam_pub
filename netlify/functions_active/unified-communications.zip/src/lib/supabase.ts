"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var supabase_exports = {};
__export(supabase_exports, {
  CitadelDatabase: () => CitadelDatabase,
  initializeConnectionMonitoring: () => initializeConnectionMonitoring,
  setSupabaseConfig: () => setSupabaseConfig,
  startConnectionMonitoring: () => startConnectionMonitoring,
  stopConnectionMonitoring: () => stopConnectionMonitoring,
  supabase: () => supabase
});
module.exports = __toCommonJS(supabase_exports);
var import_supabase_js = require("@supabase/supabase-js");
function getEnvVar(key, defaultValue = "") {
  if (typeof process !== "undefined" && process.env && typeof process.env[key] !== "undefined") {
    return process.env[key] || defaultValue;
  }
  if (typeof globalThis !== "undefined" && globalThis.__APP_ENV__) {
    const v = globalThis.__APP_ENV__[key];
    if (typeof v !== "undefined") return v;
  }
  return defaultValue;
}
const getSupabaseConfig = () => {
  const url = getEnvVar("VITE_SUPABASE_URL");
  const key = getEnvVar("VITE_SUPABASE_ANON_KEY");
  console.log("\u{1F50D} Supabase Environment Check:", {
    hasUrl: !!url,
    hasKey: !!key,
    urlLength: url ? url.length : 0,
    keyLength: key ? key.length : 0,
    environment: typeof window !== "undefined" ? "browser" : "node",
    processEnvAvailable: typeof process !== "undefined" && !!process.env,
    processEnvHasViteVars: typeof process !== "undefined" && !!process.env?.VITE_SUPABASE_URL
  });
  if (!url || !key) {
    const errorDetails = {
      hasUrl: !!url,
      hasKey: !!key,
      environment: typeof window !== "undefined" ? "browser" : "node",
      availableEnvVars: typeof process !== "undefined" && process.env ? Object.keys(process.env).filter((k) => k.startsWith("VITE_")) : []
    };
    console.error("\u274C Supabase credentials missing:", errorDetails);
    throw new Error(
      `CRITICAL: Bootstrap Supabase credentials missing. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables to access the Vault system. Environment: ${errorDetails.environment}, Available VITE_ vars: ${errorDetails.availableEnvVars.length}`
    );
  }
  return { url, key };
};
const config = getSupabaseConfig();
const supabaseUrl = config.url;
const supabaseKey = config.key;
if (typeof window !== "undefined") {
  if (!supabaseUrl || !supabaseKey) {
    throw new Error(
      "CRITICAL: Bootstrap Supabase credentials missing. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables."
    );
  }
  if (supabaseUrl.includes("your-project-ref") || supabaseKey.includes("your-anon-key")) {
    throw new Error(
      "CRITICAL: Placeholder Supabase credentials detected. Configure real bootstrap credentials in environment variables."
    );
  }
}
if (typeof window !== "undefined") {
  try {
    const url = new URL(supabaseUrl);
    if (url.protocol !== "https:") {
      throw new Error(`SECURITY: Supabase URL must use HTTPS: ${supabaseUrl}`);
    }
  } catch (error) {
    throw new Error(`CRITICAL: Invalid Supabase URL format: ${supabaseUrl}`);
  }
  if (!supabaseKey.startsWith("eyJ")) {
    throw new Error(
      "CRITICAL: Supabase anon key appears to be invalid (not a JWT token)"
    );
  }
}
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    flowType: "pkce",
    // Enhanced security with PKCE
    lock: async (_name, _acquireTimeout, fn) => await fn(),
    // Prevent concurrent session operations
    storageKey: "citadel-auth"
    // Custom storage key
  },
  global: {
    headers: {
      "x-client-info": "citadel-identity-forge@1.0.0",
      "x-security-level": "enhanced"
    }
  },
  db: {
    schema: "public"
  },
  realtime: {
    params: {
      eventsPerSecond: 10
      // Rate limiting
    },
    heartbeatIntervalMs: 3e4,
    // Connection health monitoring
    reconnectAfterMs: (tries) => Math.min(tries * 1e3, 3e4)
    // Exponential backoff
  }
});
function setSupabaseConfig(url, key) {
  if (typeof window !== "undefined") {
    const config2 = { url, key };
    localStorage.setItem("satnam_supabase_config", JSON.stringify(config2));
    window.location.reload();
  }
}
let connectionHealthCheck = null;
function startConnectionMonitoring() {
  if (connectionHealthCheck) return;
  connectionHealthCheck = setInterval(async () => {
    try {
      await supabase.from("privacy_users").select("hashed_uuid", { count: "exact", head: true });
    } catch (error) {
      console.error("\u{1F6A8} Supabase connection health check failed:", error);
    }
  }, 6e4);
}
function stopConnectionMonitoring() {
  if (connectionHealthCheck) {
    clearInterval(connectionHealthCheck);
    connectionHealthCheck = null;
  }
}
let monitoringInitialized = false;
function initializeConnectionMonitoring() {
  if (monitoringInitialized || typeof window === "undefined") return;
  monitoringInitialized = true;
  startConnectionMonitoring();
  window.addEventListener("beforeunload", () => {
    stopConnectionMonitoring();
  });
}
class CitadelDatabase {
  // Static methods for database operations
  static async query(sql, params) {
    return supabase.rpc("execute_sql", { query: sql, params });
  }
  static async from(table) {
    return supabase.from(table);
  }
  // Create privacy-first user profile
  static async createUserProfile(userData) {
    const { data, error } = await supabase.from("profiles").insert(userData).select().single();
    if (error) throw error;
    return data;
  }
  // Get family members
  static async getFamilyMembers(familyId) {
    const { data, error } = await supabase.from("profiles").select("*").eq("family_id", familyId);
    if (error) throw error;
    return data;
  }
  // Store Nostr event reference
  static async storeNostrBackup(userId, eventId) {
    const { data, error } = await supabase.from("nostr_backups").insert({
      user_id: userId,
      event_id: eventId,
      relay_url: "wss://relay.citadel.academy"
    });
    if (error) throw error;
    return data;
  }
  // Create a family
  static async createFamily(familyData) {
    const { data, error } = await supabase.from("families").insert(familyData).select().single();
    if (error) throw error;
    return data;
  }
  // Join a family
  static async joinFamily(userId, familyId) {
    const { data, error } = await supabase.from("profiles").update({ family_id: familyId }).eq("id", userId).select().single();
    if (error) throw error;
    return data;
  }
  // Set up lightning address
  static async setupLightningAddress(addressData) {
    await supabase.from("lightning_addresses").update({ active: false }).eq("user_id", addressData.user_id);
    const { data, error } = await supabase.from("lightning_addresses").insert({ ...addressData, active: true }).select().single();
    if (error) throw error;
    return data;
  }
  // Get complete user identity
  static async getUserIdentity(userId) {
    const { data: profile, error: profileError } = await supabase.from("profiles").select(
      `
        *,
        families(*),
        lightning_addresses(*),
        nostr_backups(*)
      `
    ).eq("id", userId).single();
    if (profileError) throw profileError;
    return profile;
  }
  // Get user backups
  static async getUserBackups(userId) {
    const { data, error } = await supabase.from("nostr_backups").select("*").eq("user_id", userId);
    if (error) throw error;
    return data;
  }
  // Get user lightning data
  static async getUserLightning(userId) {
    const { data, error } = await supabase.from("lightning_addresses").select("*").eq("user_id", userId);
    if (error) throw error;
    return data;
  }
  // Store encrypted private key (SECURITY: Atomic operation)
  static async storeEncryptedPrivateKey(userId, encryptedPrivateKey, encryptionMethod) {
    const { data, error } = await supabase.from("encrypted_keys").insert({
      user_id: userId,
      encrypted_private_key: encryptedPrivateKey,
      encryption_method: encryptionMethod,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    }).select().single();
    if (error) throw error;
    return data;
  }
  // Get encrypted private key for recovery (SECURITY: Authenticated only)
  static async getEncryptedPrivateKey(userId) {
    const { data, error } = await supabase.from("encrypted_keys").select("encrypted_private_key, encryption_method").eq("user_id", userId).order("created_at", { ascending: false }).limit(1).single();
    if (error) {
      if (error.code === "PGRST116") {
        return null;
      }
      throw error;
    }
    return {
      encrypted_key: data.encrypted_private_key,
      encryption_method: data.encryption_method
    };
  }
  // Get user by username (for availability checking)
  static async getUserByUsername(username) {
    const { data, error } = await supabase.from("profiles").select("id, username").eq("username", username).single();
    if (error) {
      if (error.code === "PGRST116") {
        return null;
      }
      throw error;
    }
    return data;
  }
  // Update lightning address with external service IDs (SECURITY: Atomic operation)
  static async updateLightningServiceIds(userId, updates) {
    const { data, error } = await supabase.from("lightning_addresses").update({
      ...updates,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("user_id", userId).eq("active", true).select().single();
    if (error) throw error;
    return data;
  }
  // Atomic lightning setup with rollback capability
  static async atomicLightningSetup(lightningData) {
    const { data, error } = await supabase.rpc("setup_lightning_atomic", {
      p_user_id: lightningData.user_id,
      p_address: lightningData.address,
      p_btcpay_store_id: lightningData.btcpay_store_id,
      p_voltage_node_id: lightningData.voltage_node_id,
      p_encrypted_btcpay_config: lightningData.encrypted_btcpay_config,
      p_encrypted_voltage_config: lightningData.encrypted_voltage_config,
      p_active: lightningData.active ?? true
    });
    if (error) throw error;
    return data;
  }
  // Get lightning address record for updates
  static async getLightningAddress(userId) {
    const { data, error } = await supabase.from("lightning_addresses").select("*").eq("user_id", userId).eq("active", true).single();
    if (error) {
      if (error.code === "PGRST116") {
        return null;
      }
      throw error;
    }
    return data;
  }
  // Validate NIP-05 and Lightning address consistency
  static async validateIdentifierConsistency(userId) {
    try {
      const profile = await this.getUserIdentity(userId);
      if (!profile) {
        return {
          isConsistent: false,
          issues: ["User profile not found"]
        };
      }
      const issues = [];
      const username = profile.username;
      const expectedIdentifier = `${username}@${getEnvVar(
        "VITE_LIGHTNING_DOMAIN",
        "satnam.pub"
      )}`;
      const lightningAddress = profile.lightning_addresses?.[0]?.address;
      if (lightningAddress && lightningAddress !== expectedIdentifier) {
        issues.push(
          `Lightning address mismatch: expected ${expectedIdentifier}, got ${lightningAddress}`
        );
      }
      return {
        isConsistent: issues.length === 0,
        nip05_identifier: expectedIdentifier,
        lightning_address: lightningAddress,
        username,
        issues
      };
    } catch (error) {
      return {
        isConsistent: false,
        issues: [
          `Validation error: ${error instanceof Error ? error.message : String(error)}`
        ]
      };
    }
  }
  // Fix inconsistent identifiers
  static async fixIdentifierConsistency(userId) {
    try {
      const validation = await this.validateIdentifierConsistency(userId);
      if (validation.isConsistent) {
        return {
          success: true,
          fixed_issues: ["No issues found - identifiers are consistent"]
        };
      }
      const fixedIssues = [];
      const profile = await this.getUserIdentity(userId);
      if (!profile) {
        throw new Error("User profile not found");
      }
      const correctIdentifier = `${profile.username}@${typeof process !== "undefined" && process.env?.VITE_LIGHTNING_DOMAIN || "satnam.pub"}`;
      const lightningAddress = profile.lightning_addresses?.[0];
      if (lightningAddress && lightningAddress.address !== correctIdentifier) {
        await this.updateLightningServiceIds(userId, {
          // Update the address to be consistent
        });
        const { error } = await supabase.from("lightning_addresses").update({
          address: correctIdentifier,
          updated_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("user_id", userId).eq("active", true);
        if (error) throw error;
        fixedIssues.push(`Updated Lightning address to: ${correctIdentifier}`);
      }
      return {
        success: true,
        fixed_issues: fixedIssues
      };
    } catch (error) {
      return {
        success: false,
        fixed_issues: [],
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CitadelDatabase,
  initializeConnectionMonitoring,
  setSupabaseConfig,
  startConnectionMonitoring,
  stopConnectionMonitoring,
  supabase
});
