"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var noble_encryption_exports = {};
__export(noble_encryption_exports, {
  NOBLE_CONFIG: () => NOBLE_CONFIG,
  NobleEncryption: () => NobleEncryption,
  NobleUtils: () => NobleUtils
});
module.exports = __toCommonJS(noble_encryption_exports);
var import_aes = require("@noble/ciphers/aes");
var import_webcrypto = require("@noble/ciphers/webcrypto");
var import_pbkdf2 = require("@noble/hashes/pbkdf2");
var import_sha256 = require("@noble/hashes/sha256");
var import_utils = require("@noble/curves/utils");
const NOBLE_CONFIG = {
  // AES-256-GCM Configuration
  keyLength: 32,
  // 256-bit keys
  ivLength: 12,
  // 96-bit IV for GCM
  tagLength: 16,
  // 128-bit authentication tag
  // PBKDF2 Configuration
  pbkdf2Iterations: 1e5,
  // NIST recommended minimum
  saltLength: 32,
  // 256-bit salt
  // Encoding
  encoding: "base64url"
  // URL-safe base64
};
class NobleEncryption {
  /**
   * Encrypt data using AES-256-GCM with PBKDF2 key derivation
   * @param plaintext Data to encrypt
   * @param password Password for key derivation
   * @returns Encryption result with all necessary parameters
   */
  static async encrypt(plaintext, password) {
    try {
      const salt = (0, import_webcrypto.randomBytes)(NOBLE_CONFIG.saltLength);
      const iv = (0, import_webcrypto.randomBytes)(NOBLE_CONFIG.ivLength);
      const key = (0, import_pbkdf2.pbkdf2)(import_sha256.sha256, password, salt, {
        c: NOBLE_CONFIG.pbkdf2Iterations,
        dkLen: NOBLE_CONFIG.keyLength
      });
      const cipher = (0, import_aes.gcm)(key, iv);
      const plainBytes = new TextEncoder().encode(plaintext);
      const encrypted = cipher.encrypt(plainBytes);
      return {
        encrypted: this.bytesToBase64Url(encrypted),
        salt: this.bytesToBase64Url(salt),
        iv: this.bytesToBase64Url(iv),
        version: "noble-v2"
      };
    } catch (error) {
      throw new Error(`Noble V2 encryption failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  /**
   * Decrypt data using AES-256-GCM with PBKDF2 key derivation
   * @param encryptionResult Result from encrypt() method
   * @param password Password for key derivation
   * @returns Decrypted plaintext
   */
  static async decrypt(encryptionResult, password) {
    try {
      const salt = this.base64UrlToBytes(encryptionResult.salt);
      const iv = this.base64UrlToBytes(encryptionResult.iv);
      const encrypted = this.base64UrlToBytes(encryptionResult.encrypted);
      const key = (0, import_pbkdf2.pbkdf2)(import_sha256.sha256, password, salt, {
        c: NOBLE_CONFIG.pbkdf2Iterations,
        dkLen: NOBLE_CONFIG.keyLength
      });
      const cipher = (0, import_aes.gcm)(key, iv);
      const decrypted = cipher.decrypt(encrypted);
      return new TextDecoder().decode(decrypted);
    } catch (error) {
      throw new Error(`Noble V2 decryption failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  /**
   * Encrypt nsec using user's unique salt (zero-knowledge)
   * @param nsec Nostr private key (bech32 format)
   * @param userSalt User's unique salt
   * @returns Single base64url string for database storage
   */
  static async encryptNsec(nsec, userSalt) {
    try {
      if (!nsec.startsWith("nsec1")) {
        throw new Error("Invalid nsec format - must start with nsec1");
      }
      const result = await this.encrypt(nsec, userSalt);
      return `${result.version}.${result.salt}.${result.iv}.${result.encrypted}`;
    } catch (error) {
      throw new Error(`Nsec encryption failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  /**
   * Decrypt nsec using user's unique salt (zero-knowledge)
   * @param encryptedNsec Encrypted nsec from database
   * @param userSalt User's unique salt
   * @returns Decrypted nsec in bech32 format
   */
  static async decryptNsec(encryptedNsec, userSalt) {
    try {
      const parts = encryptedNsec.split(".");
      if (parts.length !== 4 || parts[0] !== "noble-v2") {
        throw new Error("Invalid encrypted nsec format - expected noble-v2.salt.iv.encrypted");
      }
      const [version, salt, iv, encrypted] = parts;
      const encryptionResult = {
        encrypted,
        salt,
        iv,
        version: "noble-v2"
      };
      const decrypted = await this.decrypt(encryptionResult, userSalt);
      if (!decrypted.startsWith("nsec1")) {
        throw new Error("Decrypted data is not a valid nsec");
      }
      return decrypted;
    } catch (error) {
      throw new Error(`Nsec decryption failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  /**
   * Generate secure hash using SHA-256
   * @param data Data to hash
   * @param salt Optional salt
   * @returns Hex-encoded hash
   */
  static async hash(data, salt) {
    const input = salt ? data + salt : data;
    const hash = (0, import_sha256.sha256)(new TextEncoder().encode(input));
    return (0, import_utils.bytesToHex)(hash);
  }
  /**
   * Generate cryptographically secure random bytes
   * @param length Number of bytes to generate
   * @returns Random bytes
   */
  static generateRandomBytes(length) {
    return (0, import_webcrypto.randomBytes)(length);
  }
  /**
   * Generate secure random hex string
   * @param length Number of bytes (hex will be 2x this length)
   * @returns Hex string
   */
  static generateRandomHex(length) {
    return (0, import_utils.bytesToHex)(this.generateRandomBytes(length));
  }
  /**
   * Convert bytes to base64url (URL-safe base64)
   */
  static bytesToBase64Url(bytes) {
    return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
  /**
   * Convert base64url to bytes
   */
  static base64UrlToBytes(base64url) {
    const padding = "=".repeat((4 - base64url.length % 4) % 4);
    const base64 = base64url.replace(/-/g, "+").replace(/_/g, "/") + padding;
    return new Uint8Array(
      atob(base64).split("").map((c) => c.charCodeAt(0))
    );
  }
  /**
   * Secure memory cleanup (best effort)
   * @param sensitiveData Array of sensitive strings to clear
   */
  static secureWipe(sensitiveData) {
    sensitiveData.forEach((data) => {
      if (typeof data === "string") {
        try {
          data = "\0".repeat(data.length);
        } catch {
        }
      }
    });
    if (typeof window !== "undefined" && "gc" in window) {
      try {
        window.gc();
      } catch {
      }
    }
  }
}
const NobleUtils = {
  encrypt: NobleEncryption.encrypt.bind(NobleEncryption),
  decrypt: NobleEncryption.decrypt.bind(NobleEncryption),
  encryptNsec: NobleEncryption.encryptNsec.bind(NobleEncryption),
  decryptNsec: NobleEncryption.decryptNsec.bind(NobleEncryption),
  hash: NobleEncryption.hash.bind(NobleEncryption),
  generateRandomBytes: NobleEncryption.generateRandomBytes.bind(NobleEncryption),
  generateRandomHex: NobleEncryption.generateRandomHex.bind(NobleEncryption),
  secureWipe: NobleEncryption.secureWipe.bind(NobleEncryption)
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NOBLE_CONFIG,
  NobleEncryption,
  NobleUtils
});
