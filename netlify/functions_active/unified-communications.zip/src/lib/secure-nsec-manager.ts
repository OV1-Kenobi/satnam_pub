"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var secure_nsec_manager_exports = {};
__export(secure_nsec_manager_exports, {
  SecureNsecManager: () => SecureNsecManager,
  default: () => secure_nsec_manager_default,
  secureNsecManager: () => secureNsecManager
});
module.exports = __toCommonJS(secure_nsec_manager_exports);
class SecureNsecManager {
  static instance = null;
  temporarySession = null;
  cleanupTimer = null;
  MAX_SESSION_DURATION = 10 * 60 * 1e3;
  // 10 minutes
  MAX_OPERATIONS = 50;
  // Maximum operations per session
  enforceBrowserLifetime = false;
  constructor() {
  }
  static getInstance() {
    if (!SecureNsecManager.instance) {
      SecureNsecManager.instance = new SecureNsecManager();
    }
    return SecureNsecManager.instance;
  }
  /**
   * Create a post-registration nsec session for immediate peer invitations
   * This method is called AFTER Identity Forge completion and database storage
   * @param nsecHex - The nsec in hex format (retained from registration)
   * @param maxDurationMs - Maximum session duration (default: 10 minutes)
   * @returns Session ID for tracking
   */
  async createPostRegistrationSession(nsecInput, maxDurationMs, maxOperations, browserLifetime) {
    return await this.createTemporarySession(
      nsecInput,
      maxDurationMs,
      maxOperations,
      browserLifetime
    );
  }
  /**
   * Create a temporary nsec session (internal method)
   * @param nsecHex - The temporary nsec in hex format
   * @param maxDurationMs - Maximum session duration (default: 10 minutes)
   * @returns Session ID for tracking
   */
  async createTemporarySession(nsecInput, maxDurationMs, maxOperations, browserLifetime) {
    let nsecHex;
    if (/^nsec1/i.test(nsecInput)) {
      try {
        const { nip19 } = await import("nostr-tools");
        const decoded = nip19.decode(nsecInput);
        if (decoded.type !== "nsec") {
          throw new Error("Invalid nsec bech32 type");
        }
        const data = decoded.data;
        nsecHex = typeof data === "string" ? data : Array.from(data).map((b) => b.toString(16).padStart(2, "0")).join("");
      } catch (error) {
        throw new Error("Invalid nsec bech32 format");
      }
    } else if (/^[0-9a-fA-F]{64}$/.test(nsecInput)) {
      nsecHex = nsecInput.toLowerCase();
    } else {
      throw new Error(
        "Invalid nsec format - must be bech32 (nsec1...) or 64-character hex"
      );
    }
    this.clearTemporarySession();
    const sessionId = `nsec-session-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
    const duration = maxDurationMs || this.MAX_SESSION_DURATION;
    const now = Date.now();
    this.temporarySession = {
      nsecHex,
      createdAt: now,
      expiresAt: now + duration,
      sessionId,
      operationCount: 0,
      maxOperations: Math.max(1, maxOperations || this.MAX_OPERATIONS)
    };
    this.enforceBrowserLifetime = !!browserLifetime;
    if (!this.enforceBrowserLifetime) {
      this.cleanupTimer = window.setTimeout(() => {
        this.clearTemporarySession();
      }, duration);
    }
    return sessionId;
  }
  /**
   * Get the temporary nsec for signing operations
   * @param sessionId - Session ID to validate
   * @returns Nsec hex string or null if session invalid/expired
   */
  getTemporaryNsec(sessionId) {
    if (!this.temporarySession || this.temporarySession.sessionId !== sessionId) {
      return null;
    }
    const now = Date.now();
    if (now > this.temporarySession.expiresAt) {
      this.clearTemporarySession();
      return null;
    }
    if (this.temporarySession.operationCount >= this.temporarySession.maxOperations) {
      console.warn("\u26A0\uFE0F Temporary nsec session operation limit reached");
      this.clearTemporarySession();
      return null;
    }
    this.temporarySession.operationCount++;
    return this.temporarySession.nsecHex;
  }
  /**
   * Check if a temporary session is active and valid
   * @param sessionId - Session ID to check
   * @returns Session status information
   */
  getSessionStatus(sessionId) {
    if (!this.temporarySession) {
      return { active: false };
    }
    if (sessionId && this.temporarySession.sessionId !== sessionId) {
      return { active: false };
    }
    const now = Date.now();
    const expired = now > this.temporarySession.expiresAt;
    const operationsExceeded = this.temporarySession.operationCount >= this.temporarySession.maxOperations;
    if (expired || operationsExceeded) {
      this.clearTemporarySession();
      return { active: false };
    }
    return {
      active: true,
      remainingTime: this.temporarySession.expiresAt - now,
      remainingOperations: this.temporarySession.maxOperations - this.temporarySession.operationCount,
      sessionId: this.temporarySession.sessionId
    };
  }
  /**
   * Get the active session ID if there's a valid session
   * @returns Session ID string or null if no active session
   */
  getActiveSessionId() {
    if (!this.temporarySession) {
      return null;
    }
    const now = Date.now();
    const expired = now > this.temporarySession.expiresAt;
    const operationsExceeded = this.temporarySession.operationCount >= this.temporarySession.maxOperations;
    if (expired || operationsExceeded) {
      this.clearTemporarySession();
      return null;
    }
    return this.temporarySession.sessionId;
  }
  /**
   * Extend the current session duration
   * @param additionalMs - Additional milliseconds to extend
   * @returns Success status
   */
  extendSession(additionalMs) {
    if (!this.temporarySession) {
      return false;
    }
    const now = Date.now();
    if (now > this.temporarySession.expiresAt) {
      this.clearTemporarySession();
      return false;
    }
    this.temporarySession.expiresAt += additionalMs;
    if (this.cleanupTimer) {
      clearTimeout(this.cleanupTimer);
    }
    this.cleanupTimer = window.setTimeout(() => {
      this.clearTemporarySession();
    }, this.temporarySession.expiresAt - now);
    return true;
  }
  /**
   * Clear the temporary session and secure memory cleanup
   */
  clearTemporarySession() {
    if (this.temporarySession) {
      this.secureWipe([
        {
          data: this.temporarySession.nsecHex,
          type: "string"
        }
      ]);
      this.temporarySession = null;
    }
    if (this.cleanupTimer) {
      clearTimeout(this.cleanupTimer);
      this.cleanupTimer = null;
    }
  }
  /**
   * Perform secure memory wipe of sensitive data
   * @param targets - Array of memory targets to wipe
   */
  secureWipe(targets) {
    for (const target of targets) {
      try {
        if (target.type === "string" && typeof target.data === "string") {
          target.data = "";
        } else if (target.type === "uint8array" && target.data instanceof Uint8Array) {
          target.data.fill(0);
        }
      } catch (error) {
        console.warn("Failed to securely wipe memory target:", error);
      }
    }
  }
  /**
   * Use temporary nsec for a specific operation with automatic cleanup
   * @param sessionId - Session ID
   * @param operation - Operation to perform with the nsec
   * @returns Operation result
   */
  async useTemporaryNsec(sessionId, operation) {
    const nsecHex = this.getTemporaryNsec(sessionId);
    if (!nsecHex) {
      throw new Error("Temporary nsec session not available or expired");
    }
    try {
      const result = await operation(nsecHex);
      return result;
    } finally {
    }
  }
  /**
   * Create multiple invitations in batch while nsec is available
   * @param sessionId - Session ID
   * @param invitationConfigs - Array of invitation configurations
   * @param createInvitation - Function to create a single invitation
   * @returns Array of invitation results
   */
  async createBatchInvitations(sessionId, invitationConfigs, createInvitation) {
    const results = [];
    for (const config of invitationConfigs) {
      const nsecHex = this.getTemporaryNsec(sessionId);
      if (!nsecHex) {
        throw new Error(
          `Temporary nsec session expired during batch operation (completed ${results.length}/${invitationConfigs.length})`
        );
      }
      try {
        const result = await createInvitation(config, nsecHex);
        results.push(result);
      } catch (error) {
        console.error("Batch invitation creation failed:", error);
        results.push({
          success: false,
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
    return results;
  }
  /**
   * Get remaining session time in human-readable format
   * @param sessionId - Session ID
   * @returns Formatted time string
   */
  getFormattedRemainingTime(sessionId) {
    const status = this.getSessionStatus(sessionId);
    if (!status.active || !status.remainingTime) {
      return "Session expired";
    }
    const minutes = Math.floor(status.remainingTime / 6e4);
    const seconds = Math.floor(status.remainingTime % 6e4 / 1e3);
    if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  }
  /**
   * Cleanup on page unload or component unmount
   */
  cleanup() {
    this.clearTemporarySession();
  }
}
const secureNsecManager = SecureNsecManager.getInstance();
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    secureNsecManager.cleanup();
  });
}
var secure_nsec_manager_default = secureNsecManager;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SecureNsecManager,
  secureNsecManager
});
