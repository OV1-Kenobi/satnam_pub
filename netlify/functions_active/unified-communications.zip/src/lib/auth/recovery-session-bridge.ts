"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var recovery_session_bridge_exports = {};
__export(recovery_session_bridge_exports, {
  RecoverySessionBridge: () => RecoverySessionBridge,
  createRecoverySession: () => createRecoverySession,
  default: () => recovery_session_bridge_default,
  isRecoverySessionAvailable: () => isRecoverySessionAvailable,
  recoverySessionBridge: () => recoverySessionBridge
});
module.exports = __toCommonJS(recovery_session_bridge_exports);
var import_nsec_session_bridge = require("./nsec-session-bridge");
var import_user_identities_auth = require("./user-identities-auth");
class RecoverySessionBridge {
  static instance = null;
  DEFAULT_SESSION_DURATION = 15 * 60 * 1e3;
  // 15 minutes
  DEFAULT_MAX_OPERATIONS = 50;
  constructor() {
  }
  static getInstance() {
    if (!RecoverySessionBridge.instance) {
      RecoverySessionBridge.instance = new RecoverySessionBridge();
    }
    return RecoverySessionBridge.instance;
  }
  /**
   * Create a temporary signing session using recovery credentials
   * This is the main integration point for Individual users
   *
   * @param credentials - NIP-05/password or npub/password credentials
   * @param options - Session configuration options
   * @returns Promise<RecoverySessionResult>
   */
  async createSessionFromRecovery(credentials, options = {}) {
    try {
      console.log(
        "\u{1F510} RecoverySessionBridge: Creating session from recovery credentials"
      );
      const authResult = await this.authenticateForRecovery(credentials);
      const userFromAuth = authResult?.user || authResult?.data?.user || null;
      if (!authResult.success || !userFromAuth) {
        return {
          success: false,
          error: "Authentication failed",
          userMessage: "Invalid credentials. Please check your NIP-05/password and try again."
        };
      }
      console.log(
        "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: Retrieving user data"
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: userFromAuth keys:",
        Object.keys(userFromAuth || {})
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: userFromAuth has encrypted_nsec:",
        !!userFromAuth?.encrypted_nsec
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: userFromAuth has user_salt:",
        !!userFromAuth?.user_salt
      );
      let fullUser = null;
      try {
        if (userFromAuth?.encrypted_nsec && userFromAuth?.user_salt) {
          console.log(
            "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: Using userFromAuth directly"
          );
          fullUser = userFromAuth;
        } else if (userFromAuth?.id) {
          console.log(
            "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: Fetching full user by ID:",
            userFromAuth.id
          );
          fullUser = await import_user_identities_auth.userIdentitiesAuth.getUserById(userFromAuth.id);
          console.log(
            "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: Retrieved fullUser keys:",
            Object.keys(fullUser || {})
          );
          console.log(
            "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: fullUser has encrypted_nsec:",
            !!fullUser?.encrypted_nsec
          );
          console.log(
            "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: fullUser has user_salt:",
            !!fullUser?.user_salt
          );
        }
      } catch (e) {
        console.error(
          "\u{1F510} RecoverySessionBridge.createSessionFromRecovery: Error retrieving user data:",
          e
        );
      }
      if (!fullUser) {
        return {
          success: false,
          error: "User record not found",
          userMessage: "Unable to locate your account details. Please try again."
        };
      }
      const nsecHex = await this.decryptUserNsec(fullUser);
      if (!nsecHex) {
        return {
          success: false,
          error: "Failed to decrypt nsec",
          userMessage: "Unable to access your private key. Please contact support if this persists."
        };
      }
      let sessionId = null;
      try {
        const { userSigningPreferences } = await import("../user-signing-preferences");
        const prefs = await userSigningPreferences.getUserPreferences();
        const duration = (prefs?.sessionDurationMinutes ?? 15) * 60 * 1e3;
        const maxOps = prefs?.maxOperationsPerSession ?? this.DEFAULT_MAX_OPERATIONS;
        const browserLifetime = prefs?.sessionLifetimeMode === "browser_session";
        sessionId = await import_nsec_session_bridge.nsecSessionBridge.initializeAfterAuth(nsecHex, {
          duration,
          maxOperations: maxOps,
          browserLifetime
        });
        if (!sessionId) throw new Error("No session created");
      } catch (e) {
        sessionId = await import_nsec_session_bridge.nsecSessionBridge.initializeAfterAuth(nsecHex, {
          duration: options.duration || this.DEFAULT_SESSION_DURATION,
          maxOperations: options.maxOperations || this.DEFAULT_MAX_OPERATIONS
        });
        if (!sessionId) {
          return {
            success: false,
            error: "Failed to create session",
            userMessage: "Unable to create signing session. Please try again."
          };
        }
      }
      const ensuredSessionId = sessionId;
      if (!ensuredSessionId) {
        return {
          success: false,
          error: "Failed to create session",
          userMessage: "Unable to create signing session. Please try again."
        };
      }
      const expiresAt = new Date(
        Date.now() + (options.duration || this.DEFAULT_SESSION_DURATION)
      );
      console.log("\u{1F510} RecoverySessionBridge: Session created successfully:", {
        sessionId: ensuredSessionId.substring(0, 8) + "...",
        expiresAt: expiresAt.toISOString(),
        duration: options.duration || this.DEFAULT_SESSION_DURATION
      });
      return {
        success: true,
        sessionId: ensuredSessionId,
        expiresAt,
        securityLevel: "high",
        userMessage: `Secure signing session created. Valid for ${Math.round(
          (options.duration || this.DEFAULT_SESSION_DURATION) / 6e4
        )} minutes.`
      };
    } catch (error) {
      console.error(
        "\u{1F510} RecoverySessionBridge: Session creation failed:",
        error
      );
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        userMessage: "Failed to create signing session. Please try again or contact support."
      };
    }
  }
  /**
   * Check if recovery-based session creation is available for current user
   * @returns Promise<boolean>
   */
  async isRecoverySessionAvailable() {
    try {
      return true;
    } catch (error) {
      console.error(
        "\u{1F510} RecoverySessionBridge: Availability check failed:",
        error
      );
      return false;
    }
  }
  /**
   * Create a recovery session directly from an authenticated user object
   * Skips re-authentication and proceeds to decryption and session init
   */
  async createRecoverySessionFromUser(user, options = {}) {
    try {
      console.log(
        "\u{1F510} RecoverySessionBridge: STARTING session creation from user object"
      );
      const userAny = user;
      console.log("\u{1F510} RecoverySessionBridge: COMPREHENSIVE user analysis:", {
        // Basic user info
        userId: user?.id?.substring(0, 8) || "MISSING",
        nip05: userAny?.nip05 || "MISSING",
        username: userAny?.username || "MISSING",
        role: user?.role || "MISSING",
        // Critical encrypted credentials
        hasUserSalt: !!user?.user_salt,
        hasEncryptedNsec: !!userAny?.encrypted_nsec,
        hasEncryptedNsecIv: !!userAny?.encrypted_nsec_iv,
        hasNpub: !!userAny?.npub,
        // Field lengths for debugging
        userSaltLength: user?.user_salt?.length || 0,
        encryptedNsecLength: userAny?.encrypted_nsec?.length || 0,
        encryptedNsecIvLength: userAny?.encrypted_nsec_iv?.length || 0,
        npubLength: userAny?.npub?.length || 0,
        // Complete object structure
        availableUserFields: Object.keys(user || {}),
        userObjectType: typeof user,
        isUserNull: user === null,
        isUserUndefined: user === void 0
      });
      console.log("\u{1F510} RecoverySessionBridge: Field previews:", {
        userSaltPreview: user?.user_salt ? `${user.user_salt.substring(0, 8)}...` : "MISSING",
        encryptedNsecPreview: userAny?.encrypted_nsec ? `${userAny.encrypted_nsec.substring(0, 8)}...` : "MISSING",
        npubPreview: userAny?.npub ? `${userAny.npub.substring(0, 8)}...` : "MISSING"
      });
      console.log(
        "\u{1F510} RecoverySessionBridge: STEP 1 - Validating required fields"
      );
      const hasUserSalt = !!user?.user_salt;
      const hasEncryptedNsec = !!user?.encrypted_nsec;
      console.log("\u{1F510} RecoverySessionBridge: Field validation results:", {
        hasUserSalt,
        hasEncryptedNsec,
        userSaltType: typeof user?.user_salt,
        encryptedNsecType: typeof user?.encrypted_nsec,
        userSaltTruthy: user?.user_salt ? "truthy" : "falsy",
        encryptedNsecTruthy: user?.encrypted_nsec ? "truthy" : "falsy"
      });
      if (!hasUserSalt || !hasEncryptedNsec) {
        console.error(
          "\u{1F510} RecoverySessionBridge: CRITICAL - Missing required fields for session creation"
        );
        console.error(
          "\u{1F510} RecoverySessionBridge: user_salt present:",
          hasUserSalt
        );
        console.error(
          "\u{1F510} RecoverySessionBridge: encrypted_nsec present:",
          hasEncryptedNsec
        );
        console.error(
          "\u{1F510} RecoverySessionBridge: This will prevent SecureNsecManager session creation"
        );
        return {
          success: false,
          error: "Missing encrypted nsec or user salt",
          userMessage: "Unable to access your private key. Please contact support if this persists."
        };
      }
      console.log(
        "\u{1F510} RecoverySessionBridge: \u2705 Required fields validation passed"
      );
      console.log(
        "\u{1F510} RecoverySessionBridge: STEP 2 - Starting nsec decryption"
      );
      console.log(
        "\u{1F510} RecoverySessionBridge: Calling decryptUserNsec with user object..."
      );
      let nsecHex = null;
      try {
        nsecHex = await this.decryptUserNsec(user);
        console.log(
          "\u{1F510} RecoverySessionBridge: decryptUserNsec completed, result:",
          {
            success: !!nsecHex,
            nsecLength: nsecHex?.length || 0,
            nsecType: typeof nsecHex,
            nsecPreview: nsecHex ? `${nsecHex.substring(0, 8)}...` : "NULL/EMPTY"
          }
        );
      } catch (decryptError) {
        console.error(
          "\u{1F510} RecoverySessionBridge: CRITICAL - Nsec decryption threw exception:",
          {
            error: decryptError instanceof Error ? decryptError.message : String(decryptError),
            stack: decryptError instanceof Error ? decryptError.stack : "No stack trace"
          }
        );
        return {
          success: false,
          error: "Failed to decrypt nsec - exception thrown",
          userMessage: "Unable to access your private key. Please contact support if this persists."
        };
      }
      if (!nsecHex) {
        console.error(
          "\u{1F510} RecoverySessionBridge: CRITICAL - Nsec decryption returned null/empty"
        );
        console.error(
          "\u{1F510} RecoverySessionBridge: This will prevent SecureNsecManager session creation"
        );
        return {
          success: false,
          error: "Failed to decrypt nsec",
          userMessage: "Unable to access your private key. Please contact support if this persists."
        };
      }
      console.log(
        "\u{1F510} RecoverySessionBridge: \u2705 Nsec decryption successful, length:",
        nsecHex.length
      );
      console.log(
        "\u{1F510} RecoverySessionBridge: STEP 3 - Creating SecureNsecManager session"
      );
      let sessionId = null;
      try {
        console.log(
          "\u{1F510} RecoverySessionBridge: Loading user signing preferences..."
        );
        const { userSigningPreferences } = await import("../user-signing-preferences");
        const prefs = await userSigningPreferences.getUserPreferences();
        const duration = (prefs?.sessionDurationMinutes ?? 15) * 60 * 1e3;
        const maxOps = prefs?.maxOperationsPerSession ?? this.DEFAULT_MAX_OPERATIONS;
        const browserLifetime = prefs?.sessionLifetimeMode === "browser_session";
        console.log("\u{1F510} RecoverySessionBridge: Session configuration loaded:", {
          duration,
          maxOps,
          browserLifetime,
          prefsLoaded: !!prefs,
          sessionDurationMinutes: prefs?.sessionDurationMinutes,
          maxOperationsPerSession: prefs?.maxOperationsPerSession,
          sessionLifetimeMode: prefs?.sessionLifetimeMode
        });
        console.log(
          "\u{1F510} RecoverySessionBridge: Calling nsecSessionBridge.initializeAfterAuth..."
        );
        console.log(
          "\u{1F510} RecoverySessionBridge: nsecHex length:",
          nsecHex.length
        );
        console.log(
          "\u{1F510} RecoverySessionBridge: nsecSessionBridge available:",
          !!import_nsec_session_bridge.nsecSessionBridge
        );
        sessionId = await import_nsec_session_bridge.nsecSessionBridge.initializeAfterAuth(nsecHex, {
          duration,
          maxOperations: maxOps,
          browserLifetime
        });
        console.log(
          "\u{1F510} RecoverySessionBridge: nsecSessionBridge.initializeAfterAuth completed:",
          {
            sessionId,
            sessionIdType: typeof sessionId,
            sessionIdLength: sessionId?.length || 0,
            success: !!sessionId
          }
        );
        if (!sessionId) {
          console.error(
            "\u{1F510} RecoverySessionBridge: CRITICAL - nsecSessionBridge.initializeAfterAuth returned null/empty"
          );
          throw new Error(
            "No session created - initializeAfterAuth returned null"
          );
        }
        console.log(
          "\u{1F510} RecoverySessionBridge: \u2705 Session creation successful, sessionId:",
          sessionId
        );
      } catch (e) {
        console.warn(
          "\u{1F510} RecoverySessionBridge: User preferences failed, using defaults:",
          e
        );
        console.log("\u{1F510} RecoverySessionBridge: Fallback session config:", {
          duration: options.duration || this.DEFAULT_SESSION_DURATION,
          maxOperations: options.maxOperations || this.DEFAULT_MAX_OPERATIONS
        });
        sessionId = await import_nsec_session_bridge.nsecSessionBridge.initializeAfterAuth(nsecHex, {
          duration: options.duration || this.DEFAULT_SESSION_DURATION,
          maxOperations: options.maxOperations || this.DEFAULT_MAX_OPERATIONS
        });
        console.log(
          "\u{1F510} RecoverySessionBridge: Fallback nsecSessionBridge.initializeAfterAuth result:",
          sessionId
        );
      }
      const ensuredSessionId = sessionId;
      if (!ensuredSessionId) {
        console.error(
          "\u{1F510} RecoverySessionBridge: Session creation failed - no session ID returned"
        );
        return {
          success: false,
          error: "Failed to create session",
          userMessage: "Unable to create signing session. Please try again."
        };
      }
      console.log(
        "\u{1F510} RecoverySessionBridge: Session created successfully:",
        ensuredSessionId
      );
      const expiresAt = new Date(
        Date.now() + (options.duration || this.DEFAULT_SESSION_DURATION)
      );
      return {
        success: true,
        sessionId: ensuredSessionId,
        expiresAt,
        securityLevel: "high",
        userMessage: `Secure signing session created. Valid for ${Math.round(
          (options.duration || this.DEFAULT_SESSION_DURATION) / 6e4
        )} minutes.`
      };
    } catch (error) {
      console.error(
        "\u{1F510} RecoverySessionBridge: Session creation from user failed:",
        error
      );
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        userMessage: "Failed to create signing session. Please try again or contact support."
      };
    }
  }
  /**
   * Get current recovery session status
   * @returns Session status information
   */
  getRecoverySessionStatus() {
    const sessionStatus = import_nsec_session_bridge.nsecSessionBridge.getSessionStatus();
    return {
      ...sessionStatus,
      createdViaRecovery: true
      // Mark sessions created via recovery
    };
  }
  /**
   * Authenticate user for recovery session creation
   * @private
   */
  async authenticateForRecovery(credentials) {
    try {
      return await import_user_identities_auth.userIdentitiesAuth.authenticateNIP05Password({
        nip05: credentials.nip05,
        password: credentials.password
      });
    } catch (error) {
      console.error("\u{1F510} RecoverySessionBridge: Authentication failed:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Authentication failed"
      };
    }
  }
  /**
   * Decrypt user's nsec using their salt
   * @private
   */
  async decryptUserNsec(user) {
    try {
      console.log(
        "\u{1F510} RecoverySessionBridge.decryptUserNsec: Starting nsec decryption"
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.decryptUserNsec: User object keys:",
        Object.keys(user || {})
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.decryptUserNsec: Has encrypted_nsec:",
        !!user?.encrypted_nsec
      );
      console.log(
        "\u{1F510} RecoverySessionBridge.decryptUserNsec: Has user_salt:",
        !!user?.user_salt
      );
      if (user.encrypted_nsec && user.user_salt) {
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: encrypted_nsec type:",
          typeof user.encrypted_nsec
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: encrypted_nsec length:",
          user.encrypted_nsec?.length
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: encrypted_nsec first 50 chars:",
          user.encrypted_nsec?.substring(0, 50)
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: user_salt type:",
          typeof user.user_salt
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: user_salt length:",
          user.user_salt?.length
        );
        const { decryptNsecSimple } = await import("../privacy/encryption");
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: Calling decryptNsecSimple..."
        );
        const decrypted = await decryptNsecSimple(
          user.encrypted_nsec,
          user.user_salt
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: Decryption successful"
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: Decrypted result length:",
          decrypted?.length
        );
        console.log(
          "\u{1F510} RecoverySessionBridge.decryptUserNsec: Decrypted starts with 'nsec':",
          decrypted?.startsWith("nsec")
        );
        return decrypted;
      }
      console.error(
        "\u{1F510} RecoverySessionBridge: Missing encrypted nsec or user salt"
      );
      console.error(
        "\u{1F510} RecoverySessionBridge: encrypted_nsec:",
        user?.encrypted_nsec
      );
      console.error("\u{1F510} RecoverySessionBridge: user_salt:", user?.user_salt);
      return null;
    } catch (error) {
      console.error("\u{1F510} RecoverySessionBridge: Nsec decryption failed:", error);
      return null;
    }
  }
  /**
   * Clear any active recovery session
   */
  clearRecoverySession() {
    console.log("\u{1F510} RecoverySessionBridge: Clearing recovery session");
    import_nsec_session_bridge.nsecSessionBridge.clearSession();
  }
  /**
   * Extend current recovery session duration
   * @param additionalMs - Additional milliseconds to extend
   * @returns boolean indicating success
   */
  extendRecoverySession(additionalMs = 15 * 60 * 1e3) {
    console.log("\u{1F510} RecoverySessionBridge: Extending recovery session");
    return import_nsec_session_bridge.nsecSessionBridge.extendSession(additionalMs);
  }
}
const recoverySessionBridge = RecoverySessionBridge.getInstance();
async function createRecoverySession(credentials, options) {
  return await recoverySessionBridge.createSessionFromRecovery(
    credentials,
    options
  );
}
async function isRecoverySessionAvailable() {
  return await recoverySessionBridge.isRecoverySessionAvailable();
}
var recovery_session_bridge_default = RecoverySessionBridge;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RecoverySessionBridge,
  createRecoverySession,
  isRecoverySessionAvailable,
  recoverySessionBridge
});
