"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var secure_token_manager_exports = {};
__export(secure_token_manager_exports, {
  EnvelopeEncryptionService: () => EnvelopeEncryptionService,
  IdentifierProtectionService: () => IdentifierProtectionService,
  SecureTokenManager: () => SecureTokenManager,
  default: () => secure_token_manager_default
});
module.exports = __toCommonJS(secure_token_manager_exports);
let currentAccessToken = null;
let accessTokenExpiry = null;
const TOKEN_CONFIG = {
  ACCESS_TOKEN_LIFETIME: 15 * 60 * 1e3,
  // 15 minutes
  REFRESH_TOKEN_LIFETIME: 7 * 24 * 60 * 60 * 1e3,
  // 7 days
  COOKIE_NAME: "satnam_refresh_token",
  ROTATION_THRESHOLD: 5 * 60 * 1e3
  // Rotate if token expires in 5 minutes
};
class IdentifierProtectionService {
  static pepper = null;
  /**
   * Initialize the service with a secure pepper from environment
   * OPTIMIZATION: Use client-side fallback to avoid server dependency
   */
  static async initialize() {
    try {
      this.pepper = "client-side-identifier-protection-fallback";
      console.log(
        "\u{1F510} Identifier Protection Service initialized (client-side mode)"
      );
    } catch (error) {
      console.error("Failed to initialize identifier protection:", error);
      throw error;
    }
  }
  /**
   * Generate protected identifier: HMAC-SHA256(pepper, uuid + salt)
   */
  static async generateProtectedId(uuid, salt) {
    if (!this.pepper) {
      throw new Error("Identifier protection service not initialized");
    }
    const message = uuid + (salt || "");
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(this.pepper),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await crypto.subtle.sign(
      "HMAC",
      key,
      new TextEncoder().encode(message)
    );
    return Array.from(new Uint8Array(signature)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  /**
   * Verify protected identifier
   */
  static async verifyProtectedId(uuid, hashedId, salt) {
    try {
      const expectedHash = await this.generateProtectedId(uuid, salt);
      if (expectedHash.length !== hashedId.length) {
        return false;
      }
      let result = 0;
      for (let i = 0; i < expectedHash.length; i++) {
        result |= expectedHash.charCodeAt(i) ^ hashedId.charCodeAt(i);
      }
      return result === 0;
    } catch (error) {
      console.error("Failed to verify protected identifier:", error);
      return false;
    }
  }
}
class EnvelopeEncryptionService {
  static ALGORITHM = "AES-GCM";
  static KEY_LENGTH = 256;
  static IV_LENGTH = 12;
  // 96 bits for GCM
  static TAG_LENGTH = 16;
  // 128 bits for GCM
  /**
   * Generate a new encryption key
   */
  static async generateKey() {
    return await crypto.subtle.generateKey(
      {
        name: this.ALGORITHM,
        length: this.KEY_LENGTH
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  /**
   * Encrypt data with envelope encryption
   * Returns: { encryptedData, encryptedKey, iv }
   */
  static async encryptWithEnvelope(data, masterKey) {
    const dataKey = await this.generateKey();
    const dataKeyBuffer = await crypto.subtle.exportKey("raw", dataKey);
    const iv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
    const encryptedDataBuffer = await crypto.subtle.encrypt(
      { name: this.ALGORITHM, iv },
      dataKey,
      new TextEncoder().encode(data)
    );
    const masterIv = crypto.getRandomValues(new Uint8Array(this.IV_LENGTH));
    const encryptedKeyBuffer = await crypto.subtle.encrypt(
      { name: this.ALGORITHM, iv: masterIv },
      masterKey,
      dataKeyBuffer
    );
    return {
      encryptedData: this.bufferToHex(encryptedDataBuffer),
      encryptedKey: this.bufferToHex(
        new Uint8Array([...masterIv, ...new Uint8Array(encryptedKeyBuffer)])
      ),
      iv: this.bufferToHex(iv)
    };
  }
  /**
   * Decrypt data with envelope encryption
   */
  static async decryptWithEnvelope(encryptedData, encryptedKey, iv, masterKey) {
    const encryptedKeyBuffer = this.hexToBuffer(encryptedKey);
    const masterIv = encryptedKeyBuffer.slice(0, this.IV_LENGTH);
    const encryptedDEK = encryptedKeyBuffer.slice(this.IV_LENGTH);
    const dataKeyBuffer = await crypto.subtle.decrypt(
      { name: this.ALGORITHM, iv: masterIv },
      masterKey,
      encryptedDEK
    );
    const dataKey = await crypto.subtle.importKey(
      "raw",
      dataKeyBuffer,
      { name: this.ALGORITHM },
      false,
      ["decrypt"]
    );
    const decryptedBuffer = await crypto.subtle.decrypt(
      { name: this.ALGORITHM, iv: this.hexToBuffer(iv) },
      dataKey,
      this.hexToBuffer(encryptedData)
    );
    return new TextDecoder().decode(decryptedBuffer);
  }
  static bufferToHex(buffer) {
    return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  static hexToBuffer(hex) {
    const bytes = [];
    for (let i = 0; i < hex.length; i += 2) {
      bytes.push(parseInt(hex.substr(i, 2), 16));
    }
    return new Uint8Array(bytes);
  }
}
class SecureTokenManager {
  static initialized = false;
  /**
   * Initialize the secure token manager
   */
  static async initialize() {
    if (this.initialized) return;
    try {
      await IdentifierProtectionService.initialize();
      this.initialized = true;
      console.log("\u{1F510} Secure Token Manager initialized");
    } catch (error) {
      console.error("Failed to initialize Secure Token Manager:", error);
      throw error;
    }
  }
  /**
   * Get current access token (from memory)
   */
  static getAccessToken() {
    const now = Date.now();
    const hasToken = !!currentAccessToken && !!accessTokenExpiry;
    const expiresIn = accessTokenExpiry ? accessTokenExpiry - now : null;
    console.log("\u{1F5DD}\uFE0F STM:getAccessToken", { hasToken, expiresInMs: expiresIn });
    if (!currentAccessToken || !accessTokenExpiry) {
      return null;
    }
    if (now >= accessTokenExpiry) {
      console.warn("\u{1F5DD}\uFE0F STM:getAccessToken token expired, clearing");
      this.clearAccessToken();
      return null;
    }
    return currentAccessToken;
  }
  /**
   * Set access token in memory with expiry
   */
  static setAccessToken(token, expiryMs) {
    currentAccessToken = token;
    accessTokenExpiry = expiryMs;
  }
  /**
   * Clear access token from memory
   */
  static clearAccessToken() {
    currentAccessToken = null;
    accessTokenExpiry = null;
  }
  /**
   * Check if access token needs refresh
   */
  static needsRefresh() {
    if (!accessTokenExpiry) return true;
    return accessTokenExpiry - Date.now() < TOKEN_CONFIG.ROTATION_THRESHOLD;
  }
  /**
   * Refresh tokens using HttpOnly refresh cookie
   */
  static async refreshTokens() {
    try {
      const response = await fetch("/api/auth/refresh", {
        method: "POST",
        credentials: "include",
        // Include HttpOnly cookies
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        if (response.status === 401) {
          await this.logout();
          return null;
        }
        throw new Error(`Token refresh failed: ${response.statusText}`);
      }
      const tokens = await response.json();
      this.setAccessToken(tokens.accessToken, tokens.accessTokenExpiry);
      console.log("\u{1F504} Tokens refreshed successfully");
      return tokens;
    } catch (error) {
      console.error("Token refresh failed:", error);
      await this.logout();
      return null;
    }
  }
  /**
   * Silent token refresh - automatically refresh if needed
   */
  static async silentRefresh() {
    const currentToken = this.getAccessToken();
    if (currentToken && !this.needsRefresh()) {
      return currentToken;
    }
    const refreshedTokens = await this.refreshTokens();
    return refreshedTokens?.accessToken || null;
  }
  /**
   * Logout - clear all tokens and cookies
   */
  static async logout() {
    try {
      this.clearAccessToken();
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include"
      });
      console.log("\u{1F6AA} Logout completed");
    } catch (error) {
      console.error("Logout error:", error);
      this.clearAccessToken();
    }
  }
  /**
   * Validate token format and extract payload (without verification)
   */
  static parseTokenPayload(token) {
    try {
      const parts = token.split(".");
      if (parts.length !== 3) return null;
      const b64url = parts[1];
      const b64 = b64url.replace(/-/g, "+").replace(/_/g, "/").padEnd(b64url.length + (4 - b64url.length % 4) % 4, "=");
      const payloadJson = atob(b64);
      const payload = JSON.parse(payloadJson);
      if (!payload.hashedId || !payload.exp || !payload.type) {
        return null;
      }
      return payload;
    } catch (error) {
      console.error(
        "Invalid token format:",
        error instanceof Error ? error.message : String(error)
      );
      return null;
    }
  }
  /**
   * Check if refresh is available (refresh cookie exists)
   */
  static async checkRefreshAvailable() {
    try {
      const response = await fetch("/api/auth/check-refresh", {
        method: "GET",
        credentials: "include"
      });
      return response.ok;
    } catch (error) {
      return false;
    }
  }
}
var secure_token_manager_default = SecureTokenManager;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EnvelopeEncryptionService,
  IdentifierProtectionService,
  SecureTokenManager
});
