"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var nsec_session_bridge_exports = {};
__export(nsec_session_bridge_exports, {
  NSECSessionBridge: () => NSECSessionBridge,
  default: () => nsec_session_bridge_default,
  initializeNSECSessionAfterAuth: () => initializeNSECSessionAfterAuth,
  isSessionBasedSigningAvailable: () => isSessionBasedSigningAvailable,
  nsecSessionBridge: () => nsecSessionBridge
});
module.exports = __toCommonJS(nsec_session_bridge_exports);
var import_secure_nsec_manager = require("../secure-nsec-manager");
class NSECSessionBridge {
  static instance = null;
  nsecManager;
  constructor() {
    this.nsecManager = import_secure_nsec_manager.SecureNsecManager.getInstance();
  }
  static getInstance() {
    if (!NSECSessionBridge.instance) {
      NSECSessionBridge.instance = new NSECSessionBridge();
    }
    return NSECSessionBridge.instance;
  }
  /**
   * Initialize NSEC session after successful authentication
   * This should be called after JWT authentication succeeds
   * @param nsecHex - User's nsec in hex format (if available)
   * @param options - Session options
   * @returns Session ID if successful, null if failed
   */
  async initializeAfterAuth(nsecHex, options) {
    try {
      if (!nsecHex) {
        console.log(
          "\u{1F510} NSECSessionBridge: No nsec provided, session-based signing will not be available"
        );
        return null;
      }
      console.log(
        "\u{1F510} NSECSessionBridge: Initializing NSEC session after authentication"
      );
      const sessionId = await this.nsecManager.createPostRegistrationSession(
        nsecHex,
        options?.duration || 15 * 60 * 1e3,
        // 15 minutes default
        options?.maxOperations,
        options?.browserLifetime
      );
      console.log(
        "\u{1F510} NSECSessionBridge: NSEC session created successfully:",
        sessionId
      );
      return sessionId;
    } catch (error) {
      console.error(
        "\u{1F510} NSECSessionBridge: Failed to initialize NSEC session:",
        error
      );
      return null;
    }
  }
  /**
   * Check if there's an active NSEC session
   * @returns boolean indicating if session-based signing is available
   */
  hasActiveSession() {
    const sessionId = this.nsecManager.getActiveSessionId();
    const hasSession = !!sessionId;
    console.log(
      "\u{1F510} NSECSessionBridge: Active session check:",
      hasSession ? "YES" : "NO"
    );
    return hasSession;
  }
  /**
   * Get the active session ID
   * @returns Session ID if active, null otherwise
   */
  getActiveSessionId() {
    return this.nsecManager.getActiveSessionId();
  }
  /**
   * Clear the current NSEC session
   */
  clearSession() {
    console.log("\u{1F510} NSECSessionBridge: Clearing NSEC session");
    this.nsecManager.clearTemporarySession();
  }
  /**
   * Extend the current session duration
   * @param additionalMs - Additional milliseconds to extend
   * @returns boolean indicating success
   */
  extendSession(additionalMs = 15 * 60 * 1e3) {
    try {
      const sessionId = this.nsecManager.getActiveSessionId();
      if (!sessionId) {
        console.log("\u{1F510} NSECSessionBridge: No active session to extend");
        return false;
      }
      console.log(
        "\u{1F510} NSECSessionBridge: Session extension requested but not implemented"
      );
      return false;
    } catch (error) {
      console.error("\u{1F510} NSECSessionBridge: Failed to extend session:", error);
      return false;
    }
  }
  /**
   * Get session status information
   * @returns Session status object
   */
  getSessionStatus() {
    const sessionId = this.nsecManager.getActiveSessionId();
    const hasSession = !!sessionId;
    return {
      hasSession,
      sessionId,
      canSign: hasSession
    };
  }
}
const nsecSessionBridge = NSECSessionBridge.getInstance();
async function initializeNSECSessionAfterAuth(nsecHex, options) {
  return await nsecSessionBridge.initializeAfterAuth(nsecHex, options);
}
function isSessionBasedSigningAvailable() {
  return nsecSessionBridge.hasActiveSession();
}
var nsec_session_bridge_default = NSECSessionBridge;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NSECSessionBridge,
  initializeNSECSessionAfterAuth,
  isSessionBasedSigningAvailable,
  nsecSessionBridge
});
