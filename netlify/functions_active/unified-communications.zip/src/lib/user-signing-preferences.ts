"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var user_signing_preferences_exports = {};
__export(user_signing_preferences_exports, {
  UserSigningPreferencesService: () => UserSigningPreferencesService,
  userSigningPreferences: () => userSigningPreferences
});
module.exports = __toCommonJS(user_signing_preferences_exports);
var import_secure_token_manager = require("./auth/secure-token-manager");
var import_supabase = require("./supabase");
class UserSigningPreferencesService {
  static instance = null;
  cachedPreferences = null;
  constructor() {
  }
  static getInstance() {
    if (!UserSigningPreferencesService.instance) {
      UserSigningPreferencesService.instance = new UserSigningPreferencesService();
    }
    return UserSigningPreferencesService.instance;
  }
  /**
   * Get user's signing preferences
   */
  async getUserPreferences() {
    try {
      const token = import_secure_token_manager.SecureTokenManager.getAccessToken();
      if (!token) {
        console.log(
          "\u{1F510} UserSigningPreferences: No auth token, cannot load preferences"
        );
        return null;
      }
      if (this.cachedPreferences) {
        const cacheAge = Date.now() - new Date(this.cachedPreferences.updatedAt).getTime();
        if (cacheAge < 5 * 60 * 1e3) {
          return this.cachedPreferences;
        }
      }
      const tokenPayload = import_secure_token_manager.SecureTokenManager.parseTokenPayload(token);
      if (!tokenPayload?.hashedId) {
        console.log("\u{1F510} UserSigningPreferences: No hashedId in token");
        return null;
      }
      try {
        await import_supabase.supabase.rpc("set_app_config", {
          setting_name: "app.current_user_hash",
          setting_value: tokenPayload.hashedId,
          is_local: true
        });
      } catch (contextError) {
        console.log(
          "\u{1F510} UserSigningPreferences: Could not set RLS context:",
          contextError
        );
      }
      const { data, error } = await import_supabase.supabase.from("user_signing_preferences").select("*").eq("owner_hash", tokenPayload.hashedId).single();
      if (error) {
        if (error.code === "PGRST116") {
          console.log(
            "\u{1F510} UserSigningPreferences: No preferences found, creating defaults"
          );
          return await this.createDefaultPreferences();
        }
        throw error;
      }
      const preferences = {
        id: data.id,
        userDuid: data.owner_hash,
        // Updated to match new schema
        preferredMethod: data.preferred_method,
        fallbackMethod: data.fallback_method,
        autoFallback: data.auto_fallback,
        showSecurityWarnings: data.show_security_warnings,
        rememberChoice: data.remember_choice,
        sessionDurationMinutes: data.session_duration_minutes,
        maxOperationsPerSession: data.max_operations_per_session,
        nip07AutoApprove: data.nip07_auto_approve,
        nfcPinTimeoutSeconds: data.nfc_pin_timeout_seconds,
        nfcRequireConfirmation: data.nfc_require_confirmation,
        sessionLifetimeMode: data.session_lifetime_mode ?? void 0,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
        lastUsedMethod: data.last_used_method,
        lastUsedAt: data.last_used_at
      };
      this.cachedPreferences = preferences;
      return preferences;
    } catch (error) {
      console.error(
        "\u{1F510} UserSigningPreferences: Error loading preferences:",
        error
      );
      return null;
    }
  }
  /**
   * Update user's signing preferences
   */
  async updatePreferences(updates) {
    try {
      const { error } = await import_supabase.supabase.from("user_signing_preferences").update({
        preferred_method: updates.preferredMethod,
        fallback_method: updates.fallbackMethod,
        auto_fallback: updates.autoFallback,
        show_security_warnings: updates.showSecurityWarnings,
        remember_choice: updates.rememberChoice,
        session_duration_minutes: updates.sessionDurationMinutes,
        max_operations_per_session: updates.maxOperationsPerSession,
        nip07_auto_approve: updates.nip07AutoApprove,
        nfc_pin_timeout_seconds: updates.nfcPinTimeoutSeconds,
        nfc_require_confirmation: updates.nfcRequireConfirmation,
        session_lifetime_mode: updates.sessionLifetimeMode
      }).eq("owner_hash", updates.userDuid || this.cachedPreferences?.userDuid);
      if (error) throw error;
      this.cachedPreferences = null;
      console.log(
        "\u{1F510} UserSigningPreferences: Preferences updated successfully"
      );
      return true;
    } catch (error) {
      console.error(
        "\u{1F510} UserSigningPreferences: Error updating preferences:",
        error
      );
      return false;
    }
  }
  /**
   * Record successful use of a signing method
   */
  async recordMethodUsage(method) {
    try {
      const token = import_secure_token_manager.SecureTokenManager.getAccessToken();
      if (!token) {
        console.error(
          "\u{1F510} UserSigningPreferences: No token available for method usage recording"
        );
        return;
      }
      const tokenPayload = import_secure_token_manager.SecureTokenManager.parseTokenPayload(token);
      if (!tokenPayload?.hashedId) {
        console.error(
          "\u{1F510} UserSigningPreferences: No hashedId in token for method usage recording"
        );
        return;
      }
      await import_supabase.supabase.from("user_signing_preferences").update({
        last_used_method: method,
        last_used_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("owner_hash", tokenPayload.hashedId);
      console.log("\u{1F510} UserSigningPreferences: Recorded method usage:", method);
    } catch (error) {
      console.error(
        "\u{1F510} UserSigningPreferences: Error recording method usage:",
        error
      );
    }
  }
  /**
   * Get available signing methods with current status
   */
  async getAvailableSigningMethods() {
    const methods = [
      {
        id: "session",
        name: "Secure Session",
        description: "Temporary key storage for convenient signing",
        securityLevel: "high",
        convenience: "high",
        available: false,
        // Will be updated by availability check
        requiresSetup: true,
        setupInstructions: "Sign in to create a secure session for message signing"
      },
      {
        id: "nip07",
        name: "NIP-07 Browser Extension",
        description: "Zero-knowledge signing with browser extension",
        securityLevel: "maximum",
        convenience: "medium",
        available: typeof window !== "undefined" && !!window.nostr,
        requiresSetup: !window.nostr,
        setupInstructions: "Install a NIP-07 compatible browser extension like Alby or nos2x"
      },
      {
        id: "nfc",
        name: "NFC Physical MFA",
        description: "Hardware-based signing with physical device (most secure)",
        securityLevel: "maximum",
        convenience: "low",
        available: false,
        // Coming soon
        requiresSetup: true,
        setupInstructions: "NFC Physical MFA will be available in a future update"
      }
    ];
    return methods;
  }
  /**
   * Create default preferences for new users
   */
  async createDefaultPreferences() {
    try {
      const token = import_secure_token_manager.SecureTokenManager.getAccessToken();
      if (!token) {
        throw new Error("No authentication token available");
      }
      const tokenPayload = import_secure_token_manager.SecureTokenManager.parseTokenPayload(token);
      if (!tokenPayload?.hashedId) {
        throw new Error("No hashedId available in token");
      }
      const defaultPrefs = {
        owner_hash: tokenPayload.hashedId,
        // Updated to match new schema
        preferred_method: "session",
        fallback_method: "nip07",
        auto_fallback: true,
        show_security_warnings: true,
        remember_choice: true,
        session_duration_minutes: 15,
        max_operations_per_session: 50,
        nip07_auto_approve: false,
        nfc_pin_timeout_seconds: 30,
        nfc_require_confirmation: true,
        session_lifetime_mode: "timed"
      };
      const { data, error } = await import_supabase.supabase.rpc(
        "upsert_user_signing_preferences",
        {
          p_owner_hash: defaultPrefs.owner_hash,
          p_preferred_method: defaultPrefs.preferred_method,
          p_fallback_method: defaultPrefs.fallback_method,
          p_auto_fallback: defaultPrefs.auto_fallback,
          p_show_security_warnings: defaultPrefs.show_security_warnings,
          p_remember_choice: defaultPrefs.remember_choice,
          p_session_duration_minutes: defaultPrefs.session_duration_minutes,
          p_max_operations_per_session: defaultPrefs.max_operations_per_session,
          p_nip07_auto_approve: defaultPrefs.nip07_auto_approve,
          p_nfc_pin_timeout_seconds: defaultPrefs.nfc_pin_timeout_seconds,
          p_nfc_require_confirmation: defaultPrefs.nfc_require_confirmation,
          p_session_lifetime_mode: defaultPrefs.session_lifetime_mode
        }
      );
      if (error) throw error;
      console.log(
        "\u{1F510} UserSigningPreferences: Created/Updated default preferences via RPC"
      );
      return this.mapDatabaseToPreferences(data);
    } catch (error) {
      console.error(
        "\u{1F510} UserSigningPreferences: Error creating default preferences:",
        error
      );
      return null;
    }
  }
  /**
   * Map database row to preferences object
   */
  mapDatabaseToPreferences(data) {
    return {
      id: data.id,
      userDuid: data.owner_hash,
      // Updated to match new schema
      preferredMethod: data.preferred_method,
      fallbackMethod: data.fallback_method,
      autoFallback: data.auto_fallback,
      showSecurityWarnings: data.show_security_warnings,
      rememberChoice: data.remember_choice,
      sessionDurationMinutes: data.session_duration_minutes,
      maxOperationsPerSession: data.max_operations_per_session,
      nip07AutoApprove: data.nip07_auto_approve,
      nfcPinTimeoutSeconds: data.nfc_pin_timeout_seconds,
      nfcRequireConfirmation: data.nfc_require_confirmation,
      sessionLifetimeMode: data.session_lifetime_mode ?? void 0,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
      lastUsedMethod: data.last_used_method,
      lastUsedAt: data.last_used_at
    };
  }
  /**
   * Clear cached preferences (useful after updates)
   */
  clearCache() {
    this.cachedPreferences = null;
  }
}
const userSigningPreferences = UserSigningPreferencesService.getInstance();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UserSigningPreferencesService,
  userSigningPreferences
});
