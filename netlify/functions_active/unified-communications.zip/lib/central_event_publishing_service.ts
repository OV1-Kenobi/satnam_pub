"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var central_event_publishing_service_exports = {};
__export(central_event_publishing_service_exports, {
  CentralEventPublishingService: () => CentralEventPublishingService,
  DEFAULT_UNIFIED_CONFIG: () => DEFAULT_UNIFIED_CONFIG,
  MESSAGING_CONFIG: () => MESSAGING_CONFIG,
  PrivacyUtils: () => PrivacyUtils,
  central_event_publishing_service: () => central_event_publishing_service
});
module.exports = __toCommonJS(central_event_publishing_service_exports);
var import_nostr_tools = require("nostr-tools");
var import_recovery_session_bridge = require("../src/lib/auth/recovery-session-bridge");
var import_secure_nsec_manager = require("../src/lib/secure-nsec-manager");
const te = new TextEncoder();
const hexToBytes = (hex) => new Uint8Array((hex.match(/.{1,2}/g) || []).map((b) => parseInt(b, 16)));
const bytesToHex = (bytes) => Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
const utf8 = (s) => te.encode(s);
class PrivacyUtils {
  static async hashIdentifier(input) {
    const digest = await crypto.subtle.digest("SHA-256", utf8(input));
    return bytesToHex(new Uint8Array(digest));
  }
  static async generateEncryptedUUID() {
    const uuid = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
    const rand = new Uint8Array(16);
    crypto.getRandomValues(rand);
    const payload = `${uuid}:${Date.now()}:${bytesToHex(rand)}`;
    const digest = await crypto.subtle.digest("SHA-256", utf8(payload));
    return bytesToHex(new Uint8Array(digest));
  }
  static async generateSessionKey() {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    return bytesToHex(bytes);
  }
  static async importAesKey(sessionKeyHex) {
    const keyBytes = hexToBytes(sessionKeyHex);
    const raw = new ArrayBuffer(keyBytes.byteLength);
    new Uint8Array(raw).set(keyBytes);
    return crypto.subtle.importKey("raw", raw, { name: "AES-GCM" }, false, [
      "encrypt",
      "decrypt"
    ]);
  }
  static async encryptWithSessionKey(data, sessionKey) {
    const iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    const key = await this.importAesKey(sessionKey);
    const enc = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      utf8(data)
    );
    return `${bytesToHex(iv)}:${bytesToHex(new Uint8Array(enc))}`;
  }
  static async decryptWithSessionKey(encryptedData, sessionKey) {
    const [ivHex, cipherHex] = encryptedData.split(":");
    const iv = hexToBytes(ivHex);
    const cipher = hexToBytes(cipherHex);
    const key = await this.importAesKey(sessionKey);
    const ab = new ArrayBuffer(cipher.byteLength);
    new Uint8Array(ab).set(cipher);
    const ivAb = new ArrayBuffer(iv.byteLength);
    new Uint8Array(ivAb).set(iv);
    const dec = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: ivAb },
      key,
      ab
    );
    return new TextDecoder().decode(dec);
  }
  static async hashTimestamp(ts) {
    const v = typeof ts === "number" ? ts.toString() : ts.toISOString();
    const digest = await crypto.subtle.digest("SHA-256", utf8(v));
    return bytesToHex(new Uint8Array(digest));
  }
}
async function getSupabase() {
  try {
    const mod = await import("../netlify/functions/supabase.js");
    const m = mod.default || mod;
    return m.supabase || m;
  } catch {
    try {
      const mod2 = await import("../netlify/functions/supabase");
      const m2 = mod2.default || mod2;
      return m2.supabase || m2;
    } catch (e) {
      throw new Error(
        `Failed to load supabase client: ${e instanceof Error ? e.message : "Unknown error"}`
      );
    }
  }
}
const MESSAGING_CONFIG = {
  SESSION_TTL_HOURS: 24,
  CONTACT_CACHE_TTL_HOURS: 12,
  MESSAGE_BATCH_SIZE: 50,
  RATE_LIMITS: {
    SEND_MESSAGE_PER_HOUR: 100,
    ADD_CONTACT_PER_HOUR: 20,
    CREATE_GROUP_PER_DAY: 5,
    GROUP_INVITE_PER_HOUR: 50
  },
  IDENTITY_DISCLOSURE: {
    DEFAULT_PRIVATE: true,
    REQUIRE_EXPLICIT_CONSENT: true,
    PRIVACY_WARNING_REQUIRED: true
  }
};
const DEFAULT_UNIFIED_CONFIG = {
  relays: ["wss://nos.lol", "wss://relay.damus.io", "wss://relay.nostr.band"],
  giftWrapEnabled: true,
  guardianApprovalRequired: true,
  guardianPubkeys: [],
  maxGroupSize: 50,
  messageRetentionDays: 30,
  privacyDelayMs: 5e3,
  defaultEncryptionLevel: "enhanced",
  privacyWarnings: {
    enabled: true,
    showForNewContacts: true,
    showForGroupMessages: true
  },
  session: {
    ttlHours: 24,
    maxConcurrentSessions: 3
  }
};
function isValidRelayUrl(url) {
  if (!url || typeof url !== "string") return false;
  const s = url.trim();
  if (!s.startsWith("wss://")) return false;
  try {
    new URL(s);
    return true;
  } catch {
    return false;
  }
}
function parseRelaysCSV(csv) {
  return (csv || "").split(",").map((s) => s.trim()).filter(Boolean);
}
function defaultRelays() {
  const envNostr = process?.env?.NOSTR_RELAYS;
  const envVite = process?.env?.VITE_NOSTR_RELAYS;
  const raw = envNostr && envNostr.length ? envNostr : envVite;
  const list = parseRelaysCSV(raw).filter(isValidRelayUrl);
  if (list.length) return list;
  console.warn(
    "[CEPS] NOSTR_RELAYS/VITE_NOSTR_RELAYS not set or contained no valid wss:// URLs; falling back to defaults"
  );
  const isDevelopment = process?.env?.NODE_ENV !== "production";
  if (isDevelopment) {
    console.log(
      "[CEPS] Using development relay configuration with extended timeout tolerance"
    );
    return [
      "wss://relay.damus.io",
      "wss://nos.lol",
      "wss://relay.snort.social",
      "wss://relay.nostr.band",
      "wss://nostr.wine"
    ];
  }
  return ["wss://nos.lol", "wss://relay.damus.io", "wss://relay.nostr.band"];
}
class CentralEventPublishingService {
  pool;
  relays;
  config;
  // Session and privacy state
  userSession = null;
  contactSessions = /* @__PURE__ */ new Map();
  groupSessions = /* @__PURE__ */ new Map();
  pendingApprovals = /* @__PURE__ */ new Map();
  rateLimits = /* @__PURE__ */ new Map();
  constructor() {
    this.pool = new import_nostr_tools.SimplePool();
    this.relays = defaultRelays();
    this.config = DEFAULT_UNIFIED_CONFIG;
    this.config.relays = this.relays.slice();
    this.setupGlobalErrorHandling();
  }
  setupGlobalErrorHandling() {
    if (typeof window !== "undefined") {
      const originalConsoleError = console.error;
      console.error = (...args) => {
        const message = args.join(" ");
        if (message.includes("websocket error") || message.includes("WebSocket connection")) {
          console.warn("[CEPS] Suppressed WebSocket error:", ...args);
          return;
        }
        originalConsoleError.apply(console, args);
      };
    }
  }
  setRelays(relays) {
    if (Array.isArray(relays) && relays.length) this.relays = relays;
  }
  // ---- Session management ----
  async isNIP07Session() {
    if (!this.userSession) return false;
    return this.userSession.authMethod === "nip07";
  }
  async initializeSession(nsecOrMarker, options) {
    try {
      const isNip07 = nsecOrMarker === "nip07" || options?.authMethod === "nip07";
      if (isNip07) {
        return await this.initializeNIP07Session(options);
      }
      return await this.initializeNsecSession(nsecOrMarker, options);
    } catch (error) {
      throw new Error(
        `Failed to initialize unified messaging session: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  }
  async initializeNsecSession(nsec, options) {
    const sessionId = await PrivacyUtils.generateEncryptedUUID();
    const sessionKey = await PrivacyUtils.generateSessionKey();
    const pubHex = await (async () => {
      try {
        if (typeof nsec === "string" && /^[0-9a-fA-F]{64}$/.test(nsec))
          return (0, import_nostr_tools.getPublicKey)(hexToBytes(nsec));
        const dec = import_nostr_tools.nip19.decode(nsec);
        if (dec.type === "nsec") {
          const data = dec.data;
          return (0, import_nostr_tools.getPublicKey)(data);
        }
      } catch {
      }
      const bytes = te.encode(nsec);
      const keyBytes = bytes.length >= 32 ? bytes.slice(0, 32) : new Uint8Array(32).map((_, i) => bytes[i % bytes.length] || 0);
      return (0, import_nostr_tools.getPublicKey)(keyBytes);
    })();
    const userHash = await PrivacyUtils.hashIdentifier(pubHex);
    const ttlHours = options?.ttlHours ?? this.config.session.ttlHours;
    const expiresAt = new Date(Date.now() + ttlHours * 60 * 60 * 1e3);
    try {
      const policy = await this.getSigningPolicy();
      await import_secure_nsec_manager.secureNsecManager.createPostRegistrationSession(
        nsec,
        policy.sessionDurationMs,
        policy.maxOperations,
        policy.browserLifetime
      );
    } catch (e) {
      console.warn("[CEPS] Failed to create SecureNsecManager session:", e);
    }
    this.userSession = {
      sessionId,
      userHash,
      sessionKey,
      // used only for metadata encryption
      expiresAt,
      ipAddress: options?.ipAddress,
      userAgent: options?.userAgent,
      authMethod: "nsec"
    };
    await this.storeSessionInDatabase(this.userSession);
    return sessionId;
  }
  async initializeNIP07Session(options) {
    const sessionId = await PrivacyUtils.generateEncryptedUUID();
    const sessionKey = await PrivacyUtils.generateSessionKey();
    const userNpub = options?.npub ?? "";
    const userHash = await PrivacyUtils.hashIdentifier(userNpub || "nip07");
    const ttlHours = options?.ttlHours ?? this.config.session.ttlHours;
    const expiresAt = new Date(Date.now() + ttlHours * 60 * 60 * 1e3);
    this.userSession = {
      sessionId,
      userHash,
      sessionKey,
      expiresAt,
      ipAddress: options?.ipAddress,
      userAgent: options?.userAgent,
      authMethod: "nip07"
    };
    await this.storeSessionInDatabase(this.userSession);
    return sessionId;
  }
  async storeSessionInDatabase(session) {
    const supabase = await getSupabase();
    await supabase.rpc("set_config", {
      setting_name: "app.current_user_hash",
      setting_value: session.userHash,
      is_local: true
    }).then(() => {
    }).catch(() => {
    });
    const { error } = await supabase.from("messaging_sessions").upsert({
      session_id: session.sessionId,
      user_hash: session.userHash,
      session_key: session.sessionKey,
      expires_at: session.expiresAt.toISOString(),
      ip_address: session.ipAddress,
      user_agent: session.userAgent,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (error) throw new Error(`Session storage failed: ${error.message}`);
  }
  async destroySession() {
    const supabase = await getSupabase();
    try {
      if (this.userSession) {
        await supabase.from("messaging_sessions").delete().eq("session_id", this.userSession.sessionId);
      }
    } finally {
      this.userSession = null;
      this.contactSessions.clear();
      this.groupSessions.clear();
      this.pendingApprovals.clear();
      this.rateLimits.clear();
      try {
        this.pool.close(this.relays);
      } catch {
      }
    }
  }
  async getSessionStatus() {
    const base = {
      active: this.userSession !== null,
      sessionId: this.userSession?.sessionId || null,
      contactCount: this.contactSessions.size,
      groupCount: this.groupSessions.size
    };
    if (!this.userSession) return base;
    const isNip07 = await this.isNIP07Session();
    return {
      ...base,
      authMethod: isNip07 ? "nip07" : "nsec",
      userHash: this.userSession.userHash,
      expiresAt: this.userSession.expiresAt
    };
  }
  // ---- Rate limiting helpers ----
  checkRateLimit(key, max, windowMs) {
    const now = Date.now();
    const entry = this.rateLimits.get(key);
    if (!entry || now >= entry.resetTime) {
      this.rateLimits.set(key, { count: 1, resetTime: now + windowMs });
      return;
    }
    if (entry.count >= max) {
      const retryIn = Math.max(0, entry.resetTime - now);
      throw new Error(
        `Rate limit exceeded. Retry in ${Math.ceil(retryIn / 1e3)}s`
      );
    }
    entry.count += 1;
    this.rateLimits.set(key, entry);
  }
  calcPrivacyDelayMs() {
    return Math.floor(Math.random() * (this.config.privacyDelayMs || 0));
  }
  async sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }
  // ---- Contacts ----
  async addContact(contactData) {
    if (!this.userSession) throw new Error("No active session");
    this.checkRateLimit(
      `add_contact:${this.userSession.userHash}`,
      MESSAGING_CONFIG.RATE_LIMITS.ADD_CONTACT_PER_HOUR,
      60 * 60 * 1e3
    );
    const contactSessionId = await PrivacyUtils.generateEncryptedUUID();
    const encryptedNpub = await PrivacyUtils.encryptWithSessionKey(
      contactData.npub,
      this.userSession.sessionKey
    );
    const displayNameHash = await PrivacyUtils.hashIdentifier(
      contactData.displayName
    );
    const nip05Hash = contactData.nip05 ? await PrivacyUtils.hashIdentifier(contactData.nip05) : void 0;
    const tagsHash = contactData.tags ? await Promise.all(
      contactData.tags.map((t) => PrivacyUtils.hashIdentifier(t))
    ) : [];
    const contact = {
      sessionId: contactSessionId,
      encryptedNpub,
      nip05Hash,
      displayNameHash,
      familyRole: contactData.familyRole,
      trustLevel: contactData.trustLevel,
      supportsGiftWrap: true,
      preferredEncryption: contactData.preferredEncryption || "gift-wrap",
      tagsHash,
      addedAt: /* @__PURE__ */ new Date(),
      addedByHash: this.userSession.userHash
    };
    this.contactSessions.set(contactSessionId, contact);
    await this.storeContactInDatabase(contact);
    return contactSessionId;
  }
  // ---- Dynamic identity retrieval (SecureSession first, then NIP-07, DB fallback) ----
  async getUserPubkeyHexForVerification() {
    try {
      const sessionId = this.getActiveSigningSessionId();
      if (sessionId) {
        const pubHex = await import_secure_nsec_manager.secureNsecManager.useTemporaryNsec(
          sessionId,
          async (nsecHex) => {
            try {
              if (/^[0-9a-fA-F]{64}$/.test(nsecHex)) {
                return (0, import_nostr_tools.getPublicKey)(nsecHex);
              }
              const dec = import_nostr_tools.nip19.decode(nsecHex);
              if (dec.type === "nsec") {
                const data2 = dec.data;
                return (0, import_nostr_tools.getPublicKey)(data2);
              }
            } catch {
            }
            return (0, import_nostr_tools.getPublicKey)(nsecHex);
          }
        );
        if (typeof pubHex === "string" && pubHex.length >= 64) return pubHex;
      }
    } catch {
    }
    try {
      const w = globalThis;
      const regGuard = !!w?.window?.__identityForgeRegFlow;
      if (!regGuard && w?.window?.nostr?.getPublicKey) {
        const pubHex = await w.window.nostr.getPublicKey();
        if (typeof pubHex === "string" && pubHex.length >= 64) return pubHex;
      }
    } catch {
    }
    if (!this.userSession) throw new Error("No active session");
    const supabase = await getSupabase();
    const { data, error } = await supabase.from("user_identities").select("npub, pubkey").eq("user_hash", this.userSession.userHash).single();
    if (error || !data)
      throw new Error("Could not retrieve user identity for verification");
    const candidate = data.pubkey || data.npub;
    if (!candidate) throw new Error("User identity missing pubkey/npub");
    if (candidate.startsWith("npub")) {
      const dec = import_nostr_tools.nip19.decode(candidate);
      const hex = typeof dec.data === "string" ? dec.data : bytesToHex(dec.data);
      return hex;
    }
    return candidate;
  }
  async storeContactInDatabase(contact) {
    const supabase = await getSupabase();
    const { error } = await supabase.from("privacy_contacts").upsert({
      session_id: contact.sessionId,
      encrypted_npub: contact.encryptedNpub,
      nip05_hash: contact.nip05Hash,
      display_name_hash: contact.displayNameHash,
      family_role: contact.familyRole,
      trust_level: contact.trustLevel,
      supports_gift_wrap: contact.supportsGiftWrap,
      preferred_encryption: contact.preferredEncryption,
      last_seen_hash: contact.lastSeenHash,
      tags_hash: contact.tagsHash,
      added_at: contact.addedAt.toISOString(),
      added_by_hash: contact.addedByHash
    });
    if (error) throw new Error(`Contact storage failed: ${error.message}`);
  }
  async createGroup(a, b, c, d) {
    if (typeof a === "string") {
      const creatorNsec = a;
      const groupName = b;
      const groupType = c;
      const memberPubkeys = d;
      const pubHex = await this.getUserPubkeyHexForVerification();
      const ev = await this.signEventWithActiveSession({
        kind: 1770,
        created_at: Math.floor(Date.now() / 1e3),
        tags: [
          ["g:name", groupName],
          ["g:type", groupType],
          ...(memberPubkeys || []).map((p) => ["p", p])
        ],
        content: "",
        pubkey: pubHex
      });
      return await this.publishEvent(ev);
    }
    if (!this.userSession) throw new Error("No active session");
    this.checkRateLimit(
      `create_group:${this.userSession.userHash}`,
      MESSAGING_CONFIG.RATE_LIMITS.CREATE_GROUP_PER_DAY,
      24 * 60 * 60 * 1e3
    );
    const groupData = a;
    const groupSessionId = await PrivacyUtils.generateEncryptedUUID();
    const nameHash = await PrivacyUtils.hashIdentifier(groupData.name);
    const descriptionHash = await PrivacyUtils.hashIdentifier(
      groupData.description || ""
    );
    const group = {
      sessionId: groupSessionId,
      nameHash,
      descriptionHash,
      groupType: groupData.groupType,
      memberCount: 1,
      adminHashes: [this.userSession.userHash],
      encryptionType: groupData.encryptionType,
      createdAt: /* @__PURE__ */ new Date(),
      createdByHash: this.userSession.userHash
    };
    this.groupSessions.set(groupSessionId, group);
    await this.storeGroupInDatabase(group);
    return groupSessionId;
  }
  async storeGroupInDatabase(group) {
    const supabase = await getSupabase();
    const { error } = await supabase.from("privacy_groups").upsert({
      session_id: group.sessionId,
      name_hash: group.nameHash,
      description_hash: group.descriptionHash,
      group_type: group.groupType,
      member_count: group.memberCount,
      admin_hashes: group.adminHashes,
      encryption_type: group.encryptionType,
      created_at: group.createdAt.toISOString(),
      created_by_hash: group.createdByHash
    });
    if (error) throw new Error(`Group storage failed: ${error.message}`);
  }
  async joinGroup(groupData) {
    if (!this.userSession) throw new Error("No active session");
    const supabase = await getSupabase();
    const { groupId, inviteCode, approvalRequired } = groupData;
    const { data: existingGroup, error: groupError } = await supabase.from("privacy_groups").select("*").eq("session_id", groupId).single();
    if (groupError || !existingGroup)
      throw new Error("Group not found or access denied");
    const { data: existingMembership } = await supabase.from("group_memberships").select("*").eq("group_session_id", groupId).eq("member_hash", this.userSession.userHash).single();
    if (existingMembership) throw new Error("Already a member of this group");
    if (approvalRequired && this.config.guardianApprovalRequired) {
      const approvalId = await this.requestGuardianApproval(
        groupId,
        `Join group request: ${groupId}`,
        "sensitive"
      );
      return approvalId;
    }
    const membershipId = await PrivacyUtils.generateEncryptedUUID();
    const { error: insErr } = await supabase.from("group_memberships").insert({
      id: membershipId,
      group_session_id: groupId,
      member_hash: this.userSession.userHash,
      role: "member",
      joined_at: (/* @__PURE__ */ new Date()).toISOString(),
      invite_code_used: inviteCode || null
    });
    if (insErr) throw new Error(`Failed to join group: ${insErr.message}`);
    return membershipId;
  }
  async leaveGroup(groupData) {
    if (!this.userSession) throw new Error("No active session");
    const supabase = await getSupabase();
    const { groupId, reason, transferOwnership } = groupData;
    const { data: membership, error: membershipError } = await supabase.from("group_memberships").select("*").eq("group_session_id", groupId).eq("member_hash", this.userSession.userHash).single();
    if (membershipError || !membership)
      throw new Error("Not a member of this group");
    if (membership.role === "owner" && transferOwnership) {
      const newOwnerHash = await PrivacyUtils.hashIdentifier(transferOwnership);
      const { error: transferError } = await supabase.from("group_memberships").update({ role: "owner" }).eq("group_session_id", groupId).eq("member_hash", newOwnerHash);
      if (transferError) throw new Error("Failed to transfer ownership");
    } else if (membership.role === "owner" && !transferOwnership) {
      throw new Error("Group owner must transfer ownership before leaving");
    }
    const { error: leaveError } = await supabase.from("group_memberships").delete().eq("group_session_id", groupId).eq("member_hash", this.userSession.userHash);
    if (leaveError) throw new Error("Failed to leave group");
    if (reason) {
      await supabase.from("group_activity_log").insert({
        group_session_id: groupId,
        member_hash: this.userSession.userHash,
        activity_type: "member_left",
        activity_data: JSON.stringify({ reason }),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    this.groupSessions.delete(groupId);
    return true;
  }
  // ---- Guardian approvals ----
  async requestGuardianApproval(groupSessionId, content, messageType) {
    const approvalId = await PrivacyUtils.generateEncryptedUUID();
    const now = Math.floor(Date.now() / 1e3);
    const expiresAt = now + 24 * 60 * 60;
    const req = {
      id: approvalId,
      groupId: groupSessionId,
      messageId: approvalId,
      requesterPubkey: this.userSession ? this.userSession.userHash : "",
      guardianPubkey: this.config.guardianPubkeys[0] || "",
      messageContent: content,
      messageType: messageType || "sensitive",
      created_at: now,
      expires_at: expiresAt,
      status: "pending"
    };
    this.pendingApprovals.set(approvalId, req);
    const supabase = await getSupabase();
    await supabase.from("guardian_approvals").insert({
      id: req.id,
      group_id: req.groupId,
      message_id: req.messageId,
      requester_pubkey: req.requesterPubkey,
      guardian_pubkey: req.guardianPubkey,
      message_content: req.messageContent,
      message_type: req.messageType,
      created_at: req.created_at,
      expires_at: req.expires_at,
      status: req.status
    });
    return approvalId;
  }
  getRelays() {
    return this.relays.slice();
  }
  // ---- NIP-05 Disclosure ----
  validateNip05Format(nip05) {
    const nip05Regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!nip05Regex.test(nip05))
      return {
        valid: false,
        error: "Invalid NIP-05 format. Expected: name@domain.tld"
      };
    const [name, domain] = nip05.split("@");
    if (!name || !domain)
      return { valid: false, error: "NIP-05 name and domain cannot be empty" };
    if (name.length > 64)
      return {
        valid: false,
        error: "NIP-05 name too long (max 64 characters)"
      };
    return { valid: true };
  }
  async fetchWithRetry(url, options, maxRetries = 3, backoffMs = 1e3) {
    let lastError = null;
    for (let i = 0; i < maxRetries; i++) {
      try {
        const ctrl = new AbortController();
        const to = setTimeout(() => ctrl.abort(), 1e4);
        const res = await fetch(url, { ...options, signal: ctrl.signal });
        clearTimeout(to);
        return res;
      } catch (e) {
        lastError = e;
        await this.sleep(backoffMs * (i + 1));
      }
    }
    throw lastError || new Error("Max retries exceeded");
  }
  async verifyNip05(nip05, expectedPubkey) {
    try {
      const [name, domain] = nip05.split("@");
      const wellKnownUrl = `https://${domain}/.well-known/nostr.json`;
      const response = await this.fetchWithRetry(
        wellKnownUrl,
        { method: "GET" },
        3,
        1e3
      );
      if (!response.ok)
        return {
          success: false,
          error: `Failed to fetch NIP-05 verification: ${response.status} ${response.statusText}`
        };
      const wellKnownData = await response.json();
      if (!wellKnownData.names || typeof wellKnownData.names !== "object")
        return { success: false, error: "Invalid NIP-05 well-known response" };
      const publicKey = wellKnownData.names[name];
      if (!publicKey)
        return {
          success: false,
          error: `NIP-05 identifier '${name}' not found on domain '${domain}'`
        };
      if (publicKey !== expectedPubkey)
        return {
          success: false,
          error: "Public key mismatch: NIP-05 identifier does not match your public key"
        };
      return { success: true, publicKey, domain, name };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Verification failed"
      };
    }
  }
  async enableNip05Disclosure(nip05, scope, specificGroupIds) {
    if (!this.userSession)
      return { success: false, error: "No active session" };
    const fmt = this.validateNip05Format(nip05);
    if (!fmt.valid) return { success: false, error: fmt.error };
    const expectedPubkey = await this.getUserPubkeyHexForVerification();
    const verification = await this.verifyNip05(nip05, expectedPubkey);
    if (!verification.success)
      return { success: false, error: verification.error };
    const supabase = await getSupabase();
    const disclosureConfig = {
      enabled: true,
      nip05,
      scope,
      specificGroupIds,
      lastUpdated: /* @__PURE__ */ new Date(),
      verificationStatus: "verified",
      lastVerified: /* @__PURE__ */ new Date()
    };
    const { error } = await supabase.from("user_identities").update({
      nip05_disclosure_config: disclosureConfig,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("user_hash", this.userSession.userHash);
    if (error)
      return {
        success: false,
        error: `Failed to save disclosure configuration: ${error.message}`
      };
    await this.logPrivacyAuditEvent("nip05_disclosure_enabled", {
      nip05,
      scope,
      specificGroupIds: specificGroupIds || [],
      verificationStatus: "verified"
    });
    return { success: true };
  }
  async disableNip05Disclosure() {
    if (!this.userSession)
      return { success: false, error: "No active session" };
    const supabase = await getSupabase();
    const disclosureConfig = {
      enabled: false,
      lastUpdated: /* @__PURE__ */ new Date()
    };
    const { error } = await supabase.from("user_identities").update({
      nip05_disclosure_config: disclosureConfig,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("user_hash", this.userSession.userHash);
    if (error)
      return {
        success: false,
        error: `Failed to disable disclosure configuration: ${error.message}`
      };
    await this.logPrivacyAuditEvent("nip05_disclosure_disabled", {
      previouslyEnabled: true
    });
    return { success: true };
  }
  async getNip05DisclosureStatus() {
    if (!this.userSession) return { enabled: false };
    const supabase = await getSupabase();
    const { data, error } = await supabase.from("user_identities").select("nip05_disclosure_config").eq("user_hash", this.userSession.userHash).single();
    if (error || !data) return { enabled: false };
    const config = data.nip05_disclosure_config;
    if (!config || !config.enabled) return { enabled: false };
    return {
      enabled: true,
      nip05: config.nip05,
      scope: config.scope,
      specificGroupIds: config.specificGroupIds,
      lastUpdated: config.lastUpdated ? new Date(config.lastUpdated) : void 0,
      verificationStatus: config.verificationStatus,
      lastVerified: config.lastVerified ? new Date(config.lastVerified) : void 0
    };
  }
  async logPrivacyAuditEvent(action, details) {
    try {
      const supabase = await getSupabase();
      await supabase.from("privacy_audit_log").insert({ action, details, timestamp: (/* @__PURE__ */ new Date()).toISOString() });
    } catch {
    }
  }
  sanitizeFixedTags(ev) {
    try {
      const clone = { ...ev };
      const tags = Array.isArray(clone.tags) ? clone.tags.slice() : [];
      const sanitized = [];
      for (const t of tags) {
        if (!Array.isArray(t) || t.length < 2) continue;
        const key = t[0];
        let val = t[1];
        if (key === "p" || key === "e") {
          try {
            if (typeof val === "string" && val.startsWith("npub1")) {
              val = this.npubToHex(val);
            } else if (typeof val === "string" && val.startsWith("note1") && key === "e") {
              const dec = import_nostr_tools.nip19.decode(val);
              val = typeof dec.data === "string" ? dec.data : bytesToHex(dec.data);
            }
          } catch {
          }
          if (typeof val === "string" && /^[0-9a-fA-F]{64}$/.test(val)) {
            sanitized.push([key, val, ...t.slice(2) || []]);
          } else {
            console.warn(`[CEPS] Dropping invalid '${key}' tag value`, {
              value: t[1]
            });
          }
        } else {
          sanitized.push(t);
        }
      }
      clone.tags = sanitized;
      if (typeof clone.pubkey === "string" && clone.pubkey.startsWith("npub1")) {
        try {
          clone.pubkey = this.npubToHex(clone.pubkey);
        } catch {
        }
      }
      return clone;
    } catch {
      return ev;
    }
  }
  async publishEvent(ev, relays) {
    ev = this.sanitizeFixedTags(ev);
    const list = relays && relays.length ? relays : this.relays;
    const powDifficulty = {
      // Known requirement as of current relay policy
      "wss://relay.0xchat.com": 28
    };
    const nonPow = list.filter((r) => !(r in powDifficulty));
    const powRelays = list.filter((r) => r in powDifficulty);
    const results = [];
    const publishWithTimeout = async (relay, event) => {
      const publishPromise = this.pool.publish([relay], event);
      const timeoutPromise = new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Connection timeout")), 1e4)
      );
      await Promise.race([publishPromise, timeoutPromise]);
    };
    for (const r of nonPow) {
      try {
        await publishWithTimeout(r, ev);
        results.push({ relay: r, ok: true });
        console.log(`[CEPS] Successfully published to ${r}`);
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        if (/duplicate/i.test(msg)) {
          results.push({ relay: r, ok: true });
          console.log(`[CEPS] Duplicate event on ${r} (treated as success)`);
        } else {
          if (msg.toLowerCase().includes("websocket") || msg.includes("Connection timeout")) {
            console.warn(
              `[CEPS] Relay ${r} connection failed (non-fatal): ${msg}`
            );
          } else {
            console.warn(`[CEPS] Publish to ${r} failed: ${msg}`);
          }
          results.push({ relay: r, ok: false, error: msg });
        }
      }
    }
    if (powRelays.length) {
      try {
        const isBrowser = typeof window !== "undefined" && typeof document !== "undefined";
        if (isBrowser) {
          await Promise.allSettled(
            powRelays.map(
              (relay) => (async () => {
                const initial = powDifficulty[relay] || 28;
                const mineAndPublish = (difficulty) => new Promise((resolve) => {
                  const workerSrc = `self.onmessage = async (e) => {
  const { event, difficulty } = e.data || {};
  try {
    const mod = await import('nostr-tools/nip13');
    const mined = await mod.minePow(event, difficulty);
    self.postMessage({ success: true, event: mined });
  } catch (err) {
    const msg = (err && err.message) ? err.message : String(err);
    self.postMessage({ success: false, error: msg });
  }
};`;
                  const blob = new Blob([workerSrc], {
                    type: "text/javascript"
                  });
                  const url = URL.createObjectURL(blob);
                  const worker = new Worker(url, { type: "module" });
                  worker.onmessage = async (evt) => {
                    const { success, event, error } = evt.data || {};
                    if (!success) {
                      try {
                        worker.terminate?.();
                      } catch {
                      }
                      try {
                        URL.revokeObjectURL(url);
                      } catch {
                      }
                      return resolve({ ok: false, error });
                    }
                    try {
                      await publishWithTimeout(relay, event);
                      resolve({ ok: true });
                    } catch (e) {
                      const msg = e instanceof Error ? e.message : String(e);
                      resolve({ ok: false, error: msg });
                    } finally {
                      try {
                        worker.terminate?.();
                      } catch {
                      }
                      try {
                        URL.revokeObjectURL(url);
                      } catch {
                      }
                    }
                  };
                  worker.postMessage({ event: ev, difficulty });
                });
                let attempt = await mineAndPublish(initial);
                if (!attempt.ok) {
                  const m = /difficulty[^0-9]*([0-9]+)/i.exec(
                    attempt.error || ""
                  );
                  const req = m ? parseInt(m[1], 10) : NaN;
                  if (Number.isFinite(req) && req > initial) {
                    attempt = await mineAndPublish(req);
                  }
                }
                results.push({ relay, ok: attempt.ok, error: attempt.error });
              })()
            )
          );
        } else {
          console.log("[CEPS] Skipping PoW relays in server environment");
          for (const r of powRelays)
            results.push({
              relay: r,
              ok: false,
              error: "PoW not available in server env"
            });
        }
      } catch (e) {
        console.warn(
          "[CEPS] PoW handling failed:",
          e instanceof Error ? e.message : String(e)
        );
        for (const r of powRelays)
          results.push({ relay: r, ok: false, error: "PoW worker failed" });
      }
    }
    if (!results.some((r) => r.ok)) {
      console.warn(
        "[CEPS] Publish failed on all relays; proceeding without hard failure",
        { errors: results }
      );
    }
    return ev.id;
  }
  // Expose common helpers so other modules do not import nostr-tools directly
  signEvent(unsignedEvent, privateKeyHex) {
    return (0, import_nostr_tools.finalizeEvent)(unsignedEvent, privateKeyHex);
  }
  getPublicKeyHex(privateKeyHex) {
    return (0, import_nostr_tools.getPublicKey)(privateKeyHex);
  }
  verifyEvent(ev) {
    try {
      return (0, import_nostr_tools.verifyEvent)(ev);
    } catch {
      return false;
    }
  }
  subscribeMany(relays, filters, handlers) {
    const list = relays && relays.length ? relays : this.relays;
    return this.pool.subscribeMany(list, filters, {
      onevent: handlers.onevent,
      oneose: handlers.oneose
    });
  }
  // ---- Centralized session-based signing (SecureNsecManager integration) ----
  /**
   * Get active signing session id from either RecoverySessionBridge or SecureNsecManager
   */
  getActiveSigningSessionId() {
    try {
      const recovery = import_recovery_session_bridge.recoverySessionBridge?.getRecoverySessionStatus?.();
      if (recovery?.hasSession && recovery?.sessionId)
        return recovery.sessionId;
      const direct = import_secure_nsec_manager.secureNsecManager.getActiveSessionId();
      return direct || null;
    } catch {
      return null;
    }
  }
  // ---- Signing policy integration ----
  async getSigningPolicy() {
    try {
      const prefsMod = await import("../src/lib/user-signing-preferences");
      const prefs = await prefsMod.userSigningPreferences.getUserPreferences();
      if (!prefs) {
        return {
          sessionDurationMs: 15 * 60 * 1e3,
          maxOperations: 50,
          singleUse: false,
          browserLifetime: false
        };
      }
      return {
        sessionDurationMs: Math.max(5, prefs.sessionDurationMinutes || 15) * 60 * 1e3,
        maxOperations: Math.max(1, prefs.maxOperationsPerSession || 50),
        singleUse: (prefs.maxOperationsPerSession || 50) === 1,
        browserLifetime: prefs.sessionLifetimeMode === "browser_session"
      };
    } catch {
      return {
        sessionDurationMs: 15 * 60 * 1e3,
        maxOperations: 50,
        singleUse: false,
        browserLifetime: false
      };
    }
  }
  /**
   * Finalize an unsigned event using the active secure session without exposing nsec
   */
  async signEventWithActiveSession(unsignedEvent) {
    const sessionId = this.getActiveSigningSessionId();
    if (!sessionId) throw new Error("No active signing session");
    const status = import_secure_nsec_manager.secureNsecManager.getSessionStatus?.(sessionId);
    if (!status?.active) {
      throw new Error("Signing session expired or operation limit reached");
    }
    const ev = await import_secure_nsec_manager.secureNsecManager.useTemporaryNsec(
      sessionId,
      async (nsecHex) => {
        const toSign = {
          ...unsignedEvent,
          created_at: unsignedEvent.created_at || Math.floor(Date.now() / 1e3)
        };
        return (0, import_nostr_tools.finalizeEvent)(toSign, nsecHex);
      }
    );
    try {
      const policy = await this.getSigningPolicy();
      if (policy.singleUse) {
        try {
          import_secure_nsec_manager.secureNsecManager.clearTemporarySession?.();
        } catch {
        }
      }
    } catch {
    }
    return ev;
  }
  async list(filters, relays, opts) {
    const list = relays && relays.length ? relays : this.relays;
    const timeout = opts?.eoseTimeout ?? 5e3;
    const events = [];
    try {
      return await new Promise((resolve) => {
        let settled = false;
        const sub = this.pool.subscribeMany(list, filters, {
          onevent: (e) => {
            try {
              events.push(e);
            } catch {
            }
          },
          oneose: () => {
            if (settled) return;
            settled = true;
            try {
              sub.close();
            } catch {
            }
            try {
              this.pool.close(list);
            } catch {
            }
            resolve(events);
          }
        });
        setTimeout(() => {
          if (settled) return;
          settled = true;
          try {
            sub.close();
          } catch {
          }
          try {
            this.pool.close(list);
          } catch {
          }
          resolve(events);
        }, timeout);
      });
    } catch {
      return [];
    }
  }
  // ---- Keys / conversions ----
  npubToHex(npub) {
    const dec = import_nostr_tools.nip19.decode(npub);
    if (dec.type !== "npub") throw new Error("Invalid npub");
    return typeof dec.data === "string" ? dec.data : bytesToHex(dec.data);
  }
  nsecToBytes(nsec) {
    return hexToBytes(nsec);
  }
  decodeNpub(npub) {
    return this.npubToHex(npub);
  }
  encodeNpub(pubkeyHex) {
    return import_nostr_tools.nip19.npubEncode(pubkeyHex);
  }
  encodeNsec(privBytes) {
    return import_nostr_tools.nip19.nsecEncode(bytesToHex(privBytes));
  }
  decodeNsec(nsec) {
    const dec = import_nostr_tools.nip19.decode(nsec);
    if (dec.type !== "nsec" || !(dec.data instanceof Uint8Array)) {
      throw new Error("Invalid nsec format");
    }
    return dec.data;
  }
  async serverKeys() {
    const supabase = await getSupabase();
    const nsecResp = await supabase.rpc("get_rebuilding_camelot_nsec");
    const nip05Resp = await supabase.rpc("get_rebuilding_camelot_nip05");
    const nsec = nsecResp?.data;
    const nip05 = nip05Resp?.data;
    if (!nsec) throw new Error("Server NSEC unavailable");
    return { nsec, nip05 };
  }
  // ---- DM helpers ----
  async createSignedDMEventWithActiveSession(recipientPubHex, content) {
    const ev = await this.signEventWithActiveSession({
      kind: 4,
      created_at: Math.floor(Date.now() / 1e3),
      tags: [["p", recipientPubHex]],
      content
    });
    return ev;
  }
  async encryptWithActiveSession(recipientPubHex, content) {
    const sessionId = this.getActiveSigningSessionId();
    if (!sessionId) throw new Error("No active signing session");
    const enc = await import_secure_nsec_manager.secureNsecManager.useTemporaryNsec(
      sessionId,
      async (nsecHex) => {
        return await import_nostr_tools.nip04.encrypt(nsecHex, recipientPubHex, content);
      }
    );
    return enc;
  }
  // ---- OTP (merged) ----
  otpMessage(otp, identifier, expiresAt, mode) {
    const security = mode === "gift-wrap" ? "Encrypted using NIP-59 gift-wrap" : "Encrypted using NIP-04";
    return `Your OTP code: ${otp}
This code is for: ${identifier}
Expires: ${expiresAt.toISOString()}
Security: ${security}`;
  }
  async storeOTP(npub, otp, expiresAt) {
    const supabase = await getSupabase();
    const { hash, salt } = await this.hashOTP(otp);
    const { error } = await supabase.from("family_otp_verification").insert({
      recipient_npub: npub,
      otp_hash: hash,
      otp_salt: salt,
      expires_at: expiresAt.toISOString(),
      used: false,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (error) throw new Error(error.message || "Failed to store OTP");
  }
  // ---- Send gift-wrapped DM with NIP-07 priority ----
  async sendGiftWrappedDirectMessage(contact, messageContent) {
    if (!this.userSession) throw new Error("No active session");
    this.checkRateLimit(
      `send_dm:${this.userSession.userHash}`,
      MESSAGING_CONFIG.RATE_LIMITS.SEND_MESSAGE_PER_HOUR,
      60 * 60 * 1e3
    );
    const recipientNpub = await PrivacyUtils.decryptWithSessionKey(
      contact.encryptedNpub,
      this.userSession.sessionKey
    );
    const content = JSON.stringify(messageContent);
    const delayMs = this.calcPrivacyDelayMs();
    const w = globalThis;
    const preferGift = contact.preferredEncryption === "gift-wrap" || contact.preferredEncryption === "auto";
    if (preferGift && w?.window?.nostr?.signEvent) {
      try {
        const senderPubHex = await this.getUserPubkeyHexForVerification();
        const recipientHex2 = this.npubToHex(recipientNpub);
        const dmEventUnsigned = {
          kind: 4,
          created_at: Math.floor(Date.now() / 1e3),
          tags: [["p", recipientHex2]],
          content,
          pubkey: senderPubHex
        };
        const signedDm = await w.window.nostr.signEvent(dmEventUnsigned);
        const wrapped = await import_nostr_tools.nip59.wrapEvent?.(
          signedDm,
          senderPubHex,
          recipientHex2
        );
        if (wrapped) {
          await this.sleep(delayMs);
          return await this.publishEvent(wrapped);
        }
      } catch {
      }
    }
    const recipientHex = this.npubToHex(recipientNpub);
    if (preferGift) {
      try {
        const dmEvent = await this.createSignedDMEventWithActiveSession(
          recipientHex,
          content
        );
        const senderHex = await this.getUserPubkeyHexForVerification();
        const wrapped = await import_nostr_tools.nip59.wrapEvent?.(
          dmEvent,
          senderHex,
          recipientHex
        );
        if (wrapped) {
          await this.sleep(delayMs);
          return await this.publishEvent(wrapped);
        }
      } catch {
      }
    }
    const enc = await this.encryptWithActiveSession(recipientHex, content);
    const ev = await this.createSignedDMEventWithActiveSession(
      recipientHex,
      enc
    );
    await this.sleep(delayMs);
    return await this.publishEvent(ev);
  }
  async hashOTP(otp) {
    const saltBytes = new Uint8Array(16);
    crypto.getRandomValues(saltBytes);
    const salt = bytesToHex(saltBytes);
    const buf = await crypto.subtle.digest("SHA-256", utf8(`${otp}:${salt}`));
    return { hash: bytesToHex(new Uint8Array(buf)), salt };
  }
  genOTP(len = 6) {
    const n = Math.max(4, Math.min(10, len));
    const arr = new Uint8Array(n);
    crypto.getRandomValues(arr);
    return Array.from(arr).map((b) => String(b % 10)).join("");
  }
  async sendOTPDM(recipientNpub, userNip05, prefs) {
    try {
      const { nsec } = await this.serverKeys();
      const otp = this.genOTP(6);
      const expiresAt = new Date(Date.now() + 10 * 60 * 1e3);
      const recipientPubHex = this.npubToHex(recipientNpub);
      const senderPrivBytes = this.nsecToBytes(nsec);
      let ev = null;
      let messageType = "nip04";
      if (!prefs || prefs.preferGiftWrap !== false) {
        try {
          const dm = this.otpMessage(
            otp,
            userNip05 || recipientNpub,
            expiresAt,
            "gift-wrap"
          );
          const enc = await this.encryptWithActiveSession(recipientPubHex, dm);
          ev = await this.createSignedDMEventWithActiveSession(
            recipientPubHex,
            enc
          );
          messageType = "gift-wrap";
        } catch {
        }
      }
      if (!ev) {
        const dm = this.otpMessage(
          otp,
          userNip05 || recipientNpub,
          expiresAt,
          "nip04"
        );
        const enc = await this.encryptWithActiveSession(recipientPubHex, dm);
        ev = await this.createSignedDMEventWithActiveSession(
          recipientPubHex,
          enc
        );
        messageType = "nip04";
      }
      if (!ev) {
        throw new Error("Failed to create OTP event");
      }
      const id = await this.publishEvent(ev);
      await this.storeOTP(recipientNpub, otp, expiresAt);
      return { success: true, otp, messageId: id, expiresAt, messageType };
    } catch (e) {
      return {
        success: false,
        error: e instanceof Error ? e.message : "Failed to send OTP"
      };
    }
  }
  // ---- Group operations with rate limiting ----
  async inviteToGroup(adminNsec, groupId, inviteePubkey) {
    const adminPub = await this.getUserPubkeyHexForVerification();
    const adminKey = await PrivacyUtils.hashIdentifier(adminPub);
    this.checkRateLimit(
      `group_invite:${adminKey}`,
      MESSAGING_CONFIG.RATE_LIMITS.GROUP_INVITE_PER_HOUR,
      60 * 60 * 1e3
    );
    if (this.config.guardianApprovalRequired && this.userSession) {
      await this.requestGuardianApproval(
        groupId,
        `Invite ${inviteePubkey} to group ${groupId}`,
        "credential"
      );
    }
    const adminPubHex = await this.getUserPubkeyHexForVerification();
    const ev = await this.signEventWithActiveSession({
      kind: 1771,
      created_at: Math.floor(Date.now() / 1e3),
      tags: [
        ["e", groupId],
        ["p", inviteePubkey]
      ],
      content: "group-invite",
      pubkey: adminPubHex
    });
    return await this.publishEvent(ev);
  }
  async publishGroupAnnouncement(adminNsec, groupId, announcement) {
    const adminPub = await this.getUserPubkeyHexForVerification();
    const adminKey = await PrivacyUtils.hashIdentifier(adminPub);
    this.checkRateLimit(
      `group_announcement:${adminKey}`,
      MESSAGING_CONFIG.RATE_LIMITS.SEND_MESSAGE_PER_HOUR,
      60 * 60 * 1e3
    );
    const adminPubHex2 = await this.getUserPubkeyHexForVerification();
    const ev = await this.signEventWithActiveSession({
      kind: 1773,
      created_at: Math.floor(Date.now() / 1e3),
      tags: [
        ["e", groupId],
        ["m:type", "announcement"]
      ],
      content: announcement,
      pubkey: adminPubHex2
    });
    return await this.publishEvent(ev);
  }
  async verifyOTP(recipientNpub, providedOTP) {
    try {
      const supabase = await getSupabase();
      const { data: records, error } = await supabase.from("family_otp_verification").select("*").eq("recipient_npub", recipientNpub).eq("used", false).order("created_at", { ascending: false }).limit(5);
      if (error || !records || !records.length)
        return { valid: false, expired: false, error: "No OTP found" };
      for (const rec of records) {
        const buf = await crypto.subtle.digest(
          "SHA-256",
          utf8(`${providedOTP}:${rec.otp_salt}`)
        );
        const hash = bytesToHex(new Uint8Array(buf));
        if (hash === rec.otp_hash) {
          const now = /* @__PURE__ */ new Date();
          const exp = new Date(rec.expires_at);
          if (now > exp)
            return { valid: false, expired: true, error: "OTP has expired" };
          await supabase.from("family_otp_verification").update({ used: true, used_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", rec.id);
          return { valid: true, expired: false };
        }
      }
      return { valid: false, expired: false, error: "Invalid OTP" };
    } catch (e) {
      return {
        valid: false,
        expired: false,
        error: e instanceof Error ? e.message : "Verification failed"
      };
    }
  }
  async cleanupOTPExpired() {
    try {
      const supabase = await getSupabase();
      await supabase.rpc("cleanup_expired_otps");
      return true;
    } catch {
      return false;
    }
  }
  // ---- HybridAuth direct DM ----
  async sendDirectMessage(senderNsec, recipientNpub, plaintext) {
    const privBytes = this.nsecToBytes(senderNsec);
    const recipientHex = this.npubToHex(recipientNpub);
    const privHex = bytesToHex(privBytes);
    let ev = null;
    try {
      const now = Math.floor(Date.now() / 1e3);
      const dmEvent = (0, import_nostr_tools.finalizeEvent)(
        {
          kind: 4,
          created_at: now,
          tags: [["p", recipientHex]],
          content: await import_nostr_tools.nip04.encrypt(privHex, recipientHex, plaintext),
          pubkey: (0, import_nostr_tools.getPublicKey)(privHex),
          id: "",
          sig: ""
        },
        privHex
      );
      const wrapped = await import_nostr_tools.nip59.wrapEvent?.(
        dmEvent,
        privHex,
        recipientHex
      );
      if (wrapped) {
        ev = wrapped;
      }
    } catch {
    }
    if (!ev) {
      const enc = await import_nostr_tools.nip04.encrypt(privHex, recipientHex, plaintext);
      ev = await this.createSignedDMEventWithActiveSession(recipientHex, enc);
    }
    return await this.publishEvent(ev);
  }
  // Server-managed DM using RebuildingCamelot keys
  async sendServerDM(recipientNpub, plaintext) {
    const { nsec } = await this.serverKeys();
    return this.sendDirectMessage(nsec, recipientNpub, plaintext);
  }
  // ---- Identity Forge ----
  async publishProfile(privateNsec, profileContent) {
    let sessionId = this.getActiveSigningSessionId();
    if (!sessionId && privateNsec) {
      try {
        sessionId = await import_secure_nsec_manager.secureNsecManager.createPostRegistrationSession(
          privateNsec,
          15 * 60 * 1e3
        );
      } catch (e) {
      }
    }
    const profilePub = await this.getUserPubkeyHexForVerification();
    const ev = await this.signEventWithActiveSession({
      kind: 0,
      created_at: Math.floor(Date.now() / 1e3),
      tags: [],
      content: JSON.stringify(profileContent || {}),
      pubkey: profilePub
    });
    return await this.publishEvent(ev);
  }
  // ---- Key rotation (NIP-26, NIP-41) ----
  async publishNIP26Delegation(oldNsecHex, newPubkeyHex, kinds = [0, 1, 1777], days = 90) {
    try {
      const now = Math.floor(Date.now() / 1e3);
      const until = now + days * 24 * 60 * 60;
      const conditions = `kind=${kinds.join(
        ","
      )},created_at>${now},created_at<${until}`;
      const nt = await import("nostr-tools");
      const tag = nt.nip26?.createDelegation?.(oldNsecHex, {
        pubkey: newPubkeyHex,
        kind: 1,
        since: now,
        until,
        conditions
      });
      if (!tag) throw new Error("Failed to create delegation");
      const ev = (0, import_nostr_tools.finalizeEvent)(
        {
          kind: 1,
          created_at: now,
          tags: [["delegation", tag.pubkey, tag.conditions, tag.token]],
          content: "Delegation notice"
        },
        oldNsecHex
      );
      const id = await this.publishEvent(ev);
      return { success: true, eventId: id };
    } catch (e) {
      return {
        success: false,
        error: e instanceof Error ? e.message : "Delegation failed"
      };
    }
  }
  async publishNIP41Deprecation(pubkeyHex, targetPubkeyHex) {
    try {
      const kind = 1776;
      const ev = {
        kind,
        created_at: Math.floor(Date.now() / 1e3),
        tags: [["p", targetPubkeyHex]],
        content: `Key deprecation for ${targetPubkeyHex}`,
        pubkey: pubkeyHex,
        id: "",
        sig: ""
      };
      const id = await this.publishEvent(ev);
      return { success: true, eventId: id };
    } catch (e) {
      return {
        success: false,
        error: e instanceof Error ? e.message : "NIP-41 notice failed"
      };
    }
  }
}
const central_event_publishing_service = new CentralEventPublishingService();
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CentralEventPublishingService,
  DEFAULT_UNIFIED_CONFIG,
  MESSAGING_CONFIG,
  PrivacyUtils,
  central_event_publishing_service
});
