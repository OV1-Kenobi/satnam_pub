"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var unified_communications_exports = {};
__export(unified_communications_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(unified_communications_exports);
var import_get_contacts = __toESM(require("../../api/communications/get-contacts.js"), 1);
var import_giftwrapped = __toESM(require("../../api/communications/giftwrapped.js"), 1);
var import_messages = __toESM(require("../../api/communications/messages.js"), 1);
function buildCorsHeaders(origin, methods) {
  const allowed = /* @__PURE__ */ new Set([
    "http://localhost:8888",
    "http://localhost:5173",
    "https://www.satnam.pub"
  ]);
  const allowOrigin = allowed.has(origin || "") ? origin : "https://www.satnam.pub";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    Vary: "Origin",
    "Access-Control-Allow-Methods": methods,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
    "Cache-Control": "no-store",
    "Content-Type": "application/json"
  };
}
function callApiRouteHandler(event, headers, defaultPath, endpoint) {
  return new Promise((resolve) => {
    const req = {
      method: event.httpMethod,
      headers: event.headers || {},
      url: event.path || defaultPath,
      body: void 0,
      query: event.queryStringParameters || {}
    };
    const res = {
      _status: 200,
      _headers: { ...headers },
      status(code) {
        this._status = code;
        return this;
      },
      setHeader(k, v) {
        this._headers[k] = v;
      },
      json(payload) {
        resolve({ statusCode: this._status, headers: this._headers, body: JSON.stringify(payload) });
      },
      end() {
        resolve({ statusCode: this._status, headers: this._headers, body: "" });
      }
    };
    (async () => {
      try {
        const handler2 = endpoint === "messages" ? import_messages.default : endpoint === "get-contacts" ? import_get_contacts.default : import_giftwrapped.default;
        await Promise.resolve(handler2(req, res));
      } catch (e) {
        resolve({ statusCode: 500, headers, body: JSON.stringify({ success: false, error: e && e.message || "Internal error" }) });
      }
    })();
  });
}
function detectTarget(event) {
  const path = String(event?.path || "").toLowerCase();
  const qs = event?.queryStringParameters || {};
  const endpoint = (qs.endpoint || "").toLowerCase();
  if (path.endsWith("/api/communications/messages") || path.includes("communications-messages")) return "messages";
  if (path.endsWith("/api/communications/get-contacts") || path.includes("communications-get-contacts")) return "get-contacts";
  if (path.endsWith("/api/communications/giftwrapped") || path.includes("communications-giftwrapped")) return "giftwrapped";
  if (endpoint === "messages" || endpoint === "get-contacts" || endpoint === "giftwrapped") return endpoint;
  if (event.httpMethod === "POST") return "giftwrapped";
  if (event.httpMethod === "GET") {
    if (typeof qs.memberId === "string" && qs.memberId.length > 0) return "get-contacts";
    return "messages";
  }
  return null;
}
const handler = async (event) => {
  const origin = event?.headers?.origin || event?.headers?.Origin || "";
  const method = event?.httpMethod || "GET";
  if (method === "OPTIONS") {
    const headers = buildCorsHeaders(origin, "GET, POST, OPTIONS");
    return { statusCode: 200, headers, body: "" };
  }
  const target = detectTarget(event);
  if (target === "messages") {
    const headers = buildCorsHeaders(origin, "GET, OPTIONS");
    if (method !== "GET") return { statusCode: 405, headers, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
    return callApiRouteHandler(
      event,
      headers,
      "/api/communications/messages",
      "messages"
    );
  }
  if (target === "get-contacts") {
    const headers = buildCorsHeaders(origin, "GET, OPTIONS");
    if (method !== "GET") return { statusCode: 405, headers, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
    return callApiRouteHandler(
      event,
      headers,
      "/api/communications/get-contacts",
      "get-contacts"
    );
  }
  if (target === "giftwrapped") {
    const headers = buildCorsHeaders(origin, "POST, OPTIONS");
    if (method !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
    try {
      const mod = await import("../../api/communications/giftwrapped.js");
      const fn = mod.default || import_giftwrapped.default;
      const resp = await Promise.resolve(fn(event));
      const statusCode = resp && typeof resp.statusCode === "number" ? resp.statusCode : 200;
      const respHeaders = {
        ...headers,
        ...resp && typeof resp === "object" && resp.headers ? resp.headers : {}
      };
      const body = resp && typeof resp === "object" && "body" in resp ? typeof resp.body === "string" ? resp.body : JSON.stringify(resp.body) : JSON.stringify({ success: true });
      return { statusCode, headers: respHeaders, body };
    } catch (e) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ success: false, error: e && e.message || "Internal error" })
      };
    }
  }
  return {
    statusCode: 404,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ success: false, error: "Not Found" })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
