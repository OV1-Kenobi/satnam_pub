"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var supabase_exports = {};
__export(supabase_exports, {
  getRequestClient: () => getRequestClient,
  isServiceRoleKey: () => isServiceRoleKey,
  supabase: () => supabase,
  supabaseKeyType: () => supabaseKeyType
});
module.exports = __toCommonJS(supabase_exports);
var import_supabase_js = require("@supabase/supabase-js");
function requireEnv(key) {
  const val = process.env[key];
  if (!val) throw new Error(`Missing required environment variable: ${key}`);
  return val;
}
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;
const supabaseKeyType = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY ? "anon" : "missing";
if (!supabaseUrl) {
  throw new Error("Supabase URL not configured (SUPABASE_URL or VITE_SUPABASE_URL)");
}
if (!supabaseKey) {
  throw new Error("Supabase key not configured (SUPABASE_ANON_KEY or VITE_SUPABASE_ANON_KEY, fallback SUPABASE_SERVICE_ROLE_KEY)");
}
console.log(`\u{1F510} DEBUG: Supabase server client using ${supabaseKeyType} key`);
const supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});
function getRequestClient(accessToken) {
  return (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    },
    global: {
      headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {}
    }
  });
}
const isServiceRoleKey = () => false;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getRequestClient,
  isServiceRoleKey,
  supabase,
  supabaseKeyType
});
