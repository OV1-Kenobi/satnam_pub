"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var env_exports = {};
__export(env_exports, {
  getDuidServerSecret: () => getDuidServerSecret,
  getEnvVar: () => getEnvVar,
  getEnvironmentInfo: () => getEnvironmentInfo,
  getRequiredEnvVar: () => getRequiredEnvVar,
  getSupabaseConfig: () => getSupabaseConfig,
  isProduction: () => isProduction
});
module.exports = __toCommonJS(env_exports);
function getEnvVar(key, defaultValue) {
  if (typeof process !== "undefined" && process.env) {
    return process.env[key] || defaultValue;
  }
  return defaultValue;
}
function getRequiredEnvVar(key, context = "application") {
  const value = getEnvVar(key);
  if (!value) {
    throw new Error(`Missing required environment variable: ${key} (required for ${context})`);
  }
  return value;
}
function getDuidServerSecret() {
  const secret = getEnvVar("DUID_SERVER_SECRET");
  if (!secret) {
    throw new Error("DUID_SERVER_SECRET environment variable is required for secure indexing");
  }
  if (secret.length < 32) {
    throw new Error("DUID_SERVER_SECRET must be at least 32 characters for security");
  }
  return secret;
}
function getSupabaseConfig() {
  return {
    url: getRequiredEnvVar("VITE_SUPABASE_URL", "Supabase connection"),
    anonKey: getRequiredEnvVar("VITE_SUPABASE_ANON_KEY", "Supabase anon operations"),
    serviceRoleKey: getEnvVar("SUPABASE_SERVICE_ROLE_KEY")
    // Optional for some operations
  };
}
function isProduction() {
  const nodeEnv = getEnvVar("NODE_ENV", "development");
  const netlifyContext = getEnvVar("CONTEXT", "development");
  return nodeEnv === "production" || netlifyContext === "production";
}
function getEnvironmentInfo() {
  return {
    nodeEnv: getEnvVar("NODE_ENV"),
    netlifyContext: getEnvVar("CONTEXT"),
    isNetlify: !!getEnvVar("NETLIFY"),
    hasSupabaseUrl: !!getEnvVar("VITE_SUPABASE_URL"),
    hasSupabaseAnonKey: !!getEnvVar("VITE_SUPABASE_ANON_KEY"),
    hasSupabaseServiceKey: !!getEnvVar("SUPABASE_SERVICE_ROLE_KEY"),
    hasDuidSecret: !!getEnvVar("DUID_SERVER_SECRET"),
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getDuidServerSecret,
  getEnvVar,
  getEnvironmentInfo,
  getRequiredEnvVar,
  getSupabaseConfig,
  isProduction
});
