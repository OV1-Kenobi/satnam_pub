"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var giftwrapped_exports = {};
__export(giftwrapped_exports, {
  default: () => handler
});
module.exports = __toCommonJS(giftwrapped_exports);
let getRequestClient;
let allowRequestFn;
async function allowRate(ip) {
  if (!allowRequestFn) {
    const mod = await import("../../netlify/functions/utils/rate-limiter.js");
    allowRequestFn = mod.allowRequest;
  }
  return allowRequestFn(ip, 10, 6e4);
}
async function getClientFromEvent(event) {
  try {
    const headers = event.headers || {};
    const authHeader = headers["authorization"] || headers["Authorization"];
    if (!authHeader || !String(authHeader).startsWith("Bearer ")) {
      return { error: { status: 401, message: "Unauthorized" } };
    }
    console.log("\u{1F510} DEBUG: giftwrapped - validating JWT with SecureSessionManager");
    const { SecureSessionManager } = await import("../../netlify/functions/security/session-manager.js");
    const session = await SecureSessionManager.validateSessionFromHeader(authHeader);
    if (!session || !session.hashedId) {
      console.log("\u{1F510} DEBUG: giftwrapped - JWT validation failed");
      return { error: { status: 401, message: "Invalid token" } };
    }
    console.log("\u{1F510} DEBUG: giftwrapped - JWT validation successful, hashedId:", session.hashedId);
    const { supabase } = await import("../../netlify/functions/supabase.js");
    const client = supabase;
    const allowedHashes = /* @__PURE__ */ new Set([session.hashedId]);
    return { client, allowedHashes, sessionHashedId: session.hashedId };
  } catch (e) {
    console.error("\u{1F510} DEBUG: giftwrapped - authentication error:", e);
    return { error: { status: 500, message: "Internal server error" } };
  }
}
function getEnvVar(key) {
  return process.env[key];
}
const RATE_LIMITS = {
  SEND_MESSAGE_PER_HOUR: 100,
  SEND_MESSAGE_PER_DAY: 500,
  MAX_MESSAGE_SIZE: 1e4
  // 10KB max message size
};
async function generatePrivacyPreservingMessageId(content, sender, recipient) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`msg_${sender}_${recipient}_${content.length}_${Date.now()}`);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("").substring(0, 32);
}
async function generateNostrEventId(event) {
  const eventString = JSON.stringify([
    0,
    // Reserved for future use
    event.pubkey,
    // Public key of event creator
    event.created_at,
    // Unix timestamp
    event.kind,
    // Event kind
    event.tags,
    // Event tags
    event.content
    // Event content
  ]);
  const encoder = new TextEncoder();
  const data = encoder.encode(eventString);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function generateContentHash(content) {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function generateEncryptionKeyHash(messageContent, senderHash, messageId) {
  const keyMaterial = `${messageContent}:${senderHash}:${messageId}:encryption_key`;
  const encoder = new TextEncoder();
  const data = encoder.encode(keyMaterial);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("").substring(0, 32);
}
function convertHashedIdToNpub(hashedId) {
  return `npub1${hashedId.substring(0, 58)}`;
}
function extractPubkeyFromNpub(npubOrHash) {
  if (npubOrHash.startsWith("npub1")) {
    return npubOrHash.substring(5).padEnd(64, "0").substring(0, 64);
  }
  return npubOrHash.padEnd(64, "0").substring(0, 64);
}
async function generateDeterministicRecipientHash(recipient) {
  const salt = getEnvVar("RECIPIENT_HASH_SALT") || "static_recipient_hash_salt";
  const encoder = new TextEncoder();
  const data = encoder.encode(`recipient|${recipient}|${salt}`);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("").substring(0, 32);
}
async function generateEphemeralKey() {
  const keyArray = new Uint8Array(32);
  crypto.getRandomValues(keyArray);
  const key = Array.from(keyArray, (byte) => byte.toString(16).padStart(2, "0")).join("");
  keyArray.fill(0);
  return key;
}
function validateGiftwrappedMessage(messageData) {
  const errors = [];
  if (!messageData || typeof messageData !== "object") {
    errors.push({ field: "body", message: "Request body must be an object" });
    return { success: false, errors };
  }
  if (messageData.preSigned === true && messageData.signedEvent) {
    try {
      const signed = messageData.signedEvent;
      let inner = signed.content;
      if (typeof inner === "string") {
        try {
          inner = JSON.parse(inner);
        } catch {
        }
      }
      const derivedContent = typeof inner === "object" && inner && typeof inner.content === "string" ? inner.content : void 0;
      const derivedRecipient = (() => {
        const tags = typeof inner === "object" && inner && Array.isArray(inner.tags) ? inner.tags : Array.isArray(signed.tags) ? signed.tags : [];
        const pTag = tags.find((t) => Array.isArray(t) && t[0] === "p" && typeof t[1] === "string");
        return pTag ? pTag[1] : void 0;
      })();
      const derivedSender = typeof signed.pubkey === "string" ? signed.pubkey : void 0;
      if (derivedContent) messageData.content = messageData.content || derivedContent;
      if (derivedRecipient) messageData.recipient = messageData.recipient || derivedRecipient;
      if (derivedSender) messageData.sender = messageData.sender || derivedSender;
    } catch (_) {
    }
  }
  if (!messageData.content || typeof messageData.content !== "string") {
    errors.push({ field: "content", message: "Message content is required" });
  } else if (messageData.content.length > RATE_LIMITS.MAX_MESSAGE_SIZE) {
    errors.push({ field: "content", message: `Message content exceeds maximum size of ${RATE_LIMITS.MAX_MESSAGE_SIZE} characters` });
  }
  if (!messageData.recipient || typeof messageData.recipient !== "string") {
    errors.push({ field: "recipient", message: "Recipient identifier is required" });
  }
  if (!messageData.sender || typeof messageData.sender !== "string") {
    errors.push({ field: "sender", message: "Sender identifier is required" });
  }
  const validEncryptionLevels = ["standard", "enhanced", "maximum"];
  if (messageData.encryptionLevel && !validEncryptionLevels.includes(messageData.encryptionLevel)) {
    errors.push({
      field: "encryptionLevel",
      message: `Invalid encryption level. Must be one of: ${validEncryptionLevels.join(", ")}`
    });
  }
  const validCommunicationTypes = ["family", "individual"];
  if (messageData.communicationType && !validCommunicationTypes.includes(messageData.communicationType)) {
    errors.push({
      field: "communicationType",
      message: `Invalid communication type. Must be one of: ${validCommunicationTypes.join(", ")}`
    });
  }
  if (errors.length > 0) {
    return { success: false, errors };
  }
  return {
    success: true,
    data: {
      content: messageData.content.trim(),
      recipient: messageData.recipient.trim(),
      sender: messageData.sender.trim(),
      encryptionLevel: messageData.encryptionLevel || "enhanced",
      communicationType: messageData.communicationType || "individual",
      messageType: messageData.messageType || "direct",
      timestamp: messageData.timestamp || (/* @__PURE__ */ new Date()).toISOString()
    }
  };
}
async function createGiftWrappedEvent(messageData, ephemeralKey) {
  try {
    const privacyDelay = Math.floor(Math.random() * 300) + 60;
    const eventTimestamp = Math.floor(Date.now() / 1e3) + privacyDelay;
    const innerEvent = {
      kind: 14,
      // Direct message kind
      pubkey: messageData.sender,
      // Required for event ID generation
      content: messageData.content,
      tags: [
        ["p", messageData.recipient],
        ["message-type", messageData.messageType],
        ["encryption-level", messageData.encryptionLevel],
        ["communication-type", messageData.communicationType]
      ],
      created_at: eventTimestamp
    };
    const giftWrappedEvent = {
      kind: 1059,
      // Gift-wrapped event kind
      pubkey: messageData.sender,
      created_at: eventTimestamp,
      content: JSON.stringify(innerEvent),
      // This would be encrypted in production
      tags: [
        ["p", messageData.recipient],
        ["wrapped-event-kind", "14"],
        ["encryption", "gift-wrap"],
        ["privacy-level", messageData.encryptionLevel]
      ]
    };
    return { innerEvent, giftWrappedEvent };
  } catch (error) {
    throw new Error("Failed to create gift-wrapped event");
  }
}
async function processMessageDelivery(signedEvent, messageData) {
  try {
    console.log("\u{1F510} DEBUG: processMessageDelivery - processing pre-signed message via CEPS");
    const { CentralEventPublishingService } = await import("../../lib/central_event_publishing_service.js");
    const ceps = new CentralEventPublishingService();
    console.log("\u{1F510} DEBUG: processMessageDelivery - publishing to relays via CEPS");
    const eventId = await ceps.publishEvent(signedEvent);
    console.log("\u{1F510} DEBUG: processMessageDelivery - published successfully, eventId:", eventId);
    return {
      success: true,
      deliveryMethod: "pre-signed-ceps",
      eventId,
      relaysUsed: ["wss://relay.satnam.pub", "wss://relay.damus.io"],
      // CEPS manages actual relays
      deliveryTime: (/* @__PURE__ */ new Date()).toISOString(),
      encryptionUsed: messageData.encryptionLevel
    };
  } catch (error) {
    console.error("\u{1F510} DEBUG: processMessageDelivery - CEPS publishing error:", error);
    return {
      success: false,
      error: error?.message || "Message delivery failed via CEPS",
      deliveryMethod: "pre-signed-ceps"
    };
  }
}
function extractClientInfo(event) {
  return {
    userAgent: event.headers["user-agent"],
    ipAddress: event.headers["x-forwarded-for"] || event.headers["x-real-ip"] || event.headers["client-ip"],
    origin: event.headers["origin"]
  };
}
async function handler(event, context) {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-User-ID, X-Session-ID",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: {
        ...corsHeaders,
        "Allow": "POST"
      },
      body: JSON.stringify({
        success: false,
        error: "Method not allowed",
        meta: {
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      })
    };
  }
  try {
    let messageData;
    try {
      messageData = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
      console.log("\u{1F510} DEBUG: giftwrapped - received message data:", JSON.stringify(messageData, null, 2));
    } catch (parseError) {
      console.error("\u{1F510} DEBUG: giftwrapped - JSON parse error:", parseError);
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid JSON in request body",
          meta: { timestamp: (/* @__PURE__ */ new Date()).toISOString() }
        })
      };
    }
    const clientInfo = extractClientInfo(event);
    const isPreSigned = messageData.preSigned === true && messageData.signedEvent;
    if (isPreSigned) {
      console.log("\u{1F510} DEBUG: giftwrapped - processing pre-signed message");
      console.log("\u{1F510} DEBUG: giftwrapped - signing method:", messageData.signingMethod);
      console.log("\u{1F510} DEBUG: giftwrapped - security level:", messageData.securityLevel);
    }
    const validationResult = validateGiftwrappedMessage(messageData);
    if (!validationResult.success) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid message data",
          details: validationResult.errors,
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    const validatedData = validationResult.data;
    const clientIP = event.headers["x-forwarded-for"] || event.headers["x-real-ip"] || event.headers["client-ip"];
    if (!clientIP) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ success: false, error: "Client identification required" }) };
    }
    if (!await allowRate(String(clientIP))) {
      return { statusCode: 429, headers: corsHeaders, body: JSON.stringify({ success: false, error: "Rate limit exceeded" }) };
    }
    const authCtx = await getClientFromEvent(event);
    if (authCtx.error) {
      return { statusCode: authCtx.error.status, headers: corsHeaders, body: JSON.stringify({ success: false, error: authCtx.error.message }) };
    }
    const { client, allowedHashes, sessionHashedId } = authCtx;
    const authenticatedSender = sessionHashedId;
    console.log("\u{1F510} DEBUG: giftwrapped - using authenticated sender (hashedId):", authenticatedSender);
    validatedData.sender = authenticatedSender;
    const messageId = await generatePrivacyPreservingMessageId(
      validatedData.content,
      validatedData.sender,
      validatedData.recipient
    );
    const ephemeralKey = await generateEphemeralKey();
    let originalEventId, wrappedEventId, giftWrappedEvent, innerEvent;
    let contentHash;
    if (isPreSigned) {
      giftWrappedEvent = messageData.signedEvent;
      if (!giftWrappedEvent || typeof giftWrappedEvent !== "object" || giftWrappedEvent.kind !== 1059) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Invalid pre-signed event: kind must be 1059 (NIP-59 gift wrap)" })
        };
      }
      const expectedWrappedId = await generateNostrEventId(giftWrappedEvent);
      if (giftWrappedEvent.id && giftWrappedEvent.id !== expectedWrappedId) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Invalid pre-signed event: wrapped event id does not match content" })
        };
      }
      wrappedEventId = giftWrappedEvent.id || expectedWrappedId;
      let innerContentRaw = giftWrappedEvent.content;
      try {
        if (typeof innerContentRaw === "string") {
          innerEvent = JSON.parse(innerContentRaw);
        } else if (innerContentRaw && typeof innerContentRaw === "object") {
          innerEvent = innerContentRaw;
          innerContentRaw = JSON.stringify(innerEvent);
        } else {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ success: false, error: "Invalid pre-signed event: inner content missing or malformed" })
          };
        }
      } catch (e) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Invalid pre-signed event: inner content must be valid JSON" })
        };
      }
      try {
        originalEventId = await generateNostrEventId(innerEvent);
      } catch (e) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Invalid pre-signed event: unable to compute inner event id" })
        };
      }
      try {
        const pTag = Array.isArray(innerEvent?.tags) ? innerEvent.tags.find((t) => Array.isArray(t) && t[0] === "p") : null;
        if (pTag && typeof pTag[1] === "string") {
          const intendedRecipient = validatedData.recipient;
          let svc = null;
          try {
            const mod = await import("../../lib/central_event_publishing_service.js");
            svc = mod.central_event_publishing_service || new mod.CentralEventPublishingService();
          } catch {
          }
          const toHex = (val) => {
            try {
              if (typeof val !== "string") return null;
              if (/^[0-9a-fA-F]{64}$/.test(val)) return val;
              if (val.startsWith("npub1") && svc?.npubToHex) return svc.npubToHex(val);
              return null;
            } catch {
              return null;
            }
          };
          const intendedHex = toHex(intendedRecipient);
          const innerHex = toHex(pTag[1]);
          if (intendedHex && innerHex && intendedHex !== innerHex) {
            return {
              statusCode: 400,
              headers: corsHeaders,
              body: JSON.stringify({ success: false, error: "Recipient mismatch between request and inner event" })
            };
          }
        }
      } catch (e) {
      }
      contentHash = await generateContentHash(
        typeof giftWrappedEvent.content === "string" ? giftWrappedEvent.content : JSON.stringify(innerEvent)
      );
      console.log("\u{1F510} DEBUG: giftwrapped - pre-signed wrapped_event_id:", wrappedEventId);
      console.log("\u{1F510} DEBUG: giftwrapped - pre-signed original_event_id:", originalEventId);
    } else {
      console.log("\u{1F510} DEBUG: giftwrapped - ERROR: received unsigned message, but server-side signing is disabled");
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Message must be signed client-side using hybrid signing approach",
          userMessage: "Please use a NIP-07 extension or sign in to enable message signing"
        })
      };
    }
    if (!contentHash) {
      contentHash = await generateContentHash(validatedData.content);
    }
    console.log("\u{1F510} DEBUG: giftwrapped - generated content_hash:", contentHash.substring(0, 16) + "...");
    const encryptionKeyHash = await generateEncryptionKeyHash(validatedData.content, authenticatedSender, messageId);
    console.log("\u{1F510} DEBUG: giftwrapped - generated encryption_key_hash:", encryptionKeyHash.substring(0, 16) + "...");
    const senderNpub = convertHashedIdToNpub(authenticatedSender);
    const recipientNpub = validatedData.recipient.startsWith("npub1") ? validatedData.recipient : convertHashedIdToNpub(validatedData.recipient);
    const senderPubkey = extractPubkeyFromNpub(senderNpub);
    const recipientPubkey = extractPubkeyFromNpub(recipientNpub);
    console.log("\u{1F510} DEBUG: giftwrapped - generated sender_npub:", senderNpub.substring(0, 20) + "...");
    console.log("\u{1F510} DEBUG: giftwrapped - using recipient_npub:", recipientNpub.substring(0, 20) + "...");
    console.log("\u{1F510} DEBUG: giftwrapped - storing message in database");
    const storageResult = await (async () => {
      try {
        const recipientHash = await generateDeterministicRecipientHash(validatedData.recipient);
        console.log("\u{1F510} DEBUG: giftwrapped - recipient hash generated:", recipientHash);
        const { data: messageRecord, error: messageError } = await client.from("gift_wrapped_messages").insert({
          id: messageId,
          // Use authenticated sender (from JWT session)
          sender_hash: authenticatedSender,
          // Derive recipient hash deterministically to avoid non-deterministic queries
          recipient_hash: recipientHash,
          // REQUIRED: Nostr public keys in npub format
          sender_npub: senderNpub,
          recipient_npub: recipientNpub,
          // REQUIRED: Hex public keys for Nostr compatibility
          sender_pubkey: senderPubkey,
          recipient_pubkey: recipientPubkey,
          // REQUIRED: Original Nostr event ID (inner event) for verifiability
          original_event_id: originalEventId,
          // REQUIRED: Wrapped event ID (outer gift-wrapped event) for NIP-59 compliance
          wrapped_event_id: wrappedEventId,
          // REQUIRED: Content hash for privacy-preserving verification
          content_hash: contentHash,
          // REQUIRED: Encryption key hash for database constraint compliance
          encryption_key_hash: encryptionKeyHash,
          encryption_level: validatedData.encryptionLevel,
          communication_type: validatedData.communicationType,
          message_type: validatedData.messageType,
          status: "pending",
          // REQUIRED: Protocol discriminator for future NIP-17/MLS upgrades
          protocol: "nip59",
          // Additional fields for comprehensive database compatibility
          privacy_level: "maximum",
          encryption_method: "gift-wrap",
          forward_secrecy: true,
          nip59_version: "1.0",
          retry_count: 0,
          relay_urls: ["wss://relay.satnam.pub", "wss://relay.damus.io"],
          created_at: (/* @__PURE__ */ new Date()).toISOString(),
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString()
        }).select().single();
        if (messageError) {
          console.error("\u{1F510} DEBUG: giftwrapped - database insert error:", messageError);
          return { success: false, error: "Failed to store message" };
        }
        console.log("\u{1F510} DEBUG: giftwrapped - message stored successfully:", messageRecord?.id);
        return { success: true, record: messageRecord };
      } catch (dbError) {
        console.error("\u{1F510} DEBUG: giftwrapped - database operation error:", dbError);
        return { success: false, error: "Failed to store message" };
      }
    })();
    if (!storageResult.success) {
      return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ success: false, error: storageResult.error }) };
    }
    console.log("\u{1F510} DEBUG: giftwrapped - processing pre-signed message delivery");
    const deliveryResult = await processMessageDelivery(giftWrappedEvent, validatedData);
    deliveryResult.signingMethod = messageData.signingMethod || "hybrid";
    deliveryResult.securityLevel = messageData.securityLevel || "high";
    deliveryResult.userMessage = `Message signed with ${messageData.signingMethod} (${messageData.securityLevel} security)`;
    console.log("\u{1F510} DEBUG: giftwrapped - delivery result:", deliveryResult.success ? "SUCCESS" : "FAILED");
    try {
      const newStatus = deliveryResult.success ? "delivered" : "failed";
      const updatePayload = { status: newStatus };
      if (deliveryResult.success) {
        updatePayload.delivered_at = (/* @__PURE__ */ new Date()).toISOString();
      }
      const { error: updateError } = await client.from("gift_wrapped_messages").update(updatePayload).eq("id", messageId);
      if (updateError) {
        console.warn("\u{1F510} DEBUG: giftwrapped - failed to update delivery status:", updateError);
      } else {
        console.log("\u{1F510} DEBUG: giftwrapped - delivery status updated to", newStatus);
      }
    } catch (e) {
      console.warn("\u{1F510} DEBUG: giftwrapped - unexpected error updating delivery status", e);
    }
    if (ephemeralKey) {
      ephemeralKey.split("").forEach((_, i, arr) => arr[i] = "0");
    }
    const responseData = {
      success: true,
      messageId,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      encryptionLevel: validatedData.encryptionLevel,
      status: deliveryResult.success ? "delivered" : "failed",
      deliveryMethod: deliveryResult.deliveryMethod || deliveryResult.signingMethod,
      signingMethod: deliveryResult.signingMethod,
      securityLevel: deliveryResult.securityLevel,
      userMessage: deliveryResult.userMessage,
      encryptionUsed: deliveryResult.encryptionUsed,
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        environment: getEnvVar("NODE_ENV") || "production",
        nip59Compliant: true,
        privacyFirst: true,
        hybridSigning: isPreSigned
      }
    };
    return { statusCode: 200, headers: corsHeaders, body: JSON.stringify(responseData) };
  } catch (error) {
    console.error("Gift-wrapped messaging error (no sensitive data):", { timestamp: (/* @__PURE__ */ new Date()).toISOString(), errorType: error?.constructor?.name });
    return { statusCode: 500, headers: corsHeaders, body: JSON.stringify({ success: false, error: "Gift-wrapped message processing failed", meta: { timestamp: (/* @__PURE__ */ new Date()).toISOString() } }) };
  }
}
