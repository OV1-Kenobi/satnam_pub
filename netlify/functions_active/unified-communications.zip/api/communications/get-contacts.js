"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_contacts_exports = {};
__export(get_contacts_exports, {
  default: () => handler
});
module.exports = __toCommonJS(get_contacts_exports);
var import_rate_limiter = require("../../netlify/functions/utils/rate-limiter.js");
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }
  if (req.method !== "GET") {
    res.status(405).json({ success: false, error: "Method not allowed" });
    return;
  }
  const clientIP = req.headers["x-forwarded-for"] || req.headers["x-real-ip"] || "unknown";
  if (!(0, import_rate_limiter.allowRequest)(String(clientIP))) {
    res.status(429).json({ success: false, error: "Rate limit exceeded" });
    return;
  }
  try {
    const authHeader = req.headers?.authorization || req.headers?.Authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ success: false, error: "Authentication required" });
      return;
    }
    try {
      const { SecureSessionManager } = await import("../../netlify/functions/security/session-manager.js");
      console.log("\u{1F510} DEBUG: SecureSessionManager imported successfully (get-contacts)");
      const session = await SecureSessionManager.validateSessionFromHeader(authHeader);
      console.log("\u{1F510} DEBUG: Session validation result (get-contacts):", session ? "valid" : "invalid");
      if (!session || !session.hashedId) {
        console.log("\u{1F510} DEBUG: Session missing or no hashedId (get-contacts):", { hasSession: !!session, hasHashedId: session?.hashedId });
        res.status(401).json({ success: false, error: "Invalid token" });
        return;
      }
      console.log("\u{1F510} DEBUG: Session hashedId (get-contacts):", session.hashedId);
      const { supabase } = await import("../../netlify/functions/supabase.js");
      const client = supabase;
      const memberId = String(req.query?.memberId || "").trim();
      if (memberId && memberId !== "current-user" && memberId !== session.hashedId) {
        res.status(403).json({ success: false, error: "Forbidden: memberId mismatch" });
        return;
      }
      const ownerHash = session.hashedId;
      console.log("\u{1F510} DEBUG: get-contacts - querying encrypted_contacts table with ownerHash:", ownerHash);
      const { data, error } = await client.from("encrypted_contacts").select("*").eq("owner_hash", ownerHash).order("added_at", { ascending: false }).limit(100);
      if (error) {
        console.error("\u{1F510} DEBUG: get-contacts - database error:", error);
        res.status(500).json({ success: false, error: "Failed to load contacts" });
        return;
      }
      console.log("\u{1F510} DEBUG: get-contacts - query successful, contacts found:", data?.length || 0);
      res.status(200).json({ success: true, contacts: data || [] });
    } catch (importError) {
      console.error("\u{1F510} DEBUG: SecureSessionManager import failed (get-contacts):", importError);
      res.status(500).json({ success: false, error: "Session validation failed" });
    }
  } catch (e) {
    const code = e && typeof e === "object" && "statusCode" in e ? e.statusCode : 500;
    console.error("get-contacts error:", e);
    res.status(code).json({ success: false, error: e?.message || "Failed to load contacts" });
  }
}
