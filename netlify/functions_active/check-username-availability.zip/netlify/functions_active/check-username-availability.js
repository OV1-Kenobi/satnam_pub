"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var check_username_availability_exports = {};
__export(check_username_availability_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(check_username_availability_exports);
var import_supabase = require("../../netlify/functions/supabase.js");
console.log("\u{1F512} Secure username availability function initialized (shared Supabase client)");
const RATE_LIMIT_WINDOW = 6e4;
const RATE_LIMIT_MAX_REQUESTS = 10;
async function checkRateLimit(clientIP) {
  const now = Date.now();
  const clientKey = clientIP || "unknown";
  const endpoint = "check-username-availability";
  try {
    console.log("\u{1F512} Checking database-based rate limit for client:", clientKey);
    const { data, error } = await import_supabase.supabase.from("rate_limits").select("count, reset_time").eq("client_key", clientKey).eq("endpoint", endpoint).single();
    if (error && error.code !== "PGRST116") {
      console.error("Rate limit check error:", error);
      return true;
    }
    if (!data || now > data.reset_time) {
      console.log("\u{1F512} Creating/resetting rate limit for client:", clientKey);
      const { error: upsertError } = await import_supabase.supabase.from("rate_limits").upsert({
        client_key: clientKey,
        endpoint,
        count: 1,
        reset_time: now + RATE_LIMIT_WINDOW,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }, {
        onConflict: "client_key,endpoint"
      });
      if (upsertError) {
        console.error("Rate limit upsert error:", upsertError);
        return true;
      }
      return true;
    }
    if (data.count >= RATE_LIMIT_MAX_REQUESTS) {
      console.warn("\u{1F6AB} Rate limit exceeded for client:", clientKey, "count:", data.count);
      return false;
    }
    console.log("\u{1F512} Incrementing rate limit count for client:", clientKey, "current:", data.count);
    const { error: updateError } = await import_supabase.supabase.from("rate_limits").update({
      count: data.count + 1,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("client_key", clientKey).eq("endpoint", endpoint);
    if (updateError) {
      console.error("Rate limit update error:", updateError);
      return true;
    }
    return true;
  } catch (error) {
    console.error("Rate limiting system error:", error);
    return true;
  }
}
async function checkUsernameAvailability(username) {
  try {
    const domain = "satnam.pub";
    const local = (username || "").trim().toLowerCase();
    if (!local) {
      return { available: false, error: "Username is required" };
    }
    if (local.length < 3 || local.length > 20) {
      return { available: false, error: "Username must be between 3 and 20 characters" };
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(local)) {
      return { available: false, error: "Username can only contain letters, numbers, underscores, and hyphens" };
    }
    const crypto = await import("node:crypto");
    const duidServerSecret = process.env.DUID_SERVER_SECRET;
    const duidSecretKey = process.env.DUID_SECRET_KEY;
    if (!duidServerSecret && duidSecretKey) {
      console.warn("DUID_SECRET_KEY is deprecated; please set DUID_SERVER_SECRET.");
    }
    const secretRaw = duidServerSecret ?? duidSecretKey;
    const secret = typeof secretRaw === "string" && secretRaw.trim() ? secretRaw.trim() : void 0;
    if (!secret) {
      console.warn("DUID server secret missing. Set DUID_SERVER_SECRET in the server environment; rejecting availability check.");
      return { available: false, error: "Server configuration error" };
    }
    const identifier = `${local}@${domain}`;
    const hmac = crypto.createHmac("sha256", secret);
    hmac.update(identifier);
    const hashed_nip05 = hmac.digest("hex");
    const { data, error } = await import_supabase.supabase.from("nip05_records").select("id").eq("domain", domain).eq("hashed_nip05", hashed_nip05).eq("is_active", true).limit(1);
    if (error) {
      console.error("Username availability check failed:", error);
      return { available: false, error: "Failed to check username availability" };
    }
    let isAvailable = !data || data.length === 0;
    if (isAvailable) {
      try {
        const identifierFull = `${local}@${domain}`;
        const { generateDUIDFromNIP05 } = await import("../../lib/security/duid-generator.js");
        const duid = await generateDUIDFromNIP05(identifierFull);
        const { data: users, error: userErr } = await import_supabase.supabase.from("user_identities").select("id").eq("id", duid).limit(1);
        if (!userErr && users && users.length > 0) {
          isAvailable = false;
        }
      } catch (duidErr) {
        console.warn("DUID availability cross-check failed; relying on nip05_records only:", duidErr);
      }
    }
    if (!isAvailable) {
      const suggestion = await generateUsernameSuggestion(local);
      return {
        available: false,
        error: "Username is already taken",
        suggestion
      };
    }
    return { available: true };
  } catch (error) {
    console.error("Username availability check error:", error);
    return { available: false, error: "Failed to check username availability" };
  }
}
async function generateUsernameSuggestion(baseUsername) {
  const suggestions = [
    `${baseUsername}${Math.floor(Math.random() * 100)}`,
    `${baseUsername}_${Math.floor(Math.random() * 1e3)}`,
    `${baseUsername}${(/* @__PURE__ */ new Date()).getFullYear()}`,
    `${baseUsername}_user`,
    `${baseUsername}_new`
  ];
  for (const suggestion of suggestions) {
    const result = await checkUsernameAvailability(suggestion);
    if (result.available) {
      return suggestion;
    }
  }
  return `${baseUsername}_${Math.floor(Math.random() * 1e4)}`;
}
const handler = async (event, context) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }
  if (event.httpMethod !== "POST" && event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "Method not allowed"
      })
    };
  }
  try {
    const clientIP = event.headers["x-forwarded-for"] || event.headers["x-real-ip"] || "unknown";
    if (!await checkRateLimit(clientIP)) {
      return {
        statusCode: 429,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Too many requests. Please try again later."
        })
      };
    }
    let requestData;
    if (event.httpMethod === "POST") {
      try {
        requestData = JSON.parse(event.body || "{}");
      } catch (parseError) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({
            success: false,
            error: "Invalid JSON in request body"
          })
        };
      }
    } else {
      requestData = event.queryStringParameters || {};
    }
    const { username } = requestData;
    if (!username || typeof username !== "string") {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Username is required and must be a string"
        })
      };
    }
    const result = await checkUsernameAvailability(username);
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        available: result.available,
        error: result.error,
        suggestion: result.suggestion
      })
    };
  } catch (error) {
    console.error("Username availability check handler error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "Internal server error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
