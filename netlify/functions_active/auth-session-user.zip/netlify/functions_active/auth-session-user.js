"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_session_user_exports = {};
__export(auth_session_user_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(auth_session_user_exports);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_duid_generator = require("../../lib/security/duid-generator.js");
var import_session_manager = require("./security/session-manager.js");
var import_supabase = require("./supabase.js");
var import_rate_limiter = require("./utils/rate-limiter.js");
function parseCookies(cookieHeader) {
  if (!cookieHeader) return {};
  return cookieHeader.split(";").reduce((acc, part) => {
    const [k, ...rest] = part.trim().split("=");
    acc[k] = rest.join("=");
    return acc;
  }, {});
}
function corsHeaders(origin) {
  const allowed = process.env.ALLOWED_ORIGINS?.split(",").map((s) => s.trim()) || ["*"];
  const corsOrigin = allowed.includes("*") ? origin || "*" : allowed.includes(origin || "") ? origin : allowed[0] || "*";
  return {
    "Access-Control-Allow-Origin": corsOrigin || "*",
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json",
    Vary: "Origin"
  };
}
const handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || "*";
  const headers = corsHeaders(origin);
  const clientIP = String(
    event.headers?.["x-forwarded-for"] || event.headers?.["x-real-ip"] || "unknown"
  );
  if (!(0, import_rate_limiter.allowRequest)(clientIP, 30, 6e4)) {
    return { statusCode: 429, headers, body: JSON.stringify({ success: false, error: "Too many attempts" }) };
  }
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, headers, body: JSON.stringify({ success: false, error: "Method not allowed" }) };
  }
  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization;
    let nip05 = void 0;
    if (authHeader && authHeader.startsWith("Bearer ")) {
      try {
        const session = await import_session_manager.SecureSessionManager.validateSessionFromHeader(authHeader);
        if (session?.nip05) nip05 = session.nip05;
      } catch {
      }
    }
    if (!nip05) {
      const cookies = parseCookies(event.headers?.cookie);
      const refresh = cookies?.["satnam_refresh_token"];
      if (!refresh) {
        return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: "Unauthorized" }) };
      }
      try {
        const { getJwtSecret } = await import("./utils/jwt-secret.js");
        const secret = getJwtSecret();
        const payload = import_jsonwebtoken.default.verify(refresh, secret, {
          algorithms: ["HS256"],
          issuer: "satnam.pub",
          audience: "satnam.pub-users"
        });
        const obj = typeof payload === "string" ? JSON.parse(payload) : payload;
        if (obj?.type !== "refresh" || !obj?.nip05) {
          return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: "Invalid token" }) };
        }
        nip05 = obj.nip05;
      } catch {
        return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: "Unauthorized" }) };
      }
    }
    if (!nip05) {
      return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: "Unauthorized" }) };
    }
    const duid = await (0, import_duid_generator.generateDUIDFromNIP05)(nip05);
    const { data: user, error: userError, status } = await import_supabase.supabase.from("user_identities").select(`
        id,
        role,
        is_active,
        user_salt,
        encrypted_nsec,
        encrypted_nsec_iv,
        hashed_npub,
        hashed_username,
        hashed_nip05
      `).eq("id", duid).single();
    if (userError || !user) {
      const code = status === 406 ? 404 : 500;
      return { statusCode: code, headers, body: JSON.stringify({ success: false, error: "User not found" }) };
    }
    const userPayload = {
      id: user.id,
      nip05,
      role: user.role || "private",
      is_active: user.is_active !== false,
      user_salt: user.user_salt || null,
      encrypted_nsec: user.encrypted_nsec || null,
      encrypted_nsec_iv: user.encrypted_nsec_iv || null,
      npub: user.hashed_npub || null,
      // Map hashed field to expected name
      username: user.hashed_username || null,
      // Map hashed field to expected name
      hashed_npub: user.hashed_npub || null,
      hashed_username: user.hashed_username || null,
      hashed_nip05: user.hashed_nip05 || null
    };
    return { statusCode: 200, headers, body: JSON.stringify({ success: true, data: { user: userPayload } }) };
  } catch (error) {
    console.error("auth-session-user error:", error);
    return { statusCode: 500, headers, body: JSON.stringify({ success: false, error: "Internal server error" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
