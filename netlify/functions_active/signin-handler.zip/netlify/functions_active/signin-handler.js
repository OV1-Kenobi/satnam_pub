"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var signin_handler_exports = {};
__export(signin_handler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(signin_handler_exports);
var import_node_crypto = __toESM(require("node:crypto"), 1);
var import_node_util = require("node:util");
const pbkdf2 = (0, import_node_util.promisify)(import_node_crypto.default.pbkdf2);
let supabase;
async function getSupabase() {
  if (!supabase) {
    const { createClient } = await import("@supabase/supabase-js");
    supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_ANON_KEY
    );
  }
  return supabase;
}
async function generateDUID(nip05Identifier) {
  const secret = process.env.DUID_SERVER_SECRET;
  if (!secret) {
    throw new Error("DUID_SERVER_SECRET not configured");
  }
  const identifier = nip05Identifier.trim().toLowerCase();
  const hmac = import_node_crypto.default.createHmac("sha256", secret);
  hmac.update(identifier);
  return hmac.digest("hex");
}
async function verifyPassword(password, hash, salt) {
  try {
    const derivedKey = await pbkdf2(password, salt, 1e5, 64, "sha512");
    const derivedHash = derivedKey.toString("hex");
    return derivedHash === hash;
  } catch (error) {
    console.error("Password verification error:", error);
    return false;
  }
}
async function createSecureJWT(payload) {
  try {
    const { SignJWT } = await import("jose");
    const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret";
    const JWT_ISSUER = process.env.JWT_ISSUER || "satnam.pub";
    const JWT_AUDIENCE = process.env.JWT_AUDIENCE || "satnam.pub";
    const secret = new TextEncoder().encode(JWT_SECRET);
    const jwt = await new SignJWT(payload).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setIssuer(JWT_ISSUER).setAudience(JWT_AUDIENCE).setExpirationTime("24h").sign(secret);
    console.log("\u2705 Secure JWT created successfully for signin");
    return jwt;
  } catch (error) {
    console.error("\u274C JWT creation error:", error.message);
    throw new Error(`JWT creation failed: ${error.message}`);
  }
}
const handler = async (event, context) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ success: false, error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { nip05, password, authMethod } = body;
    console.log("\u{1F504} Sign-in attempt:", { nip05, authMethod });
    if (!nip05 || !password) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "NIP-05 and password are required"
        })
      };
    }
    const userDUID = await generateDUID(nip05);
    const db = await getSupabase();
    try {
      await db.rpc("app_set_config", {
        setting_name: "app.lookup_user_duid",
        setting_value: userDUID,
        is_local: true
      });
    } catch (e) {
      try {
        await db.rpc("set_app_config", {
          setting_name: "app.lookup_user_duid",
          setting_value: userDUID,
          is_local: true
        });
      } catch {
      }
    }
    const { data: user, error: userError } = await db.from("user_identities").select("*").eq("id", userDUID).single();
    if (userError || !user) {
      console.log("\u274C User not found for NIP-05 identifier");
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "User not found",
          registerEndpoint: "/identity-forge"
        })
      };
    }
    const isValidPassword = await verifyPassword(
      password,
      user.password_hash,
      user.password_salt
    );
    if (!isValidPassword) {
      console.log("\u274C Invalid password for user:", nip05);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid credentials"
        })
      };
    }
    const sessionId = import_node_crypto.default.randomBytes(16).toString("hex");
    const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret";
    const hashedId = import_node_crypto.default.createHmac("sha256", JWT_SECRET).update(`${user.id}|${sessionId}`).digest("hex");
    const tokenPayload = {
      // FRONTEND-REQUIRED FIELDS (SecureTokenManager.parseTokenPayload expects these)
      userId: user.id,
      hashedId,
      // Required by frontend - HMAC of userId|sessionId
      type: "access",
      // Required by frontend - token type
      sessionId,
      // Required by frontend - unique session identifier
      nip05: user.nip05,
      // Required by frontend
      // BACKEND-REQUIRED FIELDS (for compatibility with auth-unified and other endpoints)
      username: user.username,
      role: user.role
    };
    const token = await createSecureJWT(tokenPayload);
    console.log("\u2705 Sign-in successful:", { username: user.username, role: user.role });
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        message: "Authentication successful",
        user: {
          id: user.id,
          username: user.username,
          nip05: user.nip05,
          role: user.role
        },
        session: {
          token,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString()
        }
      })
    };
  } catch (error) {
    console.error("\u274C Sign-in error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "Authentication service temporarily unavailable",
        debug: {
          message: error.message,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
