"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var session_manager_exports = {};
__export(session_manager_exports, {
  SecureSessionManager: () => SecureSessionManager
});
module.exports = __toCommonJS(session_manager_exports);
var import_env = require("../utils/env.js");
class SecureSessionManager {
  static SESSION_EXPIRY = 60 * 60;
  // 1 hour
  static REFRESH_EXPIRY = 7 * 24 * 60 * 60;
  // 7 days
  /**
   * CRITICAL SECURITY: JWT secret derived from DUID_SERVER_SECRET
   */
  static async getJWTSecret() {
    try {
      console.log("\u{1F510} DEBUG: getJWTSecret - checking JWT_SECRET env var");
      const jwtSecret = (0, import_env.getEnvVar)("JWT_SECRET");
      if (jwtSecret) {
        console.log(
          "\u{1F510} DEBUG: getJWTSecret - using JWT_SECRET, length:",
          jwtSecret.length
        );
        return jwtSecret;
      }
      console.log(
        "\u{1F510} DEBUG: getJWTSecret - JWT_SECRET not found, trying derived secret"
      );
      const mod = await import("../utils/jwt-secret.js");
      const secret = await mod.getJwtSecret();
      console.log(
        "\u{1F510} DEBUG: getJWTSecret - derived secret, length:",
        secret.length
      );
      return secret;
    } catch (error) {
      console.error("\u{1F510} DEBUG: getJWTSecret - error:", error);
      if ((0, import_env.getEnvVar)("NODE_ENV") === "production") {
        throw new Error(
          "JWT secret derivation failed: JWT_SECRET or DUID_SERVER_SECRET missing"
        );
      }
      console.log("\u{1F510} DEBUG: getJWTSecret - using dev fallback secret");
      return "fallback-secret";
    }
  }
  /**
   * CRITICAL SECURITY: Refresh secret from Vault (mandatory in production)
   */
  static async getRefreshSecret() {
    const envSecret = (0, import_env.getEnvVar)("JWT_REFRESH_SECRET");
    if (envSecret) return envSecret;
    if ((0, import_env.getEnvVar)("NODE_ENV") === "production") {
      throw new Error(
        "JWT_REFRESH_SECRET must be configured in environment variables for production"
      );
    }
    return "dev-only-refresh-secret-change-in-production";
  }
  /**
   * CRITICAL SECURITY: PBKDF2 salt from Vault (Master Context mandatory)
   * WARNING: Default salt generation is NOT secure for production
   */
  static async getAuthSalt() {
    const envSalt = (0, import_env.getEnvVar)("AUTH_SALT");
    if (envSalt) {
      return new Uint8Array(
        envSalt.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
      );
    }
    if ((0, import_env.getEnvVar)("NODE_ENV") === "production") {
      throw new Error(
        "AUTH_SALT must be configured in environment variables for production"
      );
    }
    const defaultSalt = new Uint8Array(32);
    crypto.getRandomValues(defaultSalt);
    return defaultSalt;
  }
  /**
   * Identifier pepper for HMAC-based protected IDs
   */
  static async getIdentifierPepper() {
    const duidSecret = (0, import_env.getEnvVar)("DUID_SERVER_SECRET");
    if (duidSecret) return duidSecret;
    const globalSalt = (0, import_env.getEnvVar)("GLOBAL_SALT");
    if (globalSalt) return globalSalt;
    const jwt = (0, import_env.getEnvVar)("JWT_SECRET");
    if (jwt) return jwt;
    if ((0, import_env.getEnvVar)("NODE_ENV") === "production") {
      throw new Error(
        "Identifier pepper must be configured via env 'DUID_SERVER_SECRET' (primary) or 'GLOBAL_SALT' in production"
      );
    }
    return "dev-only-identifier-pepper-change-in-production";
  }
  /** Generate a cryptographically secure random session ID (hex) */
  static generateRandomSessionIdHex() {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  /** Compute HMAC-SHA256(pepper, message) and return hex */
  static async hmacSha256Hex(key, message) {
    const enc = new TextEncoder();
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      enc.encode(key),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const sig = await crypto.subtle.sign(
      "HMAC",
      cryptoKey,
      enc.encode(message)
    );
    const bytes = new Uint8Array(sig);
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  /**
   * MASTER CONTEXT COMPLIANCE: PBKDF2 with SHA-512 authentication hashing
   * CRITICAL SECURITY: 100,000 iterations, no fallback algorithms allowed
   */
  static async createAuthHash(data) {
    const salt = await this.getAuthSalt();
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      dataBuffer,
      { name: "PBKDF2" },
      false,
      ["deriveBits"]
    );
    const saltBuffer = new ArrayBuffer(salt.length);
    const saltView = new Uint8Array(saltBuffer);
    saltView.set(salt);
    const derivedBits = await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: saltBuffer,
        iterations: 1e5,
        // High iteration count for security
        hash: "SHA-512"
        // Master Context requires SHA-512
      },
      keyMaterial,
      512
      // 64 bytes = 512 bits
    );
    const hashArray = new Uint8Array(derivedBits);
    return Array.from(hashArray).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  /**
   * JWT token creation using Web Crypto API (browser-compatible)
   */
  static async createJWTToken(payload, secret, expiresIn) {
    const header = { alg: "HS256", typ: "JWT" };
    const now = Math.floor(Date.now() / 1e3);
    const tokenPayload = { ...payload, iat: now, exp: now + expiresIn };
    const encodedHeader = btoa(JSON.stringify(header)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    const encodedPayload = btoa(JSON.stringify(tokenPayload)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    const encoder = new TextEncoder();
    const data = encoder.encode(`${encodedHeader}.${encodedPayload}`);
    const keyData = encoder.encode(secret);
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await crypto.subtle.sign("HMAC", cryptoKey, data);
    const encodedSignature = btoa(
      Array.from(new Uint8Array(signature)).map((c) => String.fromCharCode(c)).join("")
    ).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    return `${encodedHeader}.${encodedPayload}.${encodedSignature}`;
  }
  /**
   * JWT token verification using Web Crypto API
   */
  static async verifyJWTToken(token, secret) {
    try {
      console.log("\u{1F510} DEBUG: verifyJWTToken - starting verification");
      console.log("\u{1F510} DEBUG: verifyJWTToken - token length:", token.length);
      console.log("\u{1F510} DEBUG: verifyJWTToken - secret length:", secret.length);
      const parts = token.split(".");
      console.log(
        "\u{1F510} DEBUG: verifyJWTToken - token parts count:",
        parts.length
      );
      if (parts.length !== 3) {
        console.log(
          "\u{1F510} DEBUG: verifyJWTToken - invalid token format (not 3 parts)"
        );
        return null;
      }
      const [encodedHeader, encodedPayload, encodedSignature] = parts;
      console.log(
        "\u{1F510} DEBUG: verifyJWTToken - header length:",
        encodedHeader.length
      );
      console.log(
        "\u{1F510} DEBUG: verifyJWTToken - payload length:",
        encodedPayload.length
      );
      console.log(
        "\u{1F510} DEBUG: verifyJWTToken - signature length:",
        encodedSignature.length
      );
      const encoder = new TextEncoder();
      const data = encoder.encode(`${encodedHeader}.${encodedPayload}`);
      const keyData = encoder.encode(secret);
      console.log("\u{1F510} DEBUG: verifyJWTToken - importing crypto key");
      const cryptoKey = await crypto.subtle.importKey(
        "raw",
        keyData,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["verify"]
      );
      console.log("\u{1F510} DEBUG: verifyJWTToken - decoding signature");
      const signature = Uint8Array.from(
        atob(
          encodedSignature.replace(/-/g, "+").replace(/_/g, "/").padEnd(
            encodedSignature.length + (4 - encodedSignature.length % 4) % 4,
            "="
          )
        ),
        (c) => c.charCodeAt(0)
      );
      console.log("\u{1F510} DEBUG: verifyJWTToken - verifying signature");
      const isValid = await crypto.subtle.verify(
        "HMAC",
        cryptoKey,
        signature,
        data
      );
      console.log("\u{1F510} DEBUG: verifyJWTToken - signature valid:", isValid);
      if (!isValid) {
        console.log("\u{1F510} DEBUG: verifyJWTToken - signature verification failed");
        return null;
      }
      console.log("\u{1F510} DEBUG: verifyJWTToken - parsing payload");
      const payload = JSON.parse(
        atob(
          encodedPayload.replace(/-/g, "+").replace(/_/g, "/").padEnd(
            encodedPayload.length + (4 - encodedPayload.length % 4) % 4,
            "="
          )
        )
      );
      console.log("\u{1F510} DEBUG: verifyJWTToken - checking expiration");
      const now = Math.floor(Date.now() / 1e3);
      if (payload.exp && payload.exp < now) {
        console.log("\u{1F510} DEBUG: verifyJWTToken - token expired", {
          exp: payload.exp,
          now
        });
        return null;
      }
      console.log("\u{1F510} DEBUG: verifyJWTToken - verification successful");
      return payload;
    } catch (error) {
      console.error("\u{1F510} DEBUG: verifyJWTToken - error:", error);
      return null;
    }
  }
  /**
   * Create JWT session for authenticated user
   */
  static async createSession(_res, userData) {
    const sessionData = {
      userId: userData.npub,
      npub: userData.npub,
      nip05: userData.nip05,
      federationRole: userData.federationRole,
      authMethod: userData.authMethod,
      isWhitelisted: userData.isWhitelisted,
      votingPower: userData.votingPower,
      guardianApproved: userData.guardianApproved,
      stewardApproved: userData.stewardApproved,
      sessionToken: "",
      isAuthenticated: true
    };
    const jwtSecret = await this.getJWTSecret();
    const sessionId = this.generateRandomSessionIdHex();
    const pepper = await this.getIdentifierPepper();
    const hashedId = await this.hmacSha256Hex(
      pepper,
      `${sessionData.userId}|${sessionId}`
    );
    const payload = {
      // Required TokenPayload fields
      userId: sessionData.userId,
      hashedId,
      nip05: sessionData.nip05,
      type: "access",
      sessionId,
      // Backward-compat: include original session fields used by server endpoints
      ...sessionData
    };
    const sessionToken = await this.createJWTToken(
      payload,
      jwtSecret,
      this.SESSION_EXPIRY
    );
    sessionData.sessionToken = sessionToken;
    return sessionToken;
  }
  /**
   * Validate JWT token and extract session data
   */
  static async validateSession(token) {
    if (!token) {
      console.log("\u{1F510} DEBUG: validateSession - no token provided");
      return null;
    }
    try {
      console.log("\u{1F510} DEBUG: validateSession - getting JWT secret");
      const jwtSecret = await this.getJWTSecret();
      console.log(
        "\u{1F510} DEBUG: validateSession - JWT secret obtained, verifying token"
      );
      const decoded = await this.verifyJWTToken(token, jwtSecret);
      console.log(
        "\u{1F510} DEBUG: validateSession - token verification result:",
        decoded ? "success" : "failed"
      );
      if (decoded) {
        console.log(
          "\u{1F510} DEBUG: validateSession - decoded payload keys:",
          Object.keys(decoded)
        );
      }
      return decoded ? decoded : null;
    } catch (error) {
      console.error("\u{1F510} DEBUG: validateSession - error:", error);
      return null;
    }
  }
  /**
   * Refresh session using refresh token
   */
  static async refreshSession(refreshToken) {
    if (!refreshToken) return null;
    try {
      const refreshSecret = await this.getRefreshSecret();
      const decoded = await this.verifyJWTToken(refreshToken, refreshSecret);
      if (!decoded || !decoded.userId) return null;
      if (decoded.type !== "refresh") return null;
      const jwtSecret = await this.getJWTSecret();
      const sessionId = decoded.sessionId || this.generateRandomSessionIdHex();
      const pepper = await this.getIdentifierPepper();
      const hashedId = await this.hmacSha256Hex(
        pepper,
        `${decoded.userId}|${sessionId}`
      );
      const payload = {
        userId: decoded.userId,
        hashedId,
        nip05: decoded.nip05,
        type: "access",
        sessionId,
        // Keep minimal fields for backward compatibility
        npub: decoded.npub,
        isAuthenticated: true
      };
      return await this.createJWTToken(payload, jwtSecret, this.SESSION_EXPIRY);
    } catch (error) {
      return null;
    }
  }
  static async createRefreshToken(userData) {
    const refreshSecret = await this.getRefreshSecret();
    const sessionId = this.generateRandomSessionIdHex();
    const pepper = await this.getIdentifierPepper();
    const hashedId = await this.hmacSha256Hex(
      pepper,
      `${userData.userId}|${sessionId}`
    );
    const payload = {
      userId: userData.userId,
      hashedId,
      nip05: userData.nip05,
      type: "refresh",
      sessionId,
      // Minimal backward-compatible fields
      npub: userData.npub
    };
    return await this.createJWTToken(
      payload,
      refreshSecret,
      this.REFRESH_EXPIRY
    );
  }
  /**
   * PRIVACY COMPLIANCE: Return safe user data (no sensitive tokens)
   */
  static getSessionInfo(sessionData) {
    if (!sessionData) return { isAuthenticated: false };
    return {
      isAuthenticated: true,
      user: {
        npub: sessionData.npub,
        nip05: sessionData.nip05,
        federationRole: sessionData.federationRole,
        authMethod: sessionData.authMethod,
        isWhitelisted: sessionData.isWhitelisted,
        votingPower: sessionData.votingPower,
        guardianApproved: sessionData.guardianApproved,
        stewardApproved: sessionData.stewardApproved
      }
    };
  }
  static async validateSessionFromHeader(authHeader) {
    if (!authHeader || !authHeader.startsWith("Bearer ")) return null;
    const token = authHeader.substring(7);
    return await this.validateSession(token);
  }
  /**
   * PRIVACY COMPLIANCE: Generate secure session ID using PBKDF2 hash
   */
  static async generateSessionId(npub) {
    const sessionSeed = `${npub}-${Date.now()}-${crypto.getRandomValues(new Uint8Array(16)).join("")}`;
    return await this.createAuthHash(sessionSeed);
  }
  /**
   * MASTER CONTEXT COMPLIANCE: Role hierarchy permission checking
   */
  static hasRolePermission(sessionData, requiredRole) {
    const roleHierarchy = {
      offspring: 1,
      adult: 2,
      steward: 3,
      guardian: 4,
      private: 0
      // Special case for private users
    };
    const userLevel = roleHierarchy[sessionData.federationRole] || 0;
    const requiredLevel = roleHierarchy[requiredRole] || 0;
    return userLevel >= requiredLevel;
  }
  /**
   * SECURITY: Clear sensitive data from memory (best effort in JavaScript)
   */
  static clearSensitiveData(data) {
    if (typeof data === "object" && data !== null) {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          if (typeof data[key] === "string") {
            data[key] = "";
          } else if (typeof data[key] === "object") {
            this.clearSensitiveData(data[key]);
          }
        }
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SecureSessionManager
});
