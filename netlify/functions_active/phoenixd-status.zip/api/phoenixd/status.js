"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var status_exports = {};
__export(status_exports, {
  default: () => handler
});
module.exports = __toCommonJS(status_exports);
function setCorsHeaders(req, res) {
  const allowedOrigins = process.env.NODE_ENV === "production" ? [process.env.FRONTEND_URL || "https://satnam.pub"] : ["http://localhost:3000", "http://localhost:5173", "http://localhost:3002"];
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  );
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
}
async function handler(req, res) {
  setCorsHeaders(req, res);
  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }
  if (req.method !== "GET") {
    res.setHeader("Allow", ["GET"]);
    res.status(405).json({
      success: false,
      error: "Method not allowed",
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    });
    return;
  }
  try {
    const phoenixdStatus = {
      status: "running",
      version: "0.2.3",
      nodeId: "03b2c4d6e8f0a1b3c5d7e9f1a3b5c7d9e1f3a5b7c9d1e3f5a7b9c1d3e5f7a9b1c3",
      alias: "SatnamFamily-Phoenix",
      isConnected: true,
      network: "mainnet",
      blockHeight: 85e4 + Math.floor(Math.random() * 1e3),
      balance: {
        onchain: 2e6,
        // sats
        lightning: 15e5,
        // sats
        total: 35e5
        // sats
      },
      channels: {
        active: 3,
        inactive: 0,
        pending: 0,
        total: 3
      },
      peers: [
        {
          nodeId: "03a1b2c3d4e5f6789abcdef0123456789abcdef0123456789abcdef0123456789ab",
          alias: "ACINQ",
          isConnected: true
        },
        {
          nodeId: "03c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5",
          alias: "Bitrefill",
          isConnected: true
        }
      ],
      fees: {
        baseFee: 1e3,
        // msat
        feeRate: 100
        // ppm
      },
      uptime: Math.floor(Math.random() * 2592e6),
      // Random uptime up to 30 days
      lastRestart: new Date(Date.now() - Math.floor(Math.random() * 864e5)).toISOString(),
      // Last restart within 24 hours
      config: {
        autoLiquidity: true,
        maxFeePercent: 0.5,
        maxRelayFee: 3e3
      }
    };
    res.status(200).json({
      success: true,
      data: phoenixdStatus,
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        demo: true
      }
    });
  } catch (error) {
    console.error("PhoenixD status error:", error);
    res.status(500).json({
      success: false,
      error: "Failed to get PhoenixD daemon status",
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        demo: true
      }
    });
  }
}
