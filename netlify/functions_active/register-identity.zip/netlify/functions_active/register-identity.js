"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var register_identity_exports = {};
__export(register_identity_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(register_identity_exports);
var crypto = __toESM(require("node:crypto"), 1);
var import_node_util = require("node:util");
var import_supabase = require("../../netlify/functions/supabase.js");
async function createSecureJWT(payload) {
  try {
    const { SignJWT } = await import("jose");
    const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret";
    const JWT_ISSUER = process.env.JWT_ISSUER || "satnam.pub";
    const JWT_AUDIENCE = process.env.JWT_AUDIENCE || "satnam.pub";
    const secret = new TextEncoder().encode(JWT_SECRET);
    const jwt = await new SignJWT(payload).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setIssuer(JWT_ISSUER).setAudience(JWT_AUDIENCE).setExpirationTime("24h").sign(secret);
    console.log("\u2705 Secure JWT created successfully for registration");
    return jwt;
  } catch (error) {
    console.error("\u274C JWT creation error:", error.message);
    throw new Error(`JWT creation failed: ${error.message}`);
  }
}
async function getDUIDSecret() {
  const secret = process.env.DUID_SERVER_SECRET || process.env.DUID_SECRET_KEY;
  if (!secret) {
    throw new Error("Server configuration error: DUID secret missing");
  }
  return secret;
}
function generatePasswordSalt() {
  return crypto.randomBytes(24).toString("base64");
}
async function hashPassword(password, salt) {
  const iterations = 1e5;
  const keyLength = 64;
  const algorithm = "sha512";
  const pbkdf2 = (0, import_node_util.promisify)(crypto.pbkdf2);
  const hash = await pbkdf2(password, salt, iterations, keyLength, algorithm);
  return hash.toString("hex");
}
async function verifyPassword(password, storedHash, salt) {
  try {
    const computedHash = await hashPassword(password, salt);
    return crypto.timingSafeEqual(
      Buffer.from(computedHash, "hex"),
      Buffer.from(storedHash, "hex")
    );
  } catch (error) {
    console.error("Password verification failed:", error);
    return false;
  }
}
function validateRole(role) {
  const validRoles = ["private", "offspring", "adult", "steward", "guardian"];
  return (
    /** @type {'private'|'offspring'|'adult'|'steward'|'guardian'} */
    validRoles.includes(role) ? role : "private"
  );
}
function generateSovereigntySpendingLimits(role) {
  switch (role) {
    case "private":
    case "adult":
    case "steward":
    case "guardian":
      return {
        daily: -1,
        // Unlimited sovereignty
        weekly: -1,
        // Unlimited sovereignty
        requiresApproval: -1
        // No approval required
      };
    case "offspring":
      return {
        daily: 5e4,
        // 50k sats daily limit
        weekly: 2e5,
        // 200k sats weekly limit
        requiresApproval: 1e5
        // Requires approval above 100k sats
      };
    default:
      return {
        daily: 5e4,
        weekly: 2e5,
        requiresApproval: 1e5
      };
  }
}
async function generatePrivacyPreservingHash(userData) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`registration_${userData}_${Date.now()}`);
  let subtle;
  try {
    if (globalThis.crypto && globalThis.crypto.subtle) {
      subtle = globalThis.crypto.subtle;
    } else {
      const nodeCrypto = await import("node:crypto");
      subtle = nodeCrypto.webcrypto.subtle;
    }
  } catch (e) {
    const nodeCryptoFallback = await import("node:crypto");
    subtle = nodeCryptoFallback.webcrypto.subtle;
  }
  const hashBuffer = await subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("").substring(0, 16);
}
function extractClientInfo(event) {
  return {
    userAgent: event.headers["user-agent"],
    ipAddress: event.headers["x-forwarded-for"] || event.headers["x-real-ip"] || event.headers["client-ip"]
  };
}
function validateRegistrationData(userData) {
  const errors = [];
  if (!userData || typeof userData !== "object") {
    errors.push({ field: "body", message: "Request body must be an object" });
    return { success: false, errors };
  }
  if (!userData.username || typeof userData.username !== "string" || userData.username.trim().length < 3) {
    errors.push({ field: "username", message: "Username must be at least 3 characters long" });
  }
  if (!userData.password || typeof userData.password !== "string" || userData.password.length < 8) {
    errors.push({ field: "password", message: "Password must be at least 8 characters long" });
  }
  if (userData.password !== userData.confirmPassword) {
    errors.push({ field: "confirmPassword", message: "Passwords do not match" });
  }
  if (!userData.npub || typeof userData.npub !== "string" || !userData.npub.startsWith("npub1")) {
    errors.push({ field: "npub", message: "Valid npub is required" });
  }
  if (!userData.encryptedNsec || typeof userData.encryptedNsec !== "string") {
    errors.push({ field: "encryptedNsec", message: "Private key is required" });
  }
  if (userData.encryptedNsec && !userData.encryptedNsec.startsWith("nsec1")) {
    errors.push({ field: "encryptedNsec", message: "Invalid private key format - must be bech32 nsec" });
  }
  if (userData.username && !/^[a-zA-Z0-9_-]+$/.test(userData.username)) {
    errors.push({ field: "username", message: "Username can only contain letters, numbers, underscores, and hyphens" });
  }
  if (userData.nip05 && userData.nip05 !== `${userData.username}@satnam.pub`) {
    errors.push({ field: "nip05", message: "NIP-05 must match username@satnam.pub format" });
  }
  if (errors.length > 0) {
    return { success: false, errors };
  }
  return {
    success: true,
    data: {
      username: userData.username.trim().toLowerCase(),
      password: userData.password,
      npub: userData.npub.trim(),
      encryptedNsec: userData.encryptedNsec,
      nip05: userData.nip05 || `${userData.username.trim().toLowerCase()}@satnam.pub`,
      lightningAddress: userData.lightningAddress,
      role: userData.role || "private",
      displayName: userData.displayName?.trim(),
      bio: userData.bio?.trim(),
      generateInviteToken: userData.generateInviteToken || false,
      invitationToken: userData.invitationToken || null,
      // Support for imported accounts
      isImportedAccount: userData.isImportedAccount || false,
      detectedProfile: userData.detectedProfile || null,
      // DUID Integration: Include pre-generated DUID from Identity Forge
      deterministicUserId: userData.deterministicUserId || null
    }
  };
}
async function checkUsernameAvailability(username) {
  try {
    const domain = "satnam.pub";
    const local = (username || "").trim().toLowerCase();
    if (!local) return false;
    const crypto2 = await import("node:crypto");
    const secret = await getDUIDSecret();
    const identifier = `${local}@${domain}`;
    const hmac = crypto2.createHmac("sha256", secret);
    hmac.update(identifier);
    const hashed_nip05 = hmac.digest("hex");
    const { data, error } = await import_supabase.supabase.from("nip05_records").select("id").eq("domain", domain).eq("hashed_nip05", hashed_nip05).eq("is_active", true).limit(1);
    if (error) {
      console.error("Username availability check failed:", error);
      return false;
    }
    const isAvailable = !data || data.length === 0;
    console.log(`Username availability: ${username} -> ${isAvailable ? "available" : "taken"}`);
    return isAvailable;
  } catch (error) {
    console.error("Username availability check error:", error);
    return false;
  }
}
async function createUserIdentity(userData, spendingLimits) {
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  try {
    console.log("\u{1F50D} createUserIdentity: Starting user creation process:", {
      username: userData.username,
      role: userData.role,
      hasNpub: !!userData.npub,
      hasEncryptedNsec: !!userData.encryptedNsec,
      hasPassword: !!userData.password
    });
    console.log("\u{1F50D} Importing privacy-hashing utilities...");
    const { generateUserSalt, createHashedUserData } = await import("../../lib/security/privacy-hashing.js");
    console.log("\u2705 Privacy-hashing utilities imported successfully");
    let deterministicUserId;
    try {
      const { generateDUIDFromNIP05 } = await import("../../lib/security/duid-generator.js");
      const nip05Identifier = userData.nip05 || `${userData.username}@satnam.pub`;
      deterministicUserId = await generateDUIDFromNIP05(nip05Identifier);
      console.log("\u2705 Canonical NIP-05-based DUID generated:", {
        nip05: nip05Identifier,
        duidPrefix: deterministicUserId.substring(0, 10) + "...",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        source: "canonical-nip05"
      });
    } catch (duidError) {
      console.error("\u274C Canonical DUID generation failed:", duidError);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "DUID generation failed",
          details: "Failed to generate deterministic user ID. Please try again.",
          code: "DUID_GENERATION_FAILED",
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            requiresRetry: true
          }
        })
      };
    }
    const userSalt = await generateUserSalt();
    console.log("\u{1F510} Encrypting nsec with Noble V2 using generated user salt");
    let encryptedNsecNoble;
    try {
      const { encryptNsecSimple } = await import("../../netlify/functions/security/noble-encryption.js");
      encryptedNsecNoble = await encryptNsecSimple(userData.encryptedNsec, userSalt);
      console.log("\u2705 Noble V2 nsec encryption successful, format:", encryptedNsecNoble.substring(0, 20) + "...");
    } catch (encryptError) {
      console.error("\u274C Noble V2 nsec encryption failed:", encryptError);
      throw new Error("Failed to encrypt nsec with Noble V2: " + (encryptError instanceof Error ? encryptError.message : String(encryptError)));
    }
    const passwordSalt = generatePasswordSalt();
    const passwordHash = await hashPassword(userData.password, passwordSalt);
    let hashedUserData;
    let hashedUsername;
    let hashedLightningAddress;
    try {
      hashedUserData = await createHashedUserData({
        npub: userData.npub,
        nip05: userData.nip05,
        encryptedNsec: encryptedNsecNoble,
        // Use Noble V2 encrypted nsec
        password: userData.password
      }, userSalt);
      const { hashUserData } = await import("../../lib/security/privacy-hashing.js");
      hashedUsername = await hashUserData(userData.username, userSalt);
      hashedLightningAddress = userData.lightningAddress ? await hashUserData(userData.lightningAddress, userSalt) : null;
    } catch (hashError) {
      console.error("Failed to hash user data:", hashError);
      throw new Error("Failed to encrypt user data securely");
    }
    const profileData = {
      id: deterministicUserId,
      // Use DUID as primary key for O(1) database lookups
      user_salt: userSalt,
      // Store user salt for future hashing operations
      // DECRYPTABLE NSEC: Store Noble V2 encrypted nsec for authentication flow
      encrypted_nsec: encryptedNsecNoble,
      // Store Noble V2 encrypted ciphertext
      encrypted_nsec_iv: null,
      // IV is included in Noble V2 format
      // HASHED COLUMNS ONLY - MAXIMUM ENCRYPTION COMPLIANCE
      hashed_username: hashedUsername,
      hashed_npub: hashedUserData.hashed_npub,
      hashed_nip05: hashedUserData.hashed_nip05,
      hashed_lightning_address: hashedLightningAddress,
      // Metadata (non-sensitive)
      role: userData.role,
      spending_limits: spendingLimits,
      privacy_settings: {
        privacy_level: "maximum",
        // Upgraded to maximum for hashed storage
        zero_knowledge_enabled: true,
        over_encryption: true,
        // Flag indicating hashed storage
        is_imported_account: userData.isImportedAccount || false,
        detected_profile_data: userData.detectedProfile || null
      },
      // Secure password storage
      password_hash: passwordHash,
      password_salt: passwordSalt,
      password_created_at: (/* @__PURE__ */ new Date()).toISOString(),
      password_updated_at: (/* @__PURE__ */ new Date()).toISOString(),
      failed_attempts: 0,
      requires_password_change: false,
      is_active: true,
      // New users are active by default
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log("\u{1F504} Attempting to insert user identity with hashed columns...", {
      keyType: "anon_preferred",
      supabaseKeyTypeHint: typeof import_supabase.supabaseKeyType === "undefined" ? "unknown" : typeof import_supabase.supabaseKeyType === "string" ? import_supabase.supabaseKeyType : "unknown",
      profileDataKeys: Object.keys(profileData),
      hasId: !!profileData.id,
      hasHashedNpub: !!profileData.hashed_npub,
      hasEncryptedNsec: !!profileData.encrypted_nsec
    });
    try {
      const { data: testData, error: testError } = await import_supabase.supabase.from("user_identities").select("count").limit(1);
      if (testError) {
        console.error("\u274C Supabase connection test failed:", testError);
        return {
          success: false,
          error: "Database connection failed",
          details: testError.message
        };
      }
      console.log("\u2705 Supabase connection test passed");
    } catch (connectionError) {
      console.error("\u274C Supabase connection error:", connectionError);
      return {
        success: false,
        error: "Database connection error",
        details: connectionError.message
      };
    }
    console.log("\u{1F504} Executing database insert...");
    try {
      await import_supabase.supabase.rpc("app_set_config", {
        setting_name: "app.registration_duid",
        setting_value: profileData.id,
        is_local: true
      });
    } catch (e) {
      try {
        await import_supabase.supabase.rpc("set_app_config", {
          setting_name: "app.registration_duid",
          setting_value: profileData.id,
          is_local: true
        });
      } catch {
      }
    }
    const { error } = await import_supabase.supabase.from("user_identities").insert([profileData], { returning: "minimal" });
    const data = error ? null : { id: profileData.id };
    if (error) {
      console.error("User identity creation failed:", error);
      console.error("Database error details:", {
        message: error.message,
        code: error.code,
        details: error.details,
        hint: error.hint
      });
      console.error("Attempted to insert data:", JSON.stringify(profileData, null, 2));
      return {
        success: false,
        error: "Failed to create user identity",
        details: error.message,
        code: error.code
      };
    }
    return { success: true, data };
  } catch (error) {
    console.error("User profile creation error:", error);
    return { success: false, error: "Database operation failed" };
  }
}
const handler = async (event, context) => {
  console.log("\u{1F680} Registration handler started:", {
    method: event.httpMethod,
    path: event.path,
    headers: Object.keys(event.headers || {}),
    bodyLength: event.body?.length || 0,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
  console.log("\u{1F50D} Environment check:", {
    hasSupabaseUrl: !!process.env.SUPABASE_URL || !!process.env.VITE_SUPABASE_URL,
    hasSupabaseKey: !!process.env.SUPABASE_ANON_KEY || !!process.env.VITE_SUPABASE_ANON_KEY,
    hasDuidSecret: !!process.env.DUID_SERVER_SECRET,
    supabaseKeyType: import_supabase.supabaseKeyType,
    nodeEnv: process.env.NODE_ENV
  });
  function getAllowedOrigin(origin) {
    const isProd = process.env.NODE_ENV === "production";
    if (isProd) return "https://satnam.pub";
    if (!origin) return "*";
    try {
      const u = new URL(origin);
      if ((u.hostname === "localhost" || u.hostname === "127.0.0.1") && u.protocol === "http:") {
        return origin;
      }
    } catch {
    }
    return "*";
  }
  const requestOrigin = event.headers?.origin || event.headers?.Origin;
  const corsHeaders = {
    "Access-Control-Allow-Origin": getAllowedOrigin(requestOrigin),
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: {
        ...corsHeaders,
        "Allow": "POST"
      },
      body: JSON.stringify({
        success: false,
        error: "Method not allowed",
        meta: {
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      })
    };
  }
  try {
    let userData;
    try {
      userData = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    } catch (parseError) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid JSON in request body",
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    try {
      const xfwd = event.headers?.["x-forwarded-for"] || event.headers?.["X-Forwarded-For"];
      const clientIp = Array.isArray(xfwd) ? xfwd[0] : (xfwd || "").split(",")[0]?.trim() || "unknown";
      const isDevelopment = process.env.NODE_ENV !== "production";
      const windowSec = isDevelopment ? 300 : 60;
      const maxAttempts = isDevelopment ? 50 : 5;
      console.log(`\u{1F512} Rate limiting: ${maxAttempts} attempts per ${windowSec}s (${isDevelopment ? "development" : "production"} mode)`);
      const windowStart = new Date(Math.floor(Date.now() / (windowSec * 1e3)) * (windowSec * 1e3)).toISOString();
      const { supabase: rateLimitSupabase } = await import("../../netlify/functions/supabase.js");
      const { data, error } = await rateLimitSupabase.rpc("increment_auth_rate", {
        p_identifier: clientIp,
        p_scope: "ip",
        p_window_start: windowStart,
        p_limit: maxAttempts
      });
      const limited = Array.isArray(data) ? data?.[0]?.limited : data?.limited;
      if (error) {
        console.error("Rate limiting error:", error);
        if (isDevelopment) {
          console.warn("\u26A0\uFE0F Rate limiting error in development - allowing request");
        } else {
          return {
            statusCode: 429,
            headers: corsHeaders,
            body: JSON.stringify({ success: false, error: "Rate limiting service unavailable" })
          };
        }
      }
      if (limited) {
        console.warn(`\u{1F6AB} Rate limit exceeded for IP: ${clientIp}`);
        return {
          statusCode: 429,
          headers: corsHeaders,
          body: JSON.stringify({
            success: false,
            error: `Too many registration attempts. Please wait ${windowSec} seconds before trying again.`
          })
        };
      }
      console.log(`\u2705 Rate limit check passed for IP: ${clientIp}`);
    } catch (rateLimitError) {
      console.error("Rate limiting exception:", rateLimitError);
      const isDevelopment = process.env.NODE_ENV !== "production";
      if (isDevelopment) {
        console.warn("\u26A0\uFE0F Rate limiting exception in development - allowing request");
      } else {
        return {
          statusCode: 429,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Too many registration attempts" })
        };
      }
    }
    const validationResult = validateRegistrationData(userData);
    if (!validationResult.success) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid registration data",
          details: validationResult.errors,
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    let reservedHashedNip052 = null;
    let reservedDomain2 = "satnam.pub";
    const validatedData = validationResult.data;
    console.log("\u{1F50D} Checking username availability:", {
      username: validatedData.username,
      hasNpub: !!validatedData.npub,
      hasEncryptedNsec: !!validatedData.encryptedNsec
    });
    let isUsernameAvailable;
    try {
      isUsernameAvailable = await checkUsernameAvailability(validatedData.username);
      console.log("\u2705 Username availability check completed:", { available: isUsernameAvailable });
    } catch (usernameError) {
      console.error("\u274C Username availability check failed:", usernameError);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Username availability check failed",
          debug: usernameError.message,
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    if (!isUsernameAvailable) {
      return {
        statusCode: 409,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Username is already taken",
          field: "username",
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    try {
      const domain = "satnam.pub";
      const local = String(validatedData.username || "").trim().toLowerCase();
      const identifier = `${local}@${domain}`;
      const { createHmac } = await import("node:crypto");
      const secret = await getDUIDSecret();
      const hashed_nip05 = createHmac("sha256", secret).update(identifier).digest("hex");
      const hashed_npub = createHmac("sha256", secret).update(`NPUBv1:${validatedData.npub}`).digest("hex");
      reservedHashedNip052 = hashed_nip05;
      reservedDomain2 = domain;
      const { error: nip05InsertError } = await import_supabase.supabase.from("nip05_records").insert({
        domain,
        is_active: true,
        created_at: (/* @__PURE__ */ new Date()).toISOString(),
        updated_at: (/* @__PURE__ */ new Date()).toISOString(),
        hashed_nip05,
        hashed_npub
      });
      if (nip05InsertError) {
        const code = nip05InsertError.code || "";
        console.warn("NIP-05 reservation insert error:", nip05InsertError);
        if (code === "23505" || /duplicate/i.test(nip05InsertError.message || "")) {
          return {
            statusCode: 409,
            headers: corsHeaders,
            body: JSON.stringify({ success: false, error: "Username is already taken", field: "username" })
          };
        }
        return {
          statusCode: 500,
          headers: corsHeaders,
          body: JSON.stringify({ success: false, error: "Failed to reserve username" })
        };
      }
      console.log("\u2705 NIP-05 reservation created for", identifier);
    } catch (reserveErr) {
      console.error("Failed to reserve NIP-05 username:", reserveErr);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ success: false, error: "Failed to reserve username" })
      };
    }
    const hashedIdentifier = await generatePrivacyPreservingHash(validatedData.username);
    const standardizedRole = validateRole(validatedData.role);
    const spendingLimits = generateSovereigntySpendingLimits(standardizedRole);
    console.log("\u{1F50D} Creating user identity in database:", {
      role: standardizedRole,
      hasSpendingLimits: !!spendingLimits,
      npubLength: validatedData.npub?.length,
      encryptedNsecLength: validatedData.encryptedNsec?.length
    });
    let profileResult;
    try {
      profileResult = await createUserIdentity(
        { ...validatedData, role: standardizedRole },
        spendingLimits
      );
      console.log("\u2705 User identity creation completed:", {
        success: profileResult.success,
        hasData: !!profileResult.data
      });
    } catch (createError) {
      console.error("\u274C User identity creation failed:", createError);
      console.error("Create error details:", {
        name: createError.name,
        message: createError.message,
        stack: createError.stack?.substring(0, 500)
      });
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "User identity creation failed",
          debug: createError.message,
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    if (!profileResult.success) {
      console.error("\u274C User identity creation returned failure:", profileResult.error);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: profileResult.error,
          meta: {
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          }
        })
      };
    }
    const sessionId = crypto.randomBytes(16).toString("hex");
    const hashedId = crypto.createHmac("sha256", process.env.JWT_SECRET || "fallback-secret").update(`${profileResult.data.id}|${sessionId}`).digest("hex");
    const jwtToken = await createSecureJWT({
      userId: profileResult.data.id,
      // Use DUID from created user record
      hashedId,
      // Required by frontend SecureTokenManager
      username: validatedData.username,
      nip05: `${validatedData.username}@satnam.pub`,
      role: standardizedRole,
      type: "access",
      // Required by frontend SecureTokenManager
      sessionId
      // Required by frontend SecureTokenManager
    });
    const responseData = {
      success: true,
      message: "Identity registered successfully with sovereignty enforcement",
      user: {
        id: profileResult.data.id,
        // FIXED: Use actual database user ID for consistency
        hashedId,
        // Include hashed ID for JWT validation
        username: validatedData.username,
        nip05: validatedData.nip05 || `${validatedData.username}@satnam.pub`,
        lightningAddress: validatedData.lightningAddress || `${validatedData.username}@satnam.pub`,
        displayName: validatedData.displayName || validatedData.username,
        role: standardizedRole,
        is_active: true,
        // FIXED: Include is_active for authentication state
        spendingLimits,
        registeredAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      session: {
        token: jwtToken,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString()
      },
      sessionToken: jwtToken,
      // FIXED: Include sessionToken at root level for compatibility
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        environment: process.env.NODE_ENV || "production"
      }
    };
    if (userData.invitationToken) {
      try {
        const invitationResponse = await fetch(`${process.env.FRONTEND_URL || "https://satnam.pub"}/api/authenticated/process-invitation`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${jwtToken}`
          },
          body: JSON.stringify({
            inviteToken: userData.invitationToken
          })
        });
        if (invitationResponse.ok) {
          const invitationResult = await invitationResponse.json();
          if (invitationResult.success) {
            responseData.invitationProcessed = {
              creditsAwarded: invitationResult.creditsAwarded,
              welcomeMessage: invitationResult.welcomeMessage,
              personalMessage: invitationResult.personalMessage
            };
            console.log("Invitation processed successfully during registration");
          }
        }
      } catch (invitationError) {
        console.warn("Failed to process invitation during registration:", invitationError);
      }
    }
    if (validatedData.invitationCode || validatedData.familyId) {
      responseData.postAuthAction = "show_invitation_modal";
    }
    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify(responseData)
    };
  } catch (error) {
    console.error("Registration error:", error);
    try {
      if (reservedHashedNip05 && reservedDomain) {
        await import_supabase.supabase.from("nip05_records").delete().eq("hashed_nip05", reservedHashedNip05).eq("domain", reservedDomain);
        console.log("\u2705 Cleaned up reserved NIP-05 after registration failure");
      }
    } catch (cleanupError) {
      console.error("\u26A0\uFE0F Failed to cleanup reserved NIP-05:", cleanupError);
    }
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "Registration failed",
        meta: {
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
