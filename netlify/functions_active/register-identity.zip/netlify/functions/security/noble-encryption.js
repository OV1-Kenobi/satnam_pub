"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var noble_encryption_exports = {};
__export(noble_encryption_exports, {
  decryptNsecSimple: () => decryptNsecSimple,
  encryptNsecSimple: () => encryptNsecSimple
});
module.exports = __toCommonJS(noble_encryption_exports);
var nodeCrypto = __toESM(require("node:crypto"), 1);
let _gcm;
let _sha256;
async function ensureLibs() {
  if (!_gcm) {
    const mod = await import("@noble/ciphers/aes");
    _gcm = mod.gcm;
  }
  if (!_sha256) {
    const mod = await import("@noble/hashes/sha256");
    _sha256 = mod.sha256;
  }
}
function toHex(bytes) {
  return Buffer.from(bytes).toString("hex");
}
function fromHex(hex) {
  return new Uint8Array(Buffer.from(hex, "hex"));
}
function utf8Bytes(str) {
  return new TextEncoder().encode(str);
}
function getRandomIv() {
  const iv = new Uint8Array(12);
  const webcrypto = nodeCrypto.webcrypto;
  if (webcrypto && webcrypto.getRandomValues) {
    webcrypto.getRandomValues(iv);
  } else {
    nodeCrypto.randomFillSync(iv);
  }
  return iv;
}
async function deriveKeyFromSalt(salt) {
  await ensureLibs();
  const digest = _sha256(utf8Bytes(String(salt)));
  return new Uint8Array(digest.slice(0, 32));
}
function b64urlEncode(bytes) {
  return Buffer.from(bytes).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function b64urlDecode(s) {
  const pad = s.length % 4;
  const normalized = (pad ? s + "=".repeat(4 - pad) : s).replace(/-/g, "+").replace(/_/g, "/");
  return new Uint8Array(Buffer.from(normalized, "base64"));
}
function serializeNobleV2(iv, cipher, userSalt) {
  const saltBytes = utf8Bytes(String(userSalt || ""));
  const saltSeg = b64urlEncode(saltBytes);
  const ivSeg = b64urlEncode(iv);
  const ctSeg = b64urlEncode(cipher);
  return `noble-v2.${saltSeg}.${ivSeg}.${ctSeg}`;
}
function parseSerialized(s) {
  if (typeof s !== "string") return null;
  if (s.startsWith("n2enc:")) {
    const parts = s.split(":");
    if (parts.length !== 3) return null;
    const iv = fromHex(parts[1]);
    const cipher = fromHex(parts[2]);
    return { iv, cipher };
  }
  if (s.startsWith("noble-v2.")) {
    const parts = s.split(".");
    if (parts.length !== 4) return null;
    const iv = b64urlDecode(parts[2]);
    const cipher = b64urlDecode(parts[3]);
    return { iv, cipher };
  }
  return null;
}
async function encryptNsecSimple(nsecBech32, userSalt) {
  try {
    if (!nsecBech32 || typeof nsecBech32 !== "string") {
      throw new Error("encryptNsecSimple: invalid nsec");
    }
    if (!userSalt || typeof userSalt !== "string") {
      throw new Error("encryptNsecSimple: invalid salt");
    }
    await ensureLibs();
    const key = await deriveKeyFromSalt(userSalt);
    const iv = getRandomIv();
    const aead = _gcm(key, iv);
    const pt = utf8Bytes(nsecBech32);
    const ct = aead.encrypt(pt);
    return serializeNobleV2(iv, ct, userSalt);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    throw new Error(`encryptNsecSimple failed: ${msg}`);
  }
}
async function decryptNsecSimple(serialized, userSalt) {
  try {
    if (!serialized || typeof serialized !== "string") {
      throw new Error("decryptNsecSimple: invalid input");
    }
    if (!userSalt || typeof userSalt !== "string") {
      throw new Error("decryptNsecSimple: invalid salt");
    }
    await ensureLibs();
    const parsed = parseSerialized(serialized);
    if (!parsed) throw new Error("decryptNsecSimple: parse failed");
    const key = await deriveKeyFromSalt(userSalt);
    const aead = _gcm(key, parsed.iv);
    const pt = aead.decrypt(parsed.cipher);
    return new TextDecoder().decode(pt);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    throw new Error(`decryptNsecSimple failed: ${msg}`);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  decryptNsecSimple,
  encryptNsecSimple
});
