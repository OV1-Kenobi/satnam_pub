"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var privacy_logger_exports = {};
__export(privacy_logger_exports, {
  error: () => error,
  log: () => log,
  redactLogger: () => redactLogger,
  setDevMode: () => setDevMode,
  warn: () => warn
});
module.exports = __toCommonJS(privacy_logger_exports);
const SENSITIVE_KEYS = /* @__PURE__ */ new Set([
  "npub",
  "duid",
  "nip05",
  "signature",
  "nsec",
  "privateKey",
  "password",
  "authHash",
  "salt"
]);
const SAFE_KEYS = /* @__PURE__ */ new Set([
  "timestamp",
  "status",
  "message",
  "level",
  "code",
  "operation",
  "context"
]);
let devMode = false;
function detectDevMode() {
  try {
    if (typeof process !== "undefined" && process.env) {
      return process.env.NODE_ENV !== "production";
    }
  } catch {
  }
  return false;
}
devMode = detectDevMode();
function maskSensitiveInString(s) {
  if (!s || typeof s !== "string") return s;
  return s.replace(/npub1[a-z0-9]+/gi, "npub1[REDACTED]").replace(/nsec1[a-z0-9]+/gi, "nsec1[REDACTED]").replace(/[a-f0-9]{64,}/gi, (m) => m.slice(0, 8) + "[REDACTED]").replace(/\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b/gi, "[REDACTED_EMAIL]");
}
function sanitizeArg(arg) {
  if (arg instanceof Error) {
    return { name: arg.name, message: arg.message };
  }
  if (arg && typeof arg === "object" && !Array.isArray(arg)) {
    const out = {};
    for (const [k, v] of Object.entries(arg)) {
      if (SENSITIVE_KEYS.has(k)) continue;
      if (SAFE_KEYS.has(k)) {
        if (v instanceof Error) {
          out[k] = { name: v.name, message: v.message };
        } else if (typeof v === "string") {
          out[k] = devMode ? maskSensitiveInString(v) : "[redacted]";
        } else if (v && typeof v === "object") {
          out[k] = "[object]";
        } else {
          out[k] = v;
        }
      }
    }
    return out;
  }
  if (Array.isArray(arg)) {
    return arg.map((x) => sanitizeArg(x));
  }
  if (typeof arg === "string") {
    return devMode ? maskSensitiveInString(arg) : "[redacted]";
  }
  return arg;
}
function buildArgs(args) {
  return args.map((a) => sanitizeArg(a));
}
function dispatch(level, args) {
  const safeArgs = buildArgs(args);
  try {
    console[level](...safeArgs);
  } catch {
    console[level]("[privacy-logger]: failed to log safely");
  }
}
const redactLogger = {
  /**
   * Set development mode (optional override)
   * @param {boolean} value
   */
  setDevMode(value) {
    devMode = !!value;
  },
  /**
   * Safe log
   * @param  {...any} args
   */
  log(...args) {
    dispatch("log", args);
  },
  /**
   * Safe warn
   * @param  {...any} args
   */
  warn(...args) {
    dispatch("warn", args);
  },
  /**
   * Safe error
   * @param  {...any} args
   */
  error(...args) {
    dispatch("error", args);
  }
};
const setDevMode = (v) => redactLogger.setDevMode(v);
const log = (...args) => redactLogger.log(...args);
const warn = (...args) => redactLogger.warn(...args);
const error = (...args) => redactLogger.error(...args);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  error,
  log,
  redactLogger,
  setDevMode,
  warn
});
