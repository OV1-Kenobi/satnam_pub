"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var invitation_unified_exports = {};
__export(invitation_unified_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(invitation_unified_exports);
const handler = async (event, context) => {
  const cors = buildCorsHeaders(event);
  if ((event.httpMethod || "GET").toUpperCase() === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }
  try {
    const method = (event.httpMethod || "GET").toUpperCase();
    const path = event.path || event.rawUrl || event.headers?.["x-forwarded-for-path"] || "";
    const referer = event.headers?.referer || "";
    console.log("\u{1F50D} Path debug:", {
      eventPath: event.path,
      rawUrl: event.rawUrl,
      referer: referer.substring(0, 100),
      headers: Object.keys(event.headers || {}).join(", ")
    });
    const target = resolveInvitationRoute(path, method);
    if (!target) {
      return {
        statusCode: 404,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Invitation endpoint not found",
          path,
          method
        })
      };
    }
    if (target.inline && target.operation === "generate-peer-invite") {
      console.log("\u{1F50D} Using inline peer invitation implementation");
      return await handlePeerInviteInline(event, context, cors);
    }
    let targetHandler;
    try {
      const mod = await import(target.module);
      targetHandler = mod.handler || mod.default;
    } catch (importError) {
      console.error(`Failed to import invitation module: ${target.module}`, importError);
      return {
        statusCode: 500,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Invitation service temporarily unavailable",
          operation: target.operation
        })
      };
    }
    if (typeof targetHandler !== "function") {
      return {
        statusCode: 500,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Invitation handler not available",
          operation: target.operation
        })
      };
    }
    const response = await targetHandler(event, context);
    if (response && typeof response === "object") {
      return {
        ...response,
        headers: {
          ...response.headers || {},
          ...cors
        }
      };
    }
    return {
      statusCode: 200,
      headers: cors,
      body: typeof response === "string" ? response : JSON.stringify(response)
    };
  } catch (error) {
    console.error("Unified invitation handler error:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({
        success: false,
        error: "Invitation service error"
      })
    };
  }
};
function resolveInvitationRoute(path, method) {
  const normalizedPath = path.toLowerCase();
  if ((normalizedPath.includes("/authenticated/generate-peer-invite") || normalizedPath.includes("/api/authenticated/generate-peer-invite") || !path && method === "POST") && method === "POST") {
    return {
      inline: true,
      operation: "generate-peer-invite"
    };
  }
  if ((normalizedPath.includes("/authenticated/process-signed-invitation") || normalizedPath.includes("/api/authenticated/process-signed-invitation")) && method === "POST") {
    return {
      module: "../../api/authenticated/process-signed-invitation.js",
      operation: "process-signed-invitation"
    };
  }
  return null;
}
function buildCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const isProd = process.env.NODE_ENV === "production";
  const allowedOrigin = isProd ? process.env.FRONTEND_URL || "https://www.satnam.pub" : origin || "*";
  const allowCredentials = allowedOrigin !== "*";
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Credentials": String(allowCredentials),
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin, Access-Control-Request-Method, Access-Control-Request-Headers",
    "Content-Type": "application/json"
  };
}
async function verifyJWT(token) {
  try {
    const { jwtVerify, createRemoteJWKSet } = await import("jose");
    const JWT_SECRET = process.env.JWT_SECRET;
    const JWKS_URI = process.env.JWKS_URI;
    const JWT_ISSUER = process.env.JWT_ISSUER || "satnam.pub";
    const JWT_AUDIENCE = process.env.JWT_AUDIENCE || "satnam.pub";
    let payload;
    if (JWKS_URI) {
      console.log("\u{1F510} Using JWKS verification");
      const JWKS = createRemoteJWKSet(new URL(JWKS_URI));
      const { payload: jwksPayload } = await jwtVerify(token, JWKS, {
        issuer: JWT_ISSUER,
        audience: JWT_AUDIENCE,
        clockTolerance: 30
        // 30 seconds tolerance for clock skew
      });
      payload = jwksPayload;
    } else if (JWT_SECRET) {
      console.log("\u{1F510} Using HS256 secret verification");
      const secret = new TextEncoder().encode(JWT_SECRET);
      const { payload: secretPayload } = await jwtVerify(token, secret, {
        issuer: JWT_ISSUER,
        audience: JWT_AUDIENCE,
        clockTolerance: 30
      });
      payload = secretPayload;
    } else if (process.env.NODE_ENV === "development") {
      console.warn("\u26A0\uFE0F  WARNING: Using insecure JWT verification in development mode");
      const parts = token.split(".");
      if (parts.length !== 3) {
        throw new Error("Invalid JWT format");
      }
      payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
      const now2 = Math.floor(Date.now() / 1e3);
      if (payload.exp && payload.exp < now2) {
        throw new Error("Token expired");
      }
    } else {
      throw new Error("JWT verification not configured - missing JWT_SECRET or JWKS_URI");
    }
    if (!payload.userId || !payload.username) {
      throw new Error("Invalid token payload - missing required claims");
    }
    const now = Math.floor(Date.now() / 1e3);
    if (!payload.exp || payload.exp < now) {
      throw new Error("Token expired");
    }
    console.log("\u2705 JWT verification successful:", {
      userId: payload.userId,
      username: payload.username,
      exp: new Date(payload.exp * 1e3).toISOString()
    });
    return payload;
  } catch (error) {
    console.error("\u274C JWT verification error:", error.message);
    throw new Error(`JWT verification failed: ${error.message}`);
  }
}
async function handlePeerInviteInline(event, context, corsHeaders) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ success: false, error: "Method not allowed" })
    };
  }
  try {
    const headers = event.headers || {};
    const authHeader = headers.authorization || headers.Authorization || headers["authorization"] || headers["Authorization"];
    if (!authHeader) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Authorization token required"
        })
      };
    }
    const bearerMatch = authHeader.match(/^bearer\s+(.+)$/i);
    if (!bearerMatch) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid authorization format. Expected: Bearer <token>"
        })
      };
    }
    const token = bearerMatch[1];
    let payload;
    try {
      payload = await verifyJWT(token);
    } catch (jwtError) {
      console.error("\u274C JWT verification failed:", jwtError.message);
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({
          success: false,
          error: "Invalid or expired token",
          debug: process.env.NODE_ENV === "development" ? jwtError.message : void 0
        })
      };
    }
    const body = JSON.parse(event.body || "{}");
    const { inviteType = "peer", message = "Join me on Satnam!", expiresIn = 24 } = body;
    console.log("\u{1F504} Generating peer invitation:", {
      userId: payload.userId,
      username: payload.username,
      inviteType,
      expiresIn
    });
    const { randomBytes } = await import("node:crypto");
    const inviteCode = randomBytes(16).toString("hex");
    const expiresAt = new Date(Date.now() + expiresIn * 60 * 60 * 1e3).toISOString();
    const invitationData = {
      inviteCode,
      inviterUserId: payload.userId,
      inviterUsername: payload.username,
      inviterNip05: payload.nip05,
      inviteType,
      message,
      expiresAt,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      isActive: true
    };
    const inviteUrl = `https://satnam.pub/invite/${inviteCode}`;
    const qrCodeData = `data:image/svg+xml;base64,${Buffer.from(`
      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="white"/>
        <text x="100" y="100" text-anchor="middle" font-family="monospace" font-size="12">
          QR Code: ${inviteCode.substring(0, 8)}...
        </text>
      </svg>
    `).toString("base64")}`;
    console.log("\u2705 Peer invitation generated successfully:", {
      inviteCode: inviteCode.substring(0, 8) + "...",
      expiresAt
    });
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        success: true,
        message: "Peer invitation generated successfully",
        inviteCode,
        inviteUrl,
        qrCode: qrCodeData,
        invitation: {
          type: inviteType,
          message,
          expiresAt,
          createdAt: invitationData.createdAt
        },
        inviter: {
          username: payload.username,
          nip05: payload.nip05
        }
      })
    };
  } catch (error) {
    console.error("\u274C Peer invitation generation error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        success: false,
        error: "Failed to generate peer invitation",
        debug: {
          message: error.message,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
