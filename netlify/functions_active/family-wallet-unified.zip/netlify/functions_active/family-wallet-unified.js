"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var family_wallet_unified_exports = {};
__export(family_wallet_unified_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(family_wallet_unified_exports);
const handler = async (event, context) => {
  const cors = buildCorsHeaders(event);
  if ((event.httpMethod || "GET").toUpperCase() === "OPTIONS") {
    return { statusCode: 204, headers: cors, body: "" };
  }
  try {
    const method = (event.httpMethod || "GET").toUpperCase();
    const path = event.path || "";
    const target = resolveFamilyWalletRoute(path, method);
    if (!target) {
      return {
        statusCode: 404,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Family wallet endpoint not found",
          path,
          method
        })
      };
    }
    let targetHandler;
    try {
      const mod = await import(target.module);
      targetHandler = mod.handler || mod.default;
    } catch (importError) {
      console.error(`Failed to import family wallet module: ${target.module}`, importError);
      return {
        statusCode: 500,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Family wallet service temporarily unavailable",
          walletType: target.walletType
        })
      };
    }
    if (typeof targetHandler !== "function") {
      return {
        statusCode: 500,
        headers: cors,
        body: JSON.stringify({
          success: false,
          error: "Family wallet handler not available",
          walletType: target.walletType
        })
      };
    }
    const response = await targetHandler(event, context);
    if (response && typeof response === "object") {
      return {
        ...response,
        headers: {
          ...response.headers || {},
          ...cors
        }
      };
    }
    return {
      statusCode: 200,
      headers: cors,
      body: typeof response === "string" ? response : JSON.stringify(response)
    };
  } catch (error) {
    console.error("Unified family wallet handler error:", error);
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({
        success: false,
        error: "Family wallet service error"
      })
    };
  }
};
function resolveFamilyWalletRoute(path, method) {
  const normalizedPath = path.toLowerCase();
  if (normalizedPath.includes("/family/cashu/wallet") || normalizedPath.includes("/api/family/cashu/wallet")) {
    return {
      module: "../functions_lazy/family-cashu-wallet.js",
      walletType: "cashu"
    };
  }
  if (normalizedPath.includes("/family/lightning/wallet") || normalizedPath.includes("/api/family/lightning/wallet")) {
    return {
      module: "../functions_lazy/family-lightning-wallet.js",
      walletType: "lightning"
    };
  }
  if (normalizedPath.includes("/family/fedimint/wallet") || normalizedPath.includes("/api/family/fedimint/wallet")) {
    return {
      module: "../functions_lazy/family-fedimint-wallet.js",
      walletType: "fedimint"
    };
  }
  return null;
}
function buildCorsHeaders(event) {
  const origin = event.headers?.origin || event.headers?.Origin;
  const isProd = process.env.NODE_ENV === "production";
  const allowedOrigin = isProd ? process.env.FRONTEND_URL || "https://www.satnam.pub" : origin || "*";
  const allowCredentials = allowedOrigin !== "*";
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Credentials": String(allowCredentials),
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin, Access-Control-Request-Method, Access-Control-Request-Headers",
    "Content-Type": "application/json"
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
